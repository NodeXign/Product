// Local stand-in for Overpass, TeleGeography and Nominatim (run with tsx).
import http from "node:http";
import * as F from "../fixtures";

const port = Number(process.env.MOCK_PORT || 4010);
const send = (res: http.ServerResponse, code: number, body: unknown) => {
  res.writeHead(code, { "content-type": "application/json" });
  res.end(typeof body === "string" ? body : JSON.stringify(body));
};

http
  .createServer((req, res) => {
    const url = new URL(req.url!, `http://localhost:${port}`);
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      if (url.pathname === "/api/interpreter") {
        const q = decodeURIComponent(body.replace(/^data=/, "").replace(/\+/g, " "));
        if (q.includes("is_in(")) return send(res, 200, F.BOUNDARY_PASS1);
        if (q.includes("way(id:")) return send(res, 200, F.BOUNDARY_PASS2);
        if (q.includes('"power"~"^(line|cable)$"')) return send(res, 200, F.OVERPASS_LINES);
        if (q.includes('"power"~"^(plant|substation)$"')) return send(res, 200, F.OVERPASS_POINTS);
        return send(res, 200, { elements: [] });
      }
      if (url.pathname === "/cables/landing-point/landing-point-geo.json") return send(res, 200, F.TG_LANDING);
      if (url.pathname === "/cables/cable/cable-geo.json") return send(res, 200, F.TG_CABLES);
      const m = /^\/cables\/(.+)\.json$/.exec(url.pathname);
      if (m) return F.TG_DETAILS[m[1]] ? send(res, 200, F.TG_DETAILS[m[1]]) : send(res, 404, { error: "nf" });
      if (url.pathname === "/nominatim/search") return send(res, 200, F.NOMINATIM_KABIL);
      send(res, 404, { error: "unmocked", path: url.pathname });
    });
  })
  .listen(port, () => console.log(`mock upstreams on ${port}`));
