// End-to-end browser test against `next start` + mock upstreams.
// Usage: node tests/e2e/run.mjs <baseUrl> <outDir>
// Needs Playwright: set PLAYWRIGHT_MODULE to its path if it isn't resolvable, and
// CHROMIUM_PATH to use a preinstalled browser.
import fs from "node:fs";

const pw = await import(process.env.PLAYWRIGHT_MODULE || "playwright");
const { chromium } = pw.default ?? pw;
const BASE = process.argv[2] || "http://127.0.0.1:3100";
const OUT = process.argv[3] || ".";
const results = [];
const check = (name, ok, extra = "") => {
  results.push({ name, ok });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? `  — ${extra}` : ""}`);
};

// Placeholder tiles (the sandbox can't reach imagery servers).
const tile = (z, x, y) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256"><rect width="256" height="256" fill="#2a3a2f"/><path d="M0 0H256V256" fill="none" stroke="#3d5243" stroke-width="2"/><text x="8" y="20" fill="#5c7563" font-family="monospace" font-size="11">${z}/${x}/${y}</text></svg>`;

const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "en-US" });
await ctx.grantPermissions(["clipboard-read", "clipboard-write"], { origin: BASE });
await ctx.route(/arcgisonline\.com|cartocdn\.com|tile\.googleapis\.com/, (route) => {
  const m = /\/(\d+)\/(\d+)\/(\d+)/.exec(route.request().url()) || [];
  route.fulfill({ status: 200, contentType: "image/svg+xml", body: tile(m[1], m[2], m[3]) });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => m.type() === "error" && !/Failed to load resource/.test(m.text()) && errors.push(m.text()));

const stat = async (label) => {
  const dd = page.locator(".si-stats > div", { hasText: label }).locator("dd");
  return (await dd.innerText()).trim();
};
const corners = async () => parseInt(await stat("Corners"), 10);
const area = async () => parseFloat(await stat("Area"));

await page.goto(BASE, { waitUntil: "networkidle" });
await page.waitForSelector(".si-welcome");
check("loads in English with welcome card", (await page.locator(".si-step h2").first().innerText()) === "Locate the site");
await page.screenshot({ path: `${OUT}/e2e-01-welcome.png` });

// ---- 1. address → Nominatim polygon ------------------------------------------------
await page.fill(".si-input", "Kabil Industrial Estate");
await page.click("button:has-text('Locate')");
await page.waitForSelector(".si-stats");
check("address resolves to a boundary polygon", (await corners()) === 4, `${await area()} ha`);
check("provenance notice shows the provider", (await page.locator(".si-notice--info").innerText()).includes("OpenStreetMap Nominatim"));
await page.waitForTimeout(1200); // let the fly-to animation settle before grabbing a handle
const a0 = await area();
const gps0 = await page.locator(".si-gps b").innerText();

// ---- 2. drag a corner: live GPS + area -------------------------------------------------
const v = page.locator(".si-vertex").first();
const vb = await v.boundingBox();
await page.mouse.move(vb.x + 6, vb.y + 6);
await page.mouse.down();
await page.mouse.move(vb.x - 60, vb.y - 50, { steps: 8 });
const liveGps = await page.locator(".si-gps b").innerText();
check("GPS readout updates live during a corner drag", liveGps !== gps0, `${gps0} → ${liveGps}`);
await page.mouse.up();
await page.waitForTimeout(150);
const a1 = await area();
check("area recomputed after corner drag", Math.abs(a1 - a0) > 1, `${a0} → ${a1} ha`);

// ---- 3. drag the centre pin: moves site, keeps area -------------------------------------
const c = page.locator(".si-center");
const cb = await c.boundingBox();
const before = await stat("Centre GPS");
await page.mouse.move(cb.x + 15, cb.y + 15);
await page.mouse.down();
await page.mouse.move(cb.x + 120, cb.y + 70, { steps: 8 });
await page.mouse.up();
await page.waitForTimeout(150);
const after = await stat("Centre GPS");
check("centre pin moves the whole boundary", before !== after);
check("area preserved when moving the site", Math.abs((await area()) - a1) < 0.5, `${await area()} ha`);

// ---- 4. add / remove corners --------------------------------------------------------------
await page.locator(".si-mid").first().click();
await page.waitForTimeout(150);
check("clicking a mid-point adds a corner", (await corners()) === 5);
await page.locator(".si-vertex").nth(1).click({ button: "right" });
await page.waitForTimeout(150);
check("right-clicking a corner removes it", (await corners()) === 4);

// ---- 5. scan ----------------------------------------------------------------------------
await page.click("button:has-text('Run scan')");
await page.waitForSelector(".si-ready__card", { timeout: 30000 });
const cards = await page.locator(".si-ready__card").count();
const pills = await page.locator(".si-ready__card .si-pill").allInnerTexts();
check("readiness cards for power / cables / water", cards === 3, pills.join(" | "));
const rows = await page.locator(".si-res").count();
check("scan lists mapped assets", rows >= 10, `${rows} rows`);
const mapMarkers = await page.locator(".si-feat").count();
check("assets drawn on the map", mapMarkers >= 10, `${mapMarkers} markers`);
const srcLinks = await page.locator(".si-res__src").evaluateAll((as) => as.map((a) => a.href));
check("every result links to its source record", srcLinks.length === rows && srcLinks.every((h) => /openstreetmap\.org|submarinecablemap\.com/.test(h)));
await page.locator(".si-res__main", { hasText: "GI Kabil" }).click();
await page.waitForTimeout(1300);
check("clicking a result highlights it and opens its popup", (await page.locator(".si-feat.is-hl").count()) === 1 && (await page.locator(".leaflet-popup .si-pop__name").innerText()) === "GI Kabil");
await page.screenshot({ path: `${OUT}/e2e-02-scan-en.png` });

// ---- 6. language toggle --------------------------------------------------------------------
await page.click(".si-lang");
await page.waitForTimeout(300);
const zhTitles = await page.locator(".si-step h2").allInnerTexts();
check("UI switches to Chinese", zhTitles.join("|") === "定位场地|确定边界|周边扫描", zhTitles.join("|"));
check("readiness ratings localised", (await page.locator(".si-ready__card .si-pill").allInnerTexts()).every((p) => ["优", "中", "弱", "无数据"].includes(p)));
check("asset kinds localised", (await page.locator(".si-res__meta").first().innerText()).match(/[一-龥]/) !== null);
await page.screenshot({ path: `${OUT}/e2e-03-scan-zh.png` });

// ---- 7. report -----------------------------------------------------------------------------
await page.click("button:has-text('报告')");
await page.waitForSelector(".si-report");
const reportRows = await page.locator(".si-table--report tbody tr").count();
check("report lists every asset with sources", reportRows === rows, `${reportRows} rows`);
await page.screenshot({ path: `${OUT}/e2e-04-report-zh.png` });
await page.keyboard.press("Escape");
await page.click(".si-lang");

// ---- 8. save + share link round-trip ---------------------------------------------------------
await page.click("button:has-text('Save')");
await page.waitForSelector(".si-toast");
await page.click("button:has-text('Copy share link')");
await page.waitForTimeout(300);
const shared = await page.evaluate(() => navigator.clipboard.readText());
check("share link carries the site in the URL", /#s=[A-Za-z0-9_-]+$/.test(shared), `${shared.length} chars`);
const p2 = await ctx.newPage();
await p2.goto(shared, { waitUntil: "networkidle" });
await p2.waitForSelector(".si-stats");
const p2corners = parseInt(await p2.locator(".si-stats > div", { hasText: "Corners" }).locator("dd").innerText(), 10);
check("share link reopens the same boundary", p2corners === 4);
await p2.close();

// ---- 9. coordinates → boundary detection -------------------------------------------------------
await page.click("button:has-text('Projects')");
await page.click("button:has-text('New site')");
await page.fill(".si-input", "1.082, 104.116");
await page.click("button:has-text('Locate')");
await page.waitForSelector(".si-cand");
const cands = await page.locator(".si-cand").count();
check("coordinates trigger OSM boundary detection", cands === 2, `${cands} candidates`);
await page.locator(".si-cand", { hasText: "Kabil Industrial Estate" }).click();
await page.waitForTimeout(200);
check("picking a detected parcel applies it", Math.abs((await area()) - 296.7) < 1, `${await area()} ha`);

// ---- 10. draw a new boundary ---------------------------------------------------------------------
await page.click("button:has-text('Draw new')");
const mb = await page.locator(".si-map").boundingBox();
const cx = mb.x + mb.width / 2, cy = mb.y + mb.height / 2;
for (const [dx, dy] of [[-80, -60], [90, -70], [100, 80], [-70, 90]]) await page.mouse.click(cx + dx, cy + dy);
await page.click(".si-drawbar button:has-text('Finish')");
await page.waitForTimeout(200);
check("draw mode creates a 4-corner boundary", (await corners()) === 4);

// ---- 11. KML upload (Google My Maps / Earth export) --------------------------------------------------
const kml = fs.readFileSync(new URL("../fixtures.ts", import.meta.url), "utf8").match(/MY_MAPS_KML = `([\s\S]*?)`;/)[1];
await page.setInputFiles("input[type=file]", { name: "parcel.kml", mimeType: "application/vnd.google-earth.kml+xml", buffer: Buffer.from(kml) });
await page.waitForFunction(() => document.querySelector(".si-notice--info")?.textContent?.includes("Uploaded KML"));
check("KML upload loads the drawn polygon", (await corners()) === 4 && (await page.locator(".si-input").inputValue()) === "parcel.kml");
check("extra placemarks become pins", (await page.locator(".si-pinrow").count()) === 1);

// ---- 12. Batam sample: draggable pins with live GPS, use as site ---------------------------------------
await page.click("button:has-text('Projects')");
await page.locator(".si-projlist__open", { hasText: "Batam · A" }).click();
await page.waitForTimeout(1200);
check("sample study card shown", await page.locator(".si-study").isVisible());
const pinRow = page.locator(".si-pinrow", { hasText: "B · Tanjung Sauh" });
const gpsBefore = await pinRow.locator(".si-pinrow__gps").innerText();
const pinEl = page.locator(".si-pin--cand").nth(1);
const pb = await pinEl.boundingBox();
await page.mouse.move(pb.x + 10, pb.y + 10);
await page.mouse.down();
await page.mouse.move(pb.x + 70, pb.y + 40, { steps: 6 });
const gpsLive = await pinRow.locator(".si-pinrow__gps").innerText();
await page.mouse.up();
await page.waitForTimeout(150);
check("dragging a pin updates its GPS live", gpsLive !== gpsBefore, `${gpsBefore} → ${gpsLive}`);
check("moved pin is flagged", (await pinRow.locator(".si-badge").count()) === 1);
await pinRow.locator("button:has-text('Use as site')").click();
await page.waitForTimeout(200);
check("candidate pin promoted to site boundary", Math.abs((await area()) - 840) < 2, `${await area()} ha`);
await page.locator(".si-study__toggle").click();
await page.screenshot({ path: `${OUT}/e2e-05-batam.png` });

// ---- 13. mobile layout -----------------------------------------------------------------------------------
const m = await ctx.newPage();
await m.setViewportSize({ width: 390, height: 844 });
await m.goto(BASE, { waitUntil: "networkidle" });
await m.waitForSelector(".si-step");
const overflow = await m.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
check("no horizontal scroll on a phone", !overflow);
await m.screenshot({ path: `${OUT}/e2e-06-mobile.png`, fullPage: false });
await m.close();

check("no page errors", errors.length === 0, errors.slice(0, 3).join(" | "));
await browser.close();
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);
