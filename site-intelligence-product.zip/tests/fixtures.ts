// Realistic upstream payloads (Overpass JSON, TeleGeography v3 GeoJSON, Nominatim, Google)
// used to exercise the server code without network access.
import { squareRing } from "../lib/geo";
import type { LatLng } from "../lib/types";

export const SITE_CENTER: LatLng = [1.082, 104.116];
export const SITE_RING = squareRing(SITE_CENTER, 50); // ~707 m × 707 m

const g = (pts: (LatLng | null)[]) => pts.map((p) => (p ? { lat: p[0], lon: p[1] } : null));
const closed = (pts: LatLng[]) => g([...pts, pts[0]]);

export const OVERPASS_POINTS = {
  elements: [
    {
      type: "node", id: 101, lat: 1.05, lon: 104.135,
      tags: { power: "plant", name: "PLTU Tanjung Kasam", "plant:source": "coal", "plant:output:electricity": "110 MW", operator: "PLN Batam" },
    },
    {
      type: "way", id: 202,
      geometry: closed([[1.0905, 104.1195], [1.0905, 104.1215], [1.0890, 104.1215], [1.0890, 104.1195]]),
      tags: { power: "substation", name: "GI Kabil", voltage: "150000;20000", operator: "PLN" },
    },
    { type: "node", id: 303, lat: 1.121, lon: 104.103, tags: { telecom: "data_center", name: "Nongsa D1", operator: "DCI" } },
    {
      type: "way", id: 404,
      geometry: closed([[1.061, 104.069], [1.061, 104.072], [1.058, 104.072], [1.058, 104.069]]),
      tags: { man_made: "water_works", name: "IPA Duriangkang" },
    },
    {
      // Multipolygon reservoir made of two outer ways that must be stitched.
      type: "relation", id: 505,
      members: [
        { type: "way", ref: 1, role: "outer", geometry: g([[1.03, 104.04], [1.03, 104.07], [1.05, 104.07]]) },
        { type: "way", ref: 2, role: "outer", geometry: g([[1.05, 104.07], [1.05, 104.04], [1.03, 104.04]]) },
      ],
      tags: { natural: "water", water: "reservoir", name: "Waduk Duriangkang" },
    },
    {
      // Tiny unnamed pond tagged reservoir → filtered out.
      type: "way", id: 606,
      geometry: closed([[1.085, 104.13], [1.085, 104.1301], [1.0849, 104.1301], [1.0849, 104.13]]),
      tags: { water: "reservoir" },
    },
    { type: "node", id: 707, lat: 1.045, lon: 104.055, tags: { waterway: "dam", name: "Duriangkang Dam" } },
    // 30+ km away → outside a 15 km radius
    { type: "node", id: 808, lat: 1.35, lon: 104.116, tags: { power: "plant", name: "Far Plant" } },
    // Unrelated tag → ignored
    { type: "node", id: 909, lat: 1.083, lon: 104.117, tags: { amenity: "cafe", name: "Kopi" } },
  ],
};

export const OVERPASS_LINES = {
  elements: [
    {
      type: "way", id: 1001,
      // passes ~1.5 km north of the site, with a clipped (null) gap
      geometry: g([[1.098, 104.09], [1.098, 104.11], null, [1.098, 104.14], [1.098, 104.15]]),
      tags: { power: "line", name: "SUTT 150kV Kabil", voltage: "150000", circuits: "2" },
    },
    {
      type: "way", id: 1002, // same line, farther segment → deduped
      geometry: g([[1.12, 104.09], [1.12, 104.14]]),
      tags: { power: "line", name: "SUTT 150kV Kabil", voltage: "150000" },
    },
    {
      type: "way", id: 1003,
      geometry: g([[1.15, 104.16], [1.20, 104.30]]),
      tags: { power: "cable", location: "underwater", voltage: "150000", name: "Batam–Bintan interconnector" },
    },
    {
      type: "way", id: 1004,
      geometry: g([[1.07, 104.0], [1.07, 104.2]]), // crosses through the site latitude band south of it
      tags: { waterway: "river", name: "Sungai Kabil" },
    },
  ],
};

export const BOUNDARY_PASS1 = {
  elements: [
    { type: "way", id: 11, bounds: { minlat: 1.075, minlon: 104.108, maxlat: 1.09, maxlon: 104.124 }, tags: { landuse: "industrial", name: "Kabil Industrial Estate" } },
    { type: "relation", id: 12, bounds: { minlat: 0.95, minlon: 103.85, maxlat: 1.2, maxlon: 104.2 }, tags: { place: "island", name: "Batam" } },
    { type: "way", id: 13, bounds: { minlat: 1.0815, minlon: 104.1155, maxlat: 1.0825, maxlon: 104.1165 }, tags: { power: "substation" } },
  ],
};

export const BOUNDARY_PASS2 = {
  elements: [
    {
      type: "way", id: 11,
      geometry: closed([[1.09, 104.108], [1.09, 104.124], [1.075, 104.124], [1.075, 104.108]]),
      tags: { landuse: "industrial", name: "Kabil Industrial Estate" },
    },
    {
      type: "way", id: 13,
      geometry: closed([[1.0825, 104.1155], [1.0825, 104.1165], [1.0815, 104.1165], [1.0815, 104.1155]]),
      tags: { power: "substation" },
    },
  ],
};

export const TG_LANDING = {
  type: "FeatureCollection",
  features: [
    { type: "Feature", properties: { id: "batam-indonesia", name: "Batam, Indonesia" }, geometry: { type: "Point", coordinates: [104.0247, 1.1447] } },
    { type: "Feature", properties: { id: "changi-north-singapore", name: "Changi North, Singapore" }, geometry: { type: "Point", coordinates: [103.9876, 1.3919] } },
    { type: "Feature", properties: { id: "jakarta-indonesia", name: "Jakarta, Indonesia" }, geometry: { type: "Point", coordinates: [106.8, -6.1] } },
  ],
};

export const TG_CABLES = {
  type: "FeatureCollection",
  features: [
    {
      type: "Feature", properties: { id: "b2js", name: "B2JS (Jakarta-Bangka-Bintan-Batam-Singapore)", color: "#3fa9f5" },
      geometry: { type: "MultiLineString", coordinates: [[[104.0247, 1.1447], [104.0, 1.25], [103.9876, 1.3919]]] },
    },
    {
      type: "Feature", properties: { id: "far-atlantic", name: "Far Atlantic" },
      geometry: { type: "MultiLineString", coordinates: [[[-30, 40], [-10, 45]]] },
    },
  ],
};

export const TG_DETAILS: Record<string, unknown> = {
  "landing-point/batam-indonesia": { id: "batam-indonesia", cables: [{ id: "b2js", name: "B2JS" }, { id: "bcs", name: "BCS North-Phase 2" }] },
  "cable/b2js": { id: "b2js", rfs: "2017 December", length: "1,300 km", owners: "Telkom Indonesia" },
};

export const NOMINATIM_KABIL = [
  {
    lat: "1.0822", lon: "104.1161", display_name: "Kabil Industrial Estate, Batam, Riau Islands, Indonesia",
    osm_type: "way", osm_id: 11,
    geojson: { type: "Polygon", coordinates: [[[104.108, 1.09], [104.124, 1.09], [104.124, 1.075], [104.108, 1.075], [104.108, 1.09]]] },
  },
];

export const MY_MAPS_KML = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>New site</name><Folder><name>Untitled layer</name>
<Placemark><name>Parcel boundary</name><Polygon><outerBoundaryIs><LinearRing><tessellate>1</tessellate><coordinates>
104.110,1.085,0 104.120,1.085,0 104.120,1.078,0 104.110,1.078,0 104.110,1.085,0
</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>
<Placemark><name>Main gate</name><Point><coordinates>104.115,1.0852,0</coordinates></Point></Placemark>
</Folder></Document></kml>`;
