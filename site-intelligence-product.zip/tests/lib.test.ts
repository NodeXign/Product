import { test } from "node:test";
import assert from "node:assert/strict";
import {
  haversineKm, pointInRing, pointToRingKm, lineToRingKm, ringAreaHa, ringCentroid,
  squareRing, circleRing, translateRing, simplifyLine,
} from "../lib/geo";
import { parseCoordinates, parseGoogleMapsUrl, classifyInput, myMapsMid } from "../lib/parseInput";
import { parseKml, parseGeoJson } from "../lib/kml";
import type { LatLng } from "../lib/types";

const near = (a: number, b: number, tol: number) => assert.ok(Math.abs(a - b) <= tol, `${a} !≈ ${b} (±${tol})`);

test("haversine: Singapore → Batam ferry terminal ~ 20 km", () => {
  near(haversineKm([1.2644, 103.8222], [1.1557, 104.0110]), 24.2, 1.0);
});

test("square ring has the requested area and centroid", () => {
  const c: LatLng = [1.082, 104.116];
  const sq = squareRing(c, 50);
  near(ringAreaHa(sq), 50, 0.05);
  const cen = ringCentroid(sq);
  near(cen[0], c[0], 1e-6);
  near(cen[1], c[1], 1e-6);
});

test("circle ring area ≈ πr²", () => {
  near(ringAreaHa(circleRing([45, 10], 1, 128)), Math.PI * 100, 1.0);
});

test("point in / out of ring and distance to edge", () => {
  const sq = squareRing([0, 0], 400); // 2 km × 2 km
  assert.equal(pointInRing([0, 0], sq), true);
  assert.equal(pointToRingKm([0, 0], sq), 0);
  // 3 km east of centre → 2 km from the east edge
  const east: LatLng = [0, 3 / 111.195];
  near(pointToRingKm(east, sq), 2, 0.01);
});

test("line distance: crossing line is 0, parallel line measured to edge", () => {
  const sq = squareRing([0, 0], 400);
  const crossing: LatLng[] = [[0, -0.05], [0, 0.05]];
  assert.equal(lineToRingKm(crossing, sq).km, 0);
  const y = 4 / 111.195; // 4 km north of centre → 3 km from north edge
  const parallel: LatLng[] = [[y, -0.1], [y, 0.1]];
  const r = lineToRingKm(parallel, sq);
  near(r.km, 3, 0.02);
  near(r.nearest[0], y, 1e-6);
});

test("translateRing keeps area", () => {
  const sq = squareRing([1, 104], 30);
  const moved = translateRing(sq, [1, 104], [10, 104]);
  near(ringAreaHa(moved), 30, 0.1);
});

test("simplifyLine removes collinear points", () => {
  const line: LatLng[] = Array.from({ length: 50 }, (_, i) => [0, i * 0.001]);
  assert.equal(simplifyLine(line, 0.01).length, 2);
});

test("parseCoordinates: decimal, hemisphere, DMS, Chinese comma", () => {
  assert.deepEqual(parseCoordinates("1.0822, 104.1161"), [1.0822, 104.1161]);
  assert.deepEqual(parseCoordinates("1.0822 104.1161"), [1.0822, 104.1161]);
  assert.deepEqual(parseCoordinates("1.0822，104.1161"), [1.0822, 104.1161]);
  assert.deepEqual(parseCoordinates("33.86S, 151.21E"), [-33.86, 151.21]);
  const d = parseCoordinates(`1°04'56.0"N 104°06'58.0"E`)!;
  near(d[0], 1.082222, 1e-5);
  near(d[1], 104.116111, 1e-5);
  assert.equal(parseCoordinates("Kabil Industrial Estate"), null);
  assert.equal(parseCoordinates("200, 500"), null);
});

test("parseGoogleMapsUrl: pin beats viewport", () => {
  const url =
    "https://www.google.com/maps/place/Kabil+Industrial+Estate/@1.0901,104.1002,14z/data=!3m1!4b1!4m6!3m5!1s0x0:0x0!8m2!3d1.0822!4d104.1161!16s";
  const r = parseGoogleMapsUrl(url);
  assert.deepEqual(r.center, [1.0822, 104.1161]);
  assert.equal(r.precise, true);
  assert.equal(r.placeName, "Kabil Industrial Estate");
});

test("parseGoogleMapsUrl: viewport only, query, path coords", () => {
  const v = parseGoogleMapsUrl("https://www.google.com/maps/@1.0901,104.1002,14z");
  assert.deepEqual(v.center, [1.0901, 104.1002]);
  assert.equal(v.precise, false);
  assert.deepEqual(parseGoogleMapsUrl("https://www.google.com/maps/search/?api=1&query=0.9594,104.0617").center, [0.9594, 104.0617]);
  assert.deepEqual(parseGoogleMapsUrl("https://maps.google.com/?q=1.14,104.17").center, [1.14, 104.17]);
  assert.deepEqual(parseGoogleMapsUrl("https://www.google.com/maps/place/1.0822,104.1161").center, [1.0822, 104.1161]);
  const dms = parseGoogleMapsUrl(
    "https://www.google.com/maps/place/1%C2%B004'56.0%22N+104%C2%B006'58.0%22E/@1.08,104.11,17z",
  );
  near(dms.center![0], 1.082222, 1e-5);
});

test("classifyInput routes every input type", () => {
  assert.equal(classifyInput("1.08, 104.11").type, "coords");
  assert.equal(classifyInput("https://maps.app.goo.gl/AbCd123").type, "google-short");
  assert.equal(classifyInput("https://www.google.com/maps/d/viewer?mid=1AbC_xyz&ll=1,104&z=12").type, "my-maps");
  assert.equal(myMapsMid("https://www.google.com/maps/d/u/0/edit?mid=1AbC_xyz"), "1AbC_xyz");
  assert.equal(classifyInput("https://www.google.com/maps/@1.0,104.0,12z").type, "google-maps");
  assert.equal(classifyInput("Tanjung Sauh, Batam").type, "text");
  assert.equal(classifyInput('<?xml version="1.0"?><kml xmlns="x"></kml>').type, "kml");
  assert.equal(classifyInput('{"type":"Feature","geometry":null}').type, "geojson");
});

test("parseKml: polygon in a folder, point, linestring", () => {
  const kml = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Sites</name>
<Folder><name>Layer</name>
<Placemark><name>Plot A</name><Polygon><outerBoundaryIs><LinearRing><coordinates>
 104.10,1.08,0 104.12,1.08,0 104.12,1.09,0 104.10,1.09,0 104.10,1.08,0
</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>
<Placemark><name>Gate</name><Point><coordinates>104.11,1.085,0</coordinates></Point></Placemark>
<Placemark><name>Road</name><LineString><coordinates>104.1,1.0 104.2,1.1</coordinates></LineString></Placemark>
</Folder></Document></kml>`;
  const pms = parseKml(kml);
  assert.equal(pms.length, 3);
  assert.equal(pms[0].name, "Plot A");
  assert.equal(pms[0].ring!.length, 4);
  near(pms[0].center[0], 1.085, 1e-4);
  assert.deepEqual(pms[1].center, [1.085, 104.11]);
  assert.equal(pms[2].line!.length, 2);
});

test("parseGeoJson: polygon feature", () => {
  const gj = JSON.stringify({
    type: "FeatureCollection",
    features: [{ type: "Feature", properties: { name: "P" }, geometry: { type: "Polygon", coordinates: [[[104, 1], [104.01, 1], [104.01, 1.01], [104, 1]]] } }],
  });
  const pms = parseGeoJson(gj);
  assert.equal(pms[0].ring!.length, 3);
});
