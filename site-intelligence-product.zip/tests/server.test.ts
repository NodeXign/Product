import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import * as F from "./fixtures";

// ---- fetch mock --------------------------------------------------------------
type Handler = (url: string, init?: RequestInit) => Response | Promise<Response>;
let handler: Handler;
const calls: string[] = [];
globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
  const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
  calls.push(url);
  return handler(url, init);
}) as typeof fetch;

const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json" } });
const overpassBody = (init?: RequestInit) => decodeURIComponent(String(init?.body ?? "").replace(/^data=/, "").replace(/\+/g, " "));

function upstream(opts: { overpassDown?: boolean } = {}): Handler {
  return (url, init) => {
    if (url.includes("/api/interpreter")) {
      if (opts.overpassDown) return new Response("busy", { status: 429 });
      const q = overpassBody(init);
      if (q.includes("is_in(")) return json(F.BOUNDARY_PASS1);
      if (q.includes("way(id:")) return json(F.BOUNDARY_PASS2);
      if (q.includes('"power"~"^(line|cable)$"')) return json(F.OVERPASS_LINES);
      if (q.includes('"power"~"^(plant|substation)$"')) return json(F.OVERPASS_POINTS);
      return json({ elements: [] });
    }
    if (url.endsWith("landing-point/landing-point-geo.json")) return json(F.TG_LANDING);
    if (url.endsWith("cable/cable-geo.json")) return json(F.TG_CABLES);
    const m = /api\/v3\/(.+)\.json$/.exec(url);
    if (m && F.TG_DETAILS[m[1]]) return json(F.TG_DETAILS[m[1]]);
    if (m) return new Response("not found", { status: 404 });
    if (url.startsWith("https://nominatim.openstreetmap.org/search")) return json(F.NOMINATIM_KABIL);
    if (url.startsWith("https://maps.app.goo.gl/kabil")) {
      return new Response(null, { status: 302, headers: { location: "https://consent.google.com/ml?continue=" + encodeURIComponent("https://www.google.com/maps/place/Kabil/@1.09,104.10,14z/data=!4m2!3m1!8m2!3d1.0822!4d104.1161") } });
    }
    if (url.startsWith("https://consent.google.com/")) {
      return new Response(null, { status: 302, headers: { location: "https://www.google.com/maps/place/Kabil" } });
    }
    if (url.startsWith("https://maps.app.goo.gl/evil")) {
      return new Response(null, { status: 302, headers: { location: "http://169.254.169.254/latest/meta-data" } });
    }
    if (url.startsWith("https://www.google.com/maps/d/kml?mid=PUBLIC")) return new Response(F.MY_MAPS_KML, { status: 200 });
    if (url.startsWith("https://www.google.com/maps/d/kml?mid=PRIVATE")) return new Response("<html>sign in</html>", { status: 200 });
    return new Response(`unmocked ${url}`, { status: 599 });
  };
}

beforeEach(() => {
  handler = upstream();
  calls.length = 0;
  delete process.env.GOOGLE_MAPS_API_KEY;
});

// ---- scan --------------------------------------------------------------------
test("runScan classifies, measures, dedupes and filters by radius", async () => {
  const { runScan } = await import("../lib/server/scan");
  const r = await runScan(F.SITE_RING, 15);
  assert.deepEqual(r.status, { power: { ok: true }, water: { ok: true }, telecom: { ok: true } });

  const byKind = (k: string) => r.features.filter((f) => f.kind === k);
  // power
  const plant = byKind("power_plant");
  assert.equal(plant.length, 1, "far plant excluded");
  assert.equal(plant[0].attrs.capacity, "110 MW");
  assert.equal(plant[0].attrs.source, "coal");
  assert.equal(plant[0].source.url, "https://www.openstreetmap.org/node/101");
  const sub = byKind("substation")[0];
  assert.equal(sub.attrs.voltage, "150 / 20 kV");
  assert.ok(Math.abs(sub.distanceKm - 0.426) < 0.01, `substation ${sub.distanceKm}`); // NE site corner → SW substation corner
  const lines = byKind("power_line");
  assert.equal(lines.length, 1, "same-name line segments deduped");
  assert.ok(lines[0].distanceKm > 1.3 && lines[0].distanceKm < 1.8, `line ${lines[0].distanceKm}`);
  assert.equal(lines[0].lines!.length, 2, "null gap splits the polyline");
  assert.equal(byKind("submarine_power_cable").length, 1);
  // telecom
  assert.equal(byKind("data_center")[0].name, "Nongsa D1");
  const lp = byKind("landing_point");
  assert.deepEqual(lp.map((x) => x.name), ["Batam, Indonesia", "Changi North, Singapore"], "Jakarta excluded");
  assert.match(lp[0].attrs.cables, /B2JS/);
  const cable = byKind("submarine_cable");
  assert.equal(cable.length, 1, "far cable rejected");
  assert.equal(cable[0].attrs.rfs, "2017 December");
  assert.equal(cable[0].source.url, "https://www.submarinecablemap.com/submarine-cable/b2js");
  // water
  const res = byKind("reservoir");
  assert.equal(res.length, 1, "tiny unnamed pond dropped, stitched multipolygon kept");
  assert.equal(res[0].name, "Waduk Duriangkang");
  assert.equal(byKind("water_works")[0].name, "IPA Duriangkang");
  assert.equal(byKind("dam").length, 1);
  assert.equal(byKind("river")[0].name, "Sungai Kabil");
  assert.ok(byKind("river")[0].distanceKm < 1, "river south of site");
  // nothing unclassified, sorted, every feature sourced
  assert.ok(!r.features.some((f) => f.name === "Kopi"));
  for (let i = 1; i < r.features.length; i++) assert.ok(r.features[i - 1].distanceKm <= r.features[i].distanceKm);
  assert.ok(r.features.every((f) => f.source.provider && f.source.license));
  assert.ok(Math.abs(r.site.areaHa - 50) < 0.5);
});

test("runScan degrades gracefully when Overpass is down", async () => {
  handler = upstream({ overpassDown: true });
  const { runScan } = await import("../lib/server/scan");
  const r = await runScan(F.SITE_RING, 15);
  assert.equal(r.status.power.ok, false);
  assert.match(r.status.power.message!, /HTTP 429/);
  assert.equal(r.status.telecom.ok, false, "data centres come from OSM");
  assert.ok(r.features.some((f) => f.kind === "landing_point"), "cables still returned");
  assert.ok(calls.filter((c) => c.includes("interpreter")).length >= 6, "tried every mirror for both queries");
});

test("voltage and classify helpers", async () => {
  const { voltage, classify } = await import("../lib/server/scan");
  assert.deepEqual(voltage("500000;150000;150000"), { label: "500 / 150 kV", max: 500 });
  assert.deepEqual(voltage("33 kV"), { label: "33 kV", max: 33 });
  assert.equal(voltage("unknown"), null);
  assert.equal(classify({ man_made: "water_works", name: "Tuas SWRO Plant" }), "desalination");
  assert.equal(classify({ power: "cable", location: "underground" }), "power_line");
  assert.equal(classify({ building: "data_center" }), "data_center");
});

// ---- boundary ----------------------------------------------------------------
test("detectBoundaries drops huge areas and ranks containing parcels first", async () => {
  const { detectBoundaries } = await import("../lib/server/boundary");
  const c = await detectBoundaries(F.SITE_CENTER);
  assert.equal(c.length, 2, "Batam island (huge bbox) skipped");
  assert.equal(c[0].tag, "power=substation", "smallest containing polygon first");
  assert.equal(c[0].containsPoint, true);
  assert.equal(c[1].name, "Kabil Industrial Estate");
  assert.ok(c[1].areaHa > 250 && c[1].areaHa < 350, `estate ${c[1].areaHa} ha`);
  assert.equal(c[1].source.url, "https://www.openstreetmap.org/way/11");
});

// ---- resolve -----------------------------------------------------------------
test("resolve: coordinates, short link via consent page, My Maps KML, address", async () => {
  const { resolveInput } = await import("../lib/server/resolve");

  const a = await resolveInput("0.9594, 104.0617");
  assert.deepEqual(a.site.center, [0.9594, 104.0617]);
  assert.equal(a.site.kind, "coordinates");

  const b = await resolveInput("https://maps.app.goo.gl/kabil123");
  assert.deepEqual(b.site.center, [1.0822, 104.1161], "pin coordinates from the expanded URL");
  assert.equal(b.site.name, "Kabil");
  assert.equal(b.site.source.url, "https://maps.app.goo.gl/kabil123", "provenance keeps the link the user gave");

  const c = await resolveInput("https://www.google.com/maps/d/viewer?mid=PUBLIC&ll=1.08,104.11&z=15");
  assert.equal(c.site.kind, "my-maps");
  assert.equal(c.site.name, "Parcel boundary");
  assert.equal(c.site.boundary!.length, 4);
  assert.equal(c.site.extras!.length, 1);
  assert.equal(c.site.note, "multi:2");

  await assert.rejects(resolveInput("https://www.google.com/maps/d/viewer?mid=PRIVATE"), /Anyone with this link/);

  const d = await resolveInput("Kabil Industrial Estate");
  assert.equal(d.site.source.provider, "OpenStreetMap Nominatim");
  assert.equal(d.site.boundary!.length, 4, "parcel polygon from Nominatim");
});

test("resolve: short-link redirects never leave Google hosts", async () => {
  const { resolveInput } = await import("../lib/server/resolve");
  await assert.rejects(resolveInput("https://maps.app.goo.gl/evil"), /didn't lead to a Google Maps place/);
  assert.ok(!calls.some((c) => c.includes("169.254.169.254")), "metadata address never requested");
});

// ---- routes ------------------------------------------------------------------
const post = (body: unknown) => new Request("http://x/api", { method: "POST", body: JSON.stringify(body), headers: { "content-type": "application/json" } });

test("API routes validate input", async () => {
  const scan = await import("../app/api/scan/route");
  assert.equal((await scan.POST(post({ ring: [[1, 104]] }))).status, 400);
  assert.equal((await scan.POST(post({ ring: [[1, 104], [1, 999], [2, 104]] }))).status, 400);
  const huge = [[0, 100], [0, 101], [1, 101], [1, 100]];
  const r = await scan.POST(post({ ring: huge }));
  assert.equal(r.status, 400);
  assert.match((await r.json()).error, /100 km²/);
  const ok = await scan.POST(post({ ring: F.SITE_RING, radiusKm: 999 }));
  assert.equal(ok.status, 200);
  assert.equal((await ok.json()).radiusKm, 50, "radius clamped");

  const resolve = await import("../app/api/resolve/route");
  assert.equal((await resolve.POST(post({ input: "" }))).status, 400);
  assert.equal((await resolve.POST(post({ input: "https://www.google.com/maps/d/viewer?mid=PRIVATE" }))).status, 422);

  const boundary = await import("../app/api/boundary/route");
  assert.equal((await boundary.POST(post({ center: [91, 0] }))).status, 400);
  assert.equal((await boundary.POST(post({ center: F.SITE_CENTER }))).status, 200);
});
