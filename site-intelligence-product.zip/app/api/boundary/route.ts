import { detectBoundaries } from "@/lib/server/boundary";
import { errMessage, UpstreamError } from "@/lib/server/http";
import { asLatLng, bad } from "@/lib/server/validate";

export const runtime = "nodejs";
export const maxDuration = 60;

/** POST { center: [lat, lng] } → { candidates: BoundaryCandidate[] } */
export async function POST(req: Request) {
  let body: { center?: unknown };
  try {
    body = await req.json();
  } catch {
    return bad("Send JSON: { center: [lat, lng] }");
  }
  const center = asLatLng(body.center);
  if (!center) return bad("center must be [lat, lng].");
  try {
    return Response.json({ candidates: await detectBoundaries(center) });
  } catch (e) {
    if (e instanceof UpstreamError) return bad(`${e.provider}: ${e.message}`, 502);
    return bad(errMessage(e), 500);
  }
}
