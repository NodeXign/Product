import { fetchWithTimeout } from "@/lib/server/http";
import { overpassEndpoints } from "@/lib/server/overpass";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function ping(url: string, init?: RequestInit) {
  const t0 = Date.now();
  try {
    const res = await fetchWithTimeout(url, { ...init, timeoutMs: 6000 });
    return { ok: res.status < 500, status: res.status, ms: Date.now() - t0 };
  } catch (e) {
    return { ok: false, error: (e as Error).message, ms: Date.now() - t0 };
  }
}

/** Which providers are configured and reachable from this deployment. */
export async function GET() {
  const [overpass, cables, nominatim] = await Promise.all([
    ping(overpassEndpoints()[0].replace(/interpreter$/, "status")),
    ping("https://www.submarinecablemap.com/api/v3/landing-point/landing-point-geo.json", { method: "HEAD" }),
    ping("https://nominatim.openstreetmap.org/status?format=json"),
  ]);
  return Response.json({
    googleTilesKey: Boolean(process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY),
    googleGeocodingKey: Boolean(process.env.GOOGLE_MAPS_API_KEY),
    upstreams: { overpass, cables, nominatim },
    time: new Date().toISOString(),
  });
}
