import { resolveInput, InputError } from "@/lib/server/resolve";
import { errMessage, UpstreamError } from "@/lib/server/http";
import { bad } from "@/lib/server/validate";

export const runtime = "nodejs";
export const maxDuration = 30;

/** POST { input: string, lang?: "en" | "zh" } → { site, alternatives } */
export async function POST(req: Request) {
  let body: { input?: unknown; lang?: unknown };
  try {
    body = await req.json();
  } catch {
    return bad("Send JSON: { input }");
  }
  const input = typeof body.input === "string" ? body.input.trim() : "";
  if (!input) return bad("Paste a link, coordinates or an address.");
  if (input.length > 2_000_000) return bad("Input is too large (max 2 MB).", 413);
  const lang = body.lang === "zh" ? "zh" : "en";

  try {
    return Response.json(await resolveInput(input, lang));
  } catch (e) {
    if (e instanceof InputError) return bad(e.message, 422);
    if (e instanceof UpstreamError) return bad(`${e.provider}: ${e.message}`, 502);
    return bad(errMessage(e), 500);
  }
}
