import { runScan } from "@/lib/server/scan";
import { errMessage } from "@/lib/server/http";
import { asRing, bad } from "@/lib/server/validate";

export const runtime = "nodejs";
export const maxDuration = 60;

/** POST { ring: [lat, lng][], radiusKm?: number } → ScanResult */
export async function POST(req: Request) {
  let body: { ring?: unknown; radiusKm?: unknown; cableRadiusKm?: unknown };
  try {
    body = await req.json();
  } catch {
    return bad("Send JSON: { ring, radiusKm }");
  }
  const { ring, error } = asRing(body.ring);
  if (!ring) return bad(error!);
  const radiusKm = Math.min(50, Math.max(1, Number(body.radiusKm) || 15));
  const cableRadiusKm =
    body.cableRadiusKm === undefined ? undefined : Math.min(300, Math.max(10, Number(body.cableRadiusKm) || 100));
  try {
    return Response.json(await runScan(ring, radiusKm, cableRadiusKm));
  } catch (e) {
    return bad(errMessage(e), 500);
  }
}
