"use client";

import dynamic from "next/dynamic";

// Leaflet needs `window`, so the whole workspace renders client-side.
const SiteApp = dynamic(() => import("@/components/SiteApp"), {
  ssr: false,
  loading: () => (
    <div className="si-boot" role="status">
      <span className="si-boot__mark" />
      Site Intelligence · 场地情报
    </div>
  ),
});

export default function Page() {
  return <SiteApp />;
}
