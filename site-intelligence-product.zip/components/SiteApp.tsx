"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { BoundaryCandidate, Category, Feature, LatLng, Pin, Project, ResolvedSite, Ring, ScanResult } from "@/lib/types";
import { t, detectLang, type Lang } from "@/lib/i18n";
import { circleRing, ringAreaHa, ringCentroid, ringPerimeterKm, squareRing, fmtCoord } from "@/lib/geo";
import { readiness } from "@/lib/readiness";
import { batamProject } from "@/lib/batam";
import { loadProjects, saveProjects, newId, shareUrl, projectFromHash, download, slug, toGeoJson } from "@/lib/store";
import { HAS_GOOGLE, type Basemap, type Provider } from "@/lib/basemaps";
import MapView, { type Focus } from "./MapView";
import { LocateStep, BoundaryStep, ScanStep, type Notice } from "./Steps";
import { StudyCard, SourcesModal, ProjectsModal, ReportModal } from "./Dialogs";
import { Icon } from "./Icon";
import { CATEGORY_COLOR } from "./glyphs";
import { CATEGORY_LABEL } from "@/lib/i18n";

const DRAFT_KEY = "site-intel:draft:v1";
const LANG_KEY = "site-intel:lang";

type ResolveResponse = { site: ResolvedSite; alternatives: ResolvedSite[] };

class ApiError extends Error {
  constructor(message: string, public status: number) {
    super(message);
  }
}

async function api<T>(path: string, body: unknown): Promise<T> {
  let r: Response;
  try {
    r = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  } catch {
    throw new ApiError("network", 0);
  }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(j.error || `HTTP ${r.status}`, r.status);
  return j as T;
}

function emptyProject(radiusKm = 15): Project {
  return { id: newId(), name: "", center: [18, 40], ring: [], radiusKm, updatedAt: new Date().toISOString() };
}

const sameRing = (a: Ring, b: Ring) => a.length === b.length && a.every((p, i) => p[0] === b[i][0] && p[1] === b[i][1]);

export default function SiteApp() {
  const [lang, setLang] = useState<Lang>("en");
  const [basemap, setBasemap] = useState<Basemap>("hybrid");
  const [provider, setProvider] = useState<Provider>(HAS_GOOGLE ? "google" : "esri");
  const [project, setProject] = useState<Project>(emptyProject);
  const [saved, setSaved] = useState<Project[]>([]);
  const [dirty, setDirty] = useState(false);

  const [input, setInput] = useState("");
  const [resolving, setResolving] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const [alternatives, setAlternatives] = useState<ResolvedSite[]>([]);

  const [candidates, setCandidates] = useState<BoundaryCandidate[] | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [detectErr, setDetectErr] = useState<string | null>(null);
  const [drawing, setDrawing] = useState(false);

  const [scanning, setScanning] = useState(false);
  const [scanErr, setScanErr] = useState<string | null>(null);

  const [layers, setLayers] = useState<Record<Category, boolean>>({ power: true, telecom: true, water: true });
  const [showRings, setShowRings] = useState(true);
  const [focus, setFocus] = useState<Focus | null>(null);
  const [highlight, setHighlight] = useState<string | null>(null);
  const [modal, setModal] = useState<null | "projects" | "report" | "sources">(null);
  const [toast, setToast] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(true);

  const hasSite = project.ring.length >= 3;
  const focusTo = useCallback((f: Omit<Focus, "nonce">) => setFocus({ ...f, nonce: Date.now() + Math.random() }), []);
  const say = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((m) => (m === msg ? null : m)), 2200);
  }, []);

  // ---- boot: language, saved projects, shared link or draft --------------------------
  const booted = useRef(false);
  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    let l: Lang = detectLang();
    try {
      const stored = localStorage.getItem(LANG_KEY);
      if (stored === "en" || stored === "zh") l = stored;
    } catch {}
    setLang(l);
    setSaved(loadProjects());

    const shared = projectFromHash(location.hash);
    let start: Project | null = shared;
    if (!start) {
      try {
        const d = localStorage.getItem(DRAFT_KEY);
        if (d) start = JSON.parse(d) as Project;
      } catch {}
    }
    if (start && start.ring?.length >= 3) {
      setProject(start);
      setInput(start.input && start.input.length < 400 ? start.input : "");
      setDirty(Boolean(shared));
      setTimeout(() => focusTo({ bounds: start!.ring }), 300);
    }
  }, [focusTo]);

  useEffect(() => {
    document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
    document.title = `${t(lang, "appName")} · ${project.name || t(lang, "appTag")}`;
    try {
      localStorage.setItem(LANG_KEY, lang);
    } catch {}
  }, [lang, project.name]);

  // Autosave the working draft so a reload never loses a boundary.
  useEffect(() => {
    if (!hasSite) return;
    const id = setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(project));
      } catch {}
    }, 500);
    return () => clearTimeout(id);
  }, [project, hasSite]);

  const update = useCallback((patch: Partial<Project>, markDirty = true) => {
    setProject((p) => ({ ...p, ...patch, updatedAt: new Date().toISOString() }));
    if (markDirty) setDirty(true);
  }, []);

  // ---- step 2: boundary ----------------------------------------------------------------
  const detect = useCallback(async (center: LatLng) => {
    setDetecting(true);
    setDetectErr(null);
    try {
      const r = await api<{ candidates: BoundaryCandidate[] }>("/api/boundary", { center });
      setCandidates(r.candidates);
    } catch (e) {
      setCandidates([]);
      setDetectErr((e as Error).message === "network" ? t(lang, "errNetwork") : (e as Error).message);
    } finally {
      setDetecting(false);
    }
  }, [lang]);

  // ---- step 1: locate ------------------------------------------------------------------
  const applySite = useCallback(
    (site: ResolvedSite, inputLabel: string) => {
      const ring = site.boundary ?? squareRing(site.center, 20);
      const extras: Pin[] = (site.extras ?? []).map((x, i) => ({
        id: `extra-${i}`,
        label: { en: x.name, zh: x.name },
        pos: x.center,
        original: x.center,
        type: x.boundary ? "candidate" : "reference",
        areaHa: x.boundary ? Math.round(ringAreaHa(x.boundary)) : undefined,
      }));
      setProject((p) => ({
        id: newId(),
        name: site.name.length > 80 ? `${site.name.slice(0, 77)}…` : site.name,
        input: inputLabel,
        origin: site.source,
        center: site.center,
        ring,
        pins: extras,
        radiusKm: p.radiusKm,
        updatedAt: new Date().toISOString(),
      }));
      setDirty(true);
      setHighlight(null);
      setScanErr(null);
      const info: string[] = [t(lang, "resolvedVia", { provider: site.source.provider })];
      if (site.note === "approx") info.push(t(lang, "approxPin"));
      if (site.note?.startsWith("multi:")) info.push(t(lang, "multiPlacemarks", { n: site.note.split(":")[1] }));
      setNotice({ kind: "info", text: info.join(" ") });
      if (site.boundary) {
        setCandidates(null);
        focusTo({ bounds: ring });
      } else {
        focusTo({ pos: site.center, zoom: 15 });
        detect(site.center);
      }
    },
    [lang, focusTo, detect],
  );

  const locate = useCallback(
    async (text?: string, label?: string) => {
      const value = (text ?? input).trim();
      if (!value) return setNotice({ kind: "error", text: t(lang, "errEmpty") });
      if (label) setInput(label);
      setResolving(true);
      setNotice(null);
      setAlternatives([]);
      setCandidates(null);
      setDetectErr(null);
      try {
        const r = await api<ResolveResponse>("/api/resolve", { input: value, lang });
        applySite(r.site, label ?? value);
        setAlternatives(r.alternatives);
      } catch (e) {
        const err = e as ApiError;
        setNotice({
          kind: "error",
          text: err.status === 0 ? t(lang, "errNetwork") : t(lang, "errResolve"),
          detail: err.status === 0 ? undefined : err.message,
        });
      } finally {
        setResolving(false);
      }
    },
    [input, lang, applySite],
  );

  const centre = hasSite ? ringCentroid(project.ring) : project.center;

  const onRingChange = useCallback((ring: Ring, final: boolean) => {
    setProject((p) => ({ ...p, ring, updatedAt: new Date().toISOString() }));
    if (final) setDirty(true);
  }, []);

  const onPinMove = useCallback((id: string, pos: LatLng, final: boolean) => {
    setProject((p) => ({ ...p, pins: p.pins?.map((x) => (x.id === id ? { ...x, pos } : x)) }));
    if (final) setDirty(true);
  }, []);

  // ---- step 3: scan -----------------------------------------------------------------------
  const runScan = useCallback(async () => {
    if (!hasSite) return setScanErr(t(lang, "errNoBoundary"));
    setScanning(true);
    setScanErr(null);
    try {
      const r = await api<ScanResult>("/api/scan", { ring: project.ring, radiusKm: project.radiusKm });
      update({ scan: r });
      setLayers({ power: true, telecom: true, water: true });
      focusTo({ bounds: circleRing(ringCentroid(project.ring), Math.min(project.radiusKm, 15), 16) });
    } catch (e) {
      const err = e as ApiError;
      setScanErr(err.status === 0 ? t(lang, "errNetwork") : err.message);
    } finally {
      setScanning(false);
    }
  }, [hasSite, lang, project.ring, project.radiusKm, update, focusTo]);

  const focusFeature = useCallback(
    (f: Feature) => {
      setHighlight(f.id);
      setLayers((l) => ({ ...l, [f.category]: true }));
      focusTo({ pos: f.pos, zoom: f.distanceKm > 20 ? 11 : 15, featureId: f.id });
    },
    [focusTo],
  );

  const stale = Boolean(project.scan && !sameRing(project.scan.site.ring, project.ring));
  const ready = useMemo(() => (project.scan ? readiness(project.scan) : null), [project.scan]);
  const stats = useMemo(
    () =>
      hasSite
        ? { areaHa: ringAreaHa(project.ring), perimeterKm: ringPerimeterKm(project.ring), centroid: ringCentroid(project.ring), corners: project.ring.length }
        : null,
    [hasSite, project.ring],
  );

  // ---- projects --------------------------------------------------------------------------
  const allProjects = useMemo(() => [batamProject(), ...saved], [saved]);

  const openProject = (p: Project) => {
    const copy: Project = JSON.parse(JSON.stringify(p));
    setProject(copy);
    setInput(copy.input && copy.input.length < 400 ? copy.input : "");
    setCandidates(null);
    setNotice(null);
    setAlternatives([]);
    setScanErr(null);
    setHighlight(null);
    setDrawing(false);
    setDirty(false);
    setModal(null);
    focusTo({ bounds: [...copy.ring, ...(copy.pins ?? []).map((x) => x.pos)] });
  };

  const save = () => {
    if (!hasSite) return;
    let p: Project = { ...project, name: project.name || t(lang, "untitled"), updatedAt: new Date().toISOString() };
    if (p.builtIn) p = { ...p, id: newId(), builtIn: false, name: `${p.name} · ${lang === "zh" ? "副本" : "copy"}` };
    const list = [p, ...saved.filter((x) => x.id !== p.id)];
    if (saveProjects(list)) {
      setSaved(list);
      setProject(p);
      setDirty(false);
      say(t(lang, "saved"));
    }
  };

  const share = () => {
    if (!hasSite) return;
    const url = shareUrl(project);
    navigator.clipboard?.writeText(url).then(() => say(t(lang, "shareCopied")), () => window.prompt(t(lang, "share"), url));
  };

  const exportJson = () =>
    download(`${slug(project.name)}.json`, JSON.stringify({ tool: "Site Intelligence", exportedAt: new Date().toISOString(), project }, null, 2));
  const exportGeo = () => download(`${slug(project.name)}.geojson`, toGeoJson(project), "application/geo+json");

  const newProject = () => {
    setProject(emptyProject(project.radiusKm));
    setInput("");
    setCandidates(null);
    setNotice(null);
    setAlternatives([]);
    setScanErr(null);
    setDrawing(false);
    setDirty(false);
    setModal(null);
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {}
    if (location.hash) history.replaceState(null, "", location.pathname);
  };

  const pins = project.pins ?? [];
  const features = project.scan?.features ?? [];

  return (
    <div className={`si-app${panelOpen ? "" : " is-collapsed"}`}>
      <header className="si-top">
        <div className="si-brand">
          <svg className="si-logo" viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
            <path d="M4 7 12 3l8 4v10l-8 4-8-4z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
            <circle cx="12" cy="12" r="2.6" fill="currentColor" />
          </svg>
          <span className="si-brand__name">{t(lang, "appName")}</span>
        </div>
        <label className="si-projname">
          <span className="sr-only">{t(lang, "projectName")}</span>
          <input
            value={project.name}
            placeholder={hasSite ? t(lang, "untitled") : t(lang, "appTag")}
            onChange={(e) => update({ name: e.target.value })}
            disabled={!hasSite}
          />
          {dirty && hasSite && <span className="si-dirty" title="unsaved" />}
        </label>
        <nav className="si-actions">
          <button type="button" className="si-tbtn" onClick={() => setModal("projects")}>
            <Icon name="folder" /> <span>{t(lang, "projects")}</span>
          </button>
          <button type="button" className="si-tbtn" onClick={save} disabled={!hasSite}>
            <Icon name="save" /> <span>{t(lang, "saveProject")}</span>
          </button>
          <button type="button" className="si-tbtn" onClick={share} disabled={!hasSite}>
            <Icon name="share" /> <span>{t(lang, "share")}</span>
          </button>
          <button type="button" className="si-tbtn" onClick={() => setModal("report")} disabled={!project.scan}>
            <Icon name="report" /> <span>{t(lang, "report")}</span>
          </button>
          <details className="si-menu">
            <summary className="si-tbtn" aria-label={t(lang, "exportJson")}>
              <Icon name="download" /> <span>{lang === "zh" ? "导出" : "Export"}</span>
            </summary>
            <div className="si-menu__pop">
              <button type="button" onClick={exportGeo} disabled={!hasSite}>{t(lang, "exportGeoJson")}</button>
              <button type="button" onClick={exportJson} disabled={!hasSite}>{t(lang, "exportJson")}</button>
            </div>
          </details>
          <button type="button" className="si-tbtn" onClick={() => setModal("sources")}>
            <Icon name="link" /> <span>{t(lang, "sources")}</span>
          </button>
          <button
            type="button"
            className="si-lang"
            onClick={() => setLang(lang === "en" ? "zh" : "en")}
            aria-label={lang === "en" ? "切换到中文" : "Switch to English"}
          >
            <span className={lang === "en" ? "is-on" : ""}>EN</span>
            <span className={lang === "zh" ? "is-on" : ""}>中文</span>
          </button>
        </nav>
      </header>

      <div className="si-body">
        <aside className="si-panel" aria-label="Site workflow">
          <button type="button" className="si-panel__grip" onClick={() => setPanelOpen(!panelOpen)} aria-expanded={panelOpen}>
            <Icon name="chevron" className={panelOpen ? "" : "is-flipped"} />
          </button>
          <div className="si-panel__scroll">
            {project.notes === "batam-study" && <StudyCard lang={lang} onOpenSources={() => setModal("sources")} />}
            <LocateStep
              lang={lang}
              input={input}
              setInput={setInput}
              onLocate={locate}
              resolving={resolving}
              notice={notice}
              alternatives={alternatives}
              onPickAlternative={(s) => {
                applySite(s, s.name);
                setAlternatives((a) => a.filter((x) => x !== s));
              }}
              done={hasSite}
            />
            <BoundaryStep
              lang={lang}
              hasSite={hasSite}
              stats={stats}
              candidates={candidates}
              detecting={detecting}
              detectErr={detectErr}
              activeOrigin={project.origin?.url}
              onDetect={() => detect(centre)}
              onPick={(c: BoundaryCandidate) => {
                update({ ring: c.ring, origin: c.source, name: project.name || c.name });
                focusTo({ bounds: c.ring });
              }}
              onSquare={(ha) => {
                const ring = squareRing(centre, ha);
                update({ ring });
                focusTo({ bounds: ring });
              }}
              onDraw={() => {
                setDrawing(true);
                setHighlight(null);
              }}
              drawing={drawing}
              pins={pins}
              onPinReset={(id) => {
                setProject((p) => ({ ...p, pins: p.pins?.map((x) => (x.id === id ? { ...x, pos: x.original } : x)) }));
                setDirty(true);
              }}
              onPinFocus={(p) => focusTo({ pos: p.pos, zoom: 14 })}
              onPinUseAsSite={(p) => {
                const ring = squareRing(p.pos, p.areaHa ?? 20);
                update({ ring, center: p.pos, name: `${project.notes === "batam-study" ? "Batam · " : ""}${p.label[lang]}`, scan: undefined });
                setCandidates(null);
                focusTo({ bounds: ring });
              }}
            />
            <ScanStep
              lang={lang}
              project={project}
              hasSite={hasSite}
              scanning={scanning}
              scanErr={scanErr}
              stale={stale}
              readiness={ready}
              highlight={highlight}
              onRadius={(r) => update({ radiusKm: r })}
              onScan={runScan}
              onFocus={focusFeature}
            />
          </div>
        </aside>

        <main className="si-mapwrap">
          <MapView
            lang={lang}
            basemap={basemap}
            ring={hasSite ? project.ring : null}
            editable={!drawing}
            pins={pins}
            features={features}
            layers={layers}
            showRings={showRings && hasSite}
            drawing={drawing}
            focus={focus}
            highlightId={highlight}
            onRingChange={onRingChange}
            onPinMove={onPinMove}
            onDrawComplete={(ring) => {
              setDrawing(false);
              update({ ring, origin: { provider: lang === "zh" ? "在地图上手动绘制" : "Drawn on the map" } });
              setCandidates(null);
            }}
            onFeatureClick={(id) => setHighlight(id)}
            onProvider={setProvider}
          />

          <div className="si-mapctl">
            <div className="si-seg si-seg--map" role="radiogroup" aria-label="Basemap">
              {(["satellite", "hybrid", "map"] as Basemap[]).map((b) => (
                <button key={b} type="button" role="radio" aria-checked={basemap === b} className={basemap === b ? "is-on" : ""} onClick={() => setBasemap(b)}>
                  {t(lang, b)}
                </button>
              ))}
            </div>
            <div className="si-chips">
              {(["power", "telecom", "water"] as Category[]).map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`si-chip${layers[c] ? " is-on" : ""}`}
                  aria-pressed={layers[c]}
                  onClick={() => setLayers((l) => ({ ...l, [c]: !l[c] }))}
                  disabled={!features.length}
                >
                  <span className="si-group__dot" style={{ background: CATEGORY_COLOR[c] }} />
                  {CATEGORY_LABEL[c][lang]}
                </button>
              ))}
              <button type="button" className={`si-chip${showRings ? " is-on" : ""}`} aria-pressed={showRings} onClick={() => setShowRings(!showRings)} disabled={!hasSite}>
                <span className="si-ringdot" />
                {t(lang, "rings")}
              </button>
            </div>
            <div className={`si-provider${provider === "google" ? " is-google" : ""}`}>
              <Icon name="globe" size={12} /> {provider === "google" ? t(lang, "googleImagery") : t(lang, "fallbackImagery")}
            </div>
          </div>

          {stats && !drawing && (
            <div className="si-gps" aria-live="polite">
              <span className="si-label">{t(lang, "centroid")}</span>
              <b className="mono">{fmtCoord(stats.centroid)}</b>
              <span className="mono si-gps__area">{stats.areaHa >= 100 ? stats.areaHa.toFixed(0) : stats.areaHa.toFixed(1)} ha</span>
            </div>
          )}

          {drawing && (
            <div className="si-drawbar" role="status">
              <span>{t(lang, "drawHint")}</span>
              <button type="button" className="si-btn si-btn--primary" onClick={() => window.dispatchEvent(new Event("si:finish-draw"))}>
                <Icon name="check" /> {t(lang, "finish")}
              </button>
              <button type="button" className="si-btn" onClick={() => setDrawing(false)}>
                {t(lang, "cancel")}
              </button>
            </div>
          )}

          {!hasSite && !drawing && (
            <div className="si-welcome">
              <p>{t(lang, "welcome")}</p>
              <button type="button" className="si-btn" onClick={() => openProject(batamProject())}>
                <Icon name="book" /> {lang === "zh" ? "打开巴淡岛示例研究" : "Open the Batam sample study"}
              </button>
            </div>
          )}
        </main>
      </div>

      {modal === "projects" && (
        <ProjectsModal
          lang={lang}
          current={project}
          projects={allProjects}
          onOpen={openProject}
          onNew={newProject}
          onDelete={(p) => {
            const list = saved.filter((x) => x.id !== p.id);
            saveProjects(list);
            setSaved(list);
          }}
          onClose={() => setModal(null)}
        />
      )}
      {modal === "sources" && <SourcesModal lang={lang} project={project} onClose={() => setModal(null)} />}
      {modal === "report" && project.scan && <ReportModal lang={lang} project={project} onClose={() => setModal(null)} />}
      {toast && (
        <div className="si-toast" role="status">
          {toast}
        </div>
      )}
    </div>
  );
}
