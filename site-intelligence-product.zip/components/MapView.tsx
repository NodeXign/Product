"use client";

import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Category, Feature, LatLng, Pin, Ring } from "@/lib/types";
import type { Lang } from "@/lib/i18n";
import { KIND_LABEL, ATTR_LABEL, t } from "@/lib/i18n";
import { basemapLayers, googleCopyright, type Basemap, type Provider } from "@/lib/basemaps";
import { ringCentroid, translateRing, fmtKm } from "@/lib/geo";
import { GLYPH, CATEGORY_COLOR, ACCENT, esc } from "./glyphs";

export type Focus = { nonce: number; pos?: LatLng; zoom?: number; bounds?: LatLng[]; featureId?: string };

type Props = {
  lang: Lang;
  basemap: Basemap;
  ring: Ring | null;
  editable: boolean;
  pins: Pin[];
  features: Feature[];
  layers: Record<Category, boolean>;
  showRings: boolean;
  drawing: boolean;
  focus: Focus | null;
  highlightId: string | null;
  onRingChange: (ring: Ring, final: boolean) => void;
  onPinMove: (id: string, pos: LatLng, final: boolean) => void;
  onDrawComplete: (ring: Ring) => void;
  onFeatureClick: (id: string) => void;
  onProvider: (p: Provider) => void;
};

const RING_KM = [5, 10, 20];

function div(html: string, className: string, size: number) {
  return L.divIcon({ html, className, iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
}

export default function MapView(props: Props) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const cb = useRef(props);
  cb.current = props;

  const groups = useRef<{
    base: L.Layer[];
    site: L.LayerGroup;
    handles: L.LayerGroup;
    pins: L.LayerGroup;
    rings: L.LayerGroup;
    feats: Record<Category, L.LayerGroup>;
    draw: L.LayerGroup;
  } | null>(null);
  const dragging = useRef(false);
  const pinDragging = useRef(false);
  const featureLayers = useRef(new Map<string, L.Layer>());
  const session = useRef<string | null>(null);

  // ---- init ------------------------------------------------------------------
  useEffect(() => {
    if (!el.current || map.current) return;
    const m = L.map(el.current, { zoomControl: false, worldCopyJump: true, attributionControl: true }).setView([18, 40], 2); // neutral world view until a site is located
    L.control.zoom({ position: "topright" }).addTo(m);
    L.control.scale({ imperial: false, position: "bottomright" }).addTo(m);
    m.attributionControl.setPrefix('<a href="https://leafletjs.com">Leaflet</a>');
    m.createPane("rings").style.zIndex = "390";
    m.createPane("lines").style.zIndex = "410";
    m.createPane("site").style.zIndex = "420";
    groups.current = {
      base: [],
      site: L.layerGroup().addTo(m),
      handles: L.layerGroup().addTo(m),
      pins: L.layerGroup().addTo(m),
      rings: L.layerGroup().addTo(m),
      feats: { power: L.layerGroup().addTo(m), telecom: L.layerGroup().addTo(m), water: L.layerGroup().addTo(m) },
      draw: L.layerGroup().addTo(m),
    };
    map.current = m;

    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(el.current);

    // Google asks for viewport-specific provider credits.
    let timer: ReturnType<typeof setTimeout> | undefined;
    const credit = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        if (!session.current) return;
        const c = await googleCopyright(session.current, m);
        const ctrl = m.attributionControl as L.Control.Attribution & { _gc?: string };
        if (ctrl._gc) ctrl.removeAttribution(ctrl._gc);
        ctrl._gc = `Google${c ? ` · ${esc(c)}` : ""}`;
        ctrl.addAttribution(ctrl._gc);
      }, 400);
    };
    m.on("moveend", credit);

    return () => {
      ro.disconnect();
      clearTimeout(timer);
      m.remove();
      map.current = null;
      groups.current = null;
    };
  }, []);

  // ---- basemap ---------------------------------------------------------------
  useEffect(() => {
    const m = map.current;
    const g = groups.current;
    if (!m || !g) return;
    let cancelled = false;
    basemapLayers(props.basemap, props.lang).then(({ layers, provider, session: s }) => {
      if (cancelled || !map.current) return;
      g.base.forEach((l) => m.removeLayer(l));
      layers.forEach((l, i) => {
        l.addTo(m);
        (l as L.TileLayer).setZIndex?.(i);
      });
      g.base = layers;
      session.current = s ?? null;
      const ctrl = m.attributionControl as L.Control.Attribution & { _gc?: string };
      if (ctrl._gc) ctrl.removeAttribution(ctrl._gc), (ctrl._gc = undefined);
      if (s) m.fire("moveend");
      cb.current.onProvider(provider);
    });
    return () => {
      cancelled = true;
    };
  }, [props.basemap, props.lang]);

  // ---- boundary + edit handles ----------------------------------------------
  useEffect(() => {
    const m = map.current;
    const g = groups.current;
    if (!m || !g) return;
    const ring = props.ring;

    // While a handle is being dragged the polygon is updated in place; don't rebuild under the cursor.
    if (dragging.current) return;
    g.site.clearLayers();
    g.handles.clearLayers();
    if (!ring || ring.length < 3) return;

    let work: Ring = ring.slice();
    // White casing under the accent line keeps the boundary readable on any imagery.
    const casing = L.polygon(work, { pane: "site", color: "#fff", weight: 5.5, opacity: 0.85, fill: false, interactive: false }).addTo(g.site);
    const line = L.polygon(work, { pane: "site", color: ACCENT, weight: 2.5, fillColor: ACCENT, fillOpacity: 0.14, interactive: false }).addTo(g.site);
    const poly = {
      setLatLngs(r: Ring) {
        casing.setLatLngs(r);
        line.setLatLngs(r);
      },
    };
    if (!props.editable) return;

    let raf = 0;
    const live = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => cb.current.onRingChange(work.slice(), false));
    };
    const final = () => {
      cancelAnimationFrame(raf);
      dragging.current = false;
      cb.current.onRingChange(work.slice(), true);
    };

    const vIcon = div("", "si-vertex", 12);
    const mIcon = div("", "si-mid", 10);
    const verts: L.Marker[] = [];
    const mids: L.Marker[] = [];
    const midOf = (i: number): LatLng => {
      const a = work[i];
      const b = work[(i + 1) % work.length];
      return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    };
    const refreshMids = () => mids.forEach((mk, i) => mk.setLatLng(midOf(i)));

    work.forEach((p, i) => {
      const v = L.marker(p, { icon: vIcon, draggable: true, keyboard: false, zIndexOffset: 1000, title: "" }).addTo(g.handles);
      v.on("dragstart", () => (dragging.current = true));
      v.on("drag", () => {
        const ll = v.getLatLng();
        work[i] = [ll.lat, ll.lng];
        poly.setLatLngs(work);
        refreshMids();
        center.setLatLng(ringCentroid(work));
        live();
      });
      v.on("dragend", final);
      v.on("contextmenu", (e: L.LeafletMouseEvent) => {
        L.DomEvent.preventDefault(e.originalEvent);
        if (work.length <= 3) return;
        work = work.filter((_, k) => k !== i);
        final();
      });
      verts.push(v);
    });

    work.forEach((_, i) => {
      const mk = L.marker(midOf(i), { icon: mIcon, draggable: true, keyboard: false, zIndexOffset: 900 }).addTo(g.handles);
      let inserted = false;
      const insert = () => {
        if (inserted) return;
        inserted = true;
        work.splice(i + 1, 0, midOf(i));
      };
      mk.on("dragstart", () => {
        dragging.current = true;
        insert();
      });
      mk.on("drag", () => {
        const ll = mk.getLatLng();
        work[i + 1] = [ll.lat, ll.lng];
        poly.setLatLngs(work);
        center.setLatLng(ringCentroid(work));
        live();
      });
      mk.on("dragend", final);
      mk.on("click", () => {
        insert();
        final();
      });
      mids.push(mk);
    });

    // Centre pin: drags the whole boundary.
    let startRing: Ring = work;
    let startC: LatLng = ringCentroid(work);
    const center = L.marker(startC, { icon: div(GLYPH.move, "si-center", 30), draggable: true, keyboard: false, zIndexOffset: 1100 }).addTo(g.handles);
    center.on("dragstart", () => {
      dragging.current = true;
      startRing = work.slice();
      startC = ringCentroid(work);
    });
    center.on("drag", () => {
      const ll = center.getLatLng();
      work = translateRing(startRing, startC, [ll.lat, ll.lng]);
      poly.setLatLngs(work);
      work.forEach((p, i) => verts[i]?.setLatLng(p));
      refreshMids();
      live();
    });
    center.on("dragend", final);

    return () => cancelAnimationFrame(raf);
  }, [props.ring, props.editable]);

  // ---- distance rings ---------------------------------------------------------
  useEffect(() => {
    const g = groups.current;
    if (!g) return;
    g.rings.clearLayers();
    if (!props.showRings || !props.ring || props.ring.length < 3) return;
    const c = ringCentroid(props.ring);
    for (const km of RING_KM) {
      L.circle(c, { radius: km * 1000, pane: "rings", color: "#fff", weight: 1.2, opacity: 0.75, dashArray: "4 6", fill: false, interactive: false }).addTo(g.rings);
      const north: LatLng = [c[0] + km / 111.2, c[1]];
      L.marker(north, { icon: L.divIcon({ className: "si-ringlabel", html: `${km} km`, iconSize: [44, 16], iconAnchor: [22, 8] }), interactive: false, keyboard: false }).addTo(g.rings);
    }
  }, [props.showRings, props.ring]);

  // ---- pins ------------------------------------------------------------------
  useEffect(() => {
    const g = groups.current;
    if (!g || pinDragging.current) return;
    g.pins.clearLayers();
    for (const p of props.pins) {
      const cls = p.type === "candidate" ? "si-pin si-pin--cand" : "si-pin si-pin--ref";
      const mk = L.marker(p.pos, { icon: div("<i></i>", cls, 20), draggable: true, keyboard: false, zIndexOffset: p.type === "candidate" ? 500 : 400 }).addTo(g.pins);
      mk.bindTooltip(esc(p.label[props.lang]), { permanent: true, direction: "right", offset: [10, 0], className: `si-pinlabel ${p.type === "candidate" ? "is-cand" : ""}` });
      if (p.note) mk.bindPopup(`<b>${esc(p.label[props.lang])}</b><br>${esc(p.note[props.lang])}`);
      mk.on("dragstart", () => (pinDragging.current = true));
      mk.on("drag", () => {
        const ll = mk.getLatLng();
        cb.current.onPinMove(p.id, [ll.lat, ll.lng], false);
      });
      mk.on("dragend", () => {
        pinDragging.current = false;
        const ll = mk.getLatLng();
        cb.current.onPinMove(p.id, [ll.lat, ll.lng], true);
      });
    }
  }, [props.pins, props.lang]);

  // ---- scan results ------------------------------------------------------------
  useEffect(() => {
    const m = map.current;
    const g = groups.current;
    if (!m || !g) return;
    (Object.keys(g.feats) as Category[]).forEach((c) => {
      g.feats[c].clearLayers();
      if (props.layers[c]) g.feats[c].addTo(m);
      else m.removeLayer(g.feats[c]);
    });
    featureLayers.current.clear();
    const lang = props.lang;

    for (const f of props.features) {
      const color = CATEGORY_COLOR[f.category];
      const group = g.feats[f.category];
      const kind = KIND_LABEL[f.kind][lang];
      const title = f.name || kind;
      const dist = f.distanceKm === 0 ? t(lang, "insideSite") : fmtKm(f.distanceKm);
      const attrs = Object.entries(f.attrs)
        .filter(([k]) => !k.startsWith("_"))
        .map(([k, v]) => `<tr><th>${esc(ATTR_LABEL[k]?.[lang] ?? k)}</th><td>${esc(v)}</td></tr>`)
        .join("");
      const popup = `<div class="si-pop">
        <div class="si-pop__kind" style="color:${color}">${esc(kind)}</div>
        <div class="si-pop__name">${esc(title)}</div>
        <div class="si-pop__dist">${esc(dist)}</div>
        ${attrs ? `<table>${attrs}</table>` : ""}
        <a class="si-pop__src" href="${esc(f.source.url ?? "#")}" target="_blank" rel="noopener noreferrer">${esc(t(lang, "openRecord"))} · ${esc(f.source.provider)}</a>
      </div>`;

      if (f.lines?.length) {
        const isCable = f.kind === "submarine_cable";
        const style: L.PolylineOptions = {
          pane: "lines",
          color: isCable ? f.attrs._color || color : color,
          weight: f.kind === "river" ? 2.5 : isCable ? 2 : 3,
          opacity: f.kind === "river" ? 0.7 : 0.9,
          dashArray: f.kind === "submarine_power_cable" ? "8 6" : f.attrs.method ? "3 5" : undefined,
        };
        const line = L.polyline(f.lines, style).addTo(group);
        line.bindTooltip(`${esc(title)} · ${esc(dist)}`, { sticky: true, className: "si-tip" });
        line.bindPopup(popup, { maxWidth: 300 });
        line.on("click", () => cb.current.onFeatureClick(f.id));
      }
      const mk = L.marker(f.pos, {
        icon: div(`<span style="background:${color}">${GLYPH[f.kind] ?? ""}</span>`, `si-feat${f.lines ? " is-onl" : ""}`, f.lines ? 18 : 24),
        keyboard: false,
      }).addTo(group);
      mk.bindTooltip(`${esc(title)} · ${esc(dist)}`, { direction: "top", offset: [0, -10], className: "si-tip" });
      mk.bindPopup(popup, { maxWidth: 300 });
      mk.on("click", () => cb.current.onFeatureClick(f.id));
      featureLayers.current.set(f.id, mk);
    }
  }, [props.features, props.layers, props.lang]);

  // Highlight by toggling a class, so an open popup survives.
  const lastHl = useRef<string | null>(null);
  useEffect(() => {
    const prev = lastHl.current ? (featureLayers.current.get(lastHl.current) as L.Marker | undefined) : undefined;
    prev?.getElement()?.classList.remove("is-hl");
    prev?.setZIndexOffset(0);
    const cur = props.highlightId ? (featureLayers.current.get(props.highlightId) as L.Marker | undefined) : undefined;
    cur?.getElement()?.classList.add("is-hl");
    cur?.setZIndexOffset(2000);
    lastHl.current = props.highlightId;
  }, [props.highlightId, props.features, props.layers]);

  // ---- draw mode ----------------------------------------------------------------
  useEffect(() => {
    const m = map.current;
    const g = groups.current;
    if (!m || !g) return;
    g.draw.clearLayers();
    if (!props.drawing) {
      m.getContainer().classList.remove("is-drawing");
      return;
    }
    m.getContainer().classList.add("is-drawing");
    m.doubleClickZoom.disable();
    const pts: LatLng[] = [];
    const line = L.polyline([], { color: "#fff", weight: 2, dashArray: "5 5", interactive: false }).addTo(g.draw);
    const fill = L.polygon([], { color: ACCENT, weight: 2, fillColor: ACCENT, fillOpacity: 0.12, interactive: false }).addTo(g.draw);
    let cursor: LatLng | null = null;
    const redraw = () => {
      fill.setLatLngs(pts);
      line.setLatLngs(cursor ? [...pts, cursor] : pts);
    };
    const finish = () => {
      // A double-click lands two clicks on the same spot first; drop near-duplicate corners.
      const clean = pts.filter((p, i) => {
        if (i === 0) return true;
        const a = m.latLngToContainerPoint(pts[i - 1]);
        return a.distanceTo(m.latLngToContainerPoint(p)) > 4;
      });
      if (clean.length >= 3) cb.current.onDrawComplete(clean);
    };
    const onClick = (e: L.LeafletMouseEvent) => {
      if (pts.length >= 3) {
        const first = m.latLngToContainerPoint(pts[0]);
        if (first.distanceTo(e.containerPoint) < 14) return finish();
      }
      pts.push([e.latlng.lat, e.latlng.lng]);
      L.marker(e.latlng, { icon: div("", pts.length === 1 ? "si-vertex is-first" : "si-vertex", 12), interactive: false, keyboard: false }).addTo(g.draw);
      redraw();
    };
    const onMove = (e: L.LeafletMouseEvent) => {
      cursor = [e.latlng.lat, e.latlng.lng];
      redraw();
    };
    const onDbl = () => finish();
    m.on("click", onClick);
    m.on("mousemove", onMove);
    m.on("dblclick", onDbl);
    const onFinish = () => finish();
    window.addEventListener("si:finish-draw", onFinish);
    return () => {
      m.off("click", onClick);
      m.off("mousemove", onMove);
      m.off("dblclick", onDbl);
      window.removeEventListener("si:finish-draw", onFinish);
      m.doubleClickZoom.enable();
      g.draw.clearLayers();
    };
  }, [props.drawing]);

  // ---- focus requests -------------------------------------------------------------
  useEffect(() => {
    const m = map.current;
    const f = props.focus;
    if (!m || !f) return;
    if (f.bounds && f.bounds.length > 1) {
      // Keep the site clear of the basemap/layer controls (top-left) and the GPS readout (bottom-left).
      const ctl = el.current?.parentElement?.querySelector<HTMLElement>(".si-mapctl");
      const top = ctl ? ctl.offsetTop + ctl.offsetHeight + 28 : 60;
      m.flyToBounds(L.latLngBounds(f.bounds), { paddingTopLeft: [48, top], paddingBottomRight: [64, 80], maxZoom: 16, duration: 0.9 });
    } else if (f.pos) {
      m.flyTo(f.pos, f.zoom ?? Math.max(m.getZoom(), 14), { duration: 0.9 });
    }
    if (f.featureId) {
      const layer = featureLayers.current.get(f.featureId) as L.Marker | undefined;
      if (layer) setTimeout(() => layer.openPopup(), 950);
    }
  }, [props.focus?.nonce]); // eslint-disable-line react-hooks/exhaustive-deps

  return <div ref={el} className="si-map" aria-label="Map" />;
}
