"use client";

import { useRef, useState } from "react";
import type { BoundaryCandidate, Category, Feature, LatLng, Pin, Project, ResolvedSite } from "@/lib/types";
import { t, KIND_LABEL, CATEGORY_LABEL, type Lang } from "@/lib/i18n";
import { fmtCoord, fmtKm } from "@/lib/geo";
import type { Readiness } from "@/lib/readiness";
import { Icon } from "./Icon";
import { CATEGORY_COLOR, GLYPH } from "./glyphs";

export type Notice = { kind: "error" | "info"; text: string; detail?: string } | null;

function Step({ n, title, hint, children, done, disabled }: { n: number; title: string; hint?: string; children: React.ReactNode; done?: boolean; disabled?: boolean }) {
  return (
    <section className={`si-step${disabled ? " is-disabled" : ""}`} aria-disabled={disabled || undefined}>
      <header className="si-step__head">
        <span className={`si-step__n${done ? " is-done" : ""}`}>{done ? <Icon name="check" size={13} /> : n}</span>
        <h2>{title}</h2>
      </header>
      {hint && <p className="si-step__hint">{hint}</p>}
      {children}
    </section>
  );
}

function NoticeBox({ notice }: { notice: Notice }) {
  if (!notice) return null;
  return (
    <div className={`si-notice si-notice--${notice.kind}`} role={notice.kind === "error" ? "alert" : "status"}>
      {notice.kind === "error" && <Icon name="alert" size={15} />}
      <div>
        <div>{notice.text}</div>
        {notice.detail && <div className="si-notice__detail">{notice.detail}</div>}
      </div>
    </div>
  );
}

export function CopyButton({ text, lang }: { text: string; lang: Lang }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      type="button"
      className="si-linkbtn"
      onClick={() => {
        navigator.clipboard?.writeText(text).then(() => {
          setOk(true);
          setTimeout(() => setOk(false), 1300);
        });
      }}
    >
      <Icon name={ok ? "check" : "copy"} size={13} /> {ok ? t(lang, "copied") : t(lang, "copy")}
    </button>
  );
}

// ---------------------------------------------------------------------------------
export function LocateStep(props: {
  lang: Lang;
  input: string;
  setInput: (s: string) => void;
  onLocate: (text?: string, label?: string) => void;
  resolving: boolean;
  notice: Notice;
  alternatives: ResolvedSite[];
  onPickAlternative: (s: ResolvedSite) => void;
  done: boolean;
}) {
  const { lang } = props;
  const fileRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  const readFile = async (file: File) => {
    const text = await file.text();
    props.onLocate(text, file.name);
  };

  return (
    <Step n={1} title={t(lang, "step1")} hint={t(lang, "step1Hint")} done={props.done}>
      <form
        className={`si-locate${over ? " is-over" : ""}`}
        onSubmit={(e) => {
          e.preventDefault();
          props.onLocate();
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          const f = e.dataTransfer.files?.[0];
          if (f) readFile(f);
        }}
      >
        <textarea
          className="si-input"
          rows={2}
          value={props.input}
          placeholder={t(lang, "inputPlaceholder")}
          onChange={(e) => props.setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              props.onLocate();
            }
          }}
          aria-label={t(lang, "step1")}
          spellCheck={false}
        />
        <div className="si-row">
          <button className="si-btn si-btn--primary" type="submit" disabled={props.resolving}>
            <Icon name="search" /> {props.resolving ? t(lang, "locating") : t(lang, "locate")}
          </button>
          <button className="si-btn" type="button" onClick={() => fileRef.current?.click()}>
            <Icon name="upload" /> {t(lang, "upload")}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".kml,.geojson,.json,application/vnd.google-earth.kml+xml,application/geo+json"
            hidden
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) readFile(f);
              e.target.value = "";
            }}
          />
        </div>
        {over && <div className="si-dropzone">{t(lang, "dropHere")}</div>}
      </form>
      <NoticeBox notice={props.notice} />
      {props.alternatives.length > 0 && (
        <ul className="si-alts">
          {props.alternatives.map((a, i) => (
            <li key={i}>
              <button type="button" className="si-alt" onClick={() => props.onPickAlternative(a)}>
                <Icon name="pin" size={13} />
                <span>{a.name}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </Step>
  );
}

// ---------------------------------------------------------------------------------
export function BoundaryStep(props: {
  lang: Lang;
  hasSite: boolean;
  stats: { areaHa: number; perimeterKm: number; centroid: LatLng; corners: number } | null;
  candidates: BoundaryCandidate[] | null;
  detecting: boolean;
  detectErr: string | null;
  activeOrigin?: string;
  onDetect: () => void;
  onPick: (c: BoundaryCandidate) => void;
  onSquare: (ha: number) => void;
  onDraw: () => void;
  drawing: boolean;
  pins: Pin[];
  onPinReset: (id: string) => void;
  onPinFocus: (p: Pin) => void;
  onPinUseAsSite: (p: Pin) => void;
}) {
  const { lang, stats } = props;
  const [ha, setHa] = useState(20);
  return (
    <Step n={2} title={t(lang, "step2")} hint={t(lang, "step2Hint")} done={props.hasSite && !props.drawing} disabled={!props.hasSite && !props.drawing}>
      {stats && (
        <dl className="si-stats">
          <div>
            <dt>{t(lang, "area")}</dt>
            <dd className="mono">{stats.areaHa >= 100 ? stats.areaHa.toFixed(0) : stats.areaHa.toFixed(1)} ha</dd>
          </div>
          <div>
            <dt>{t(lang, "perimeter")}</dt>
            <dd className="mono">{fmtKm(stats.perimeterKm)}</dd>
          </div>
          <div>
            <dt>{t(lang, "corners")}</dt>
            <dd className="mono">{stats.corners}</dd>
          </div>
          <div className="si-stats__wide">
            <dt>{t(lang, "centroid")}</dt>
            <dd className="mono">
              {fmtCoord(stats.centroid)} <CopyButton text={fmtCoord(stats.centroid)} lang={lang} />
            </dd>
          </div>
        </dl>
      )}

      <div className="si-row si-row--wrap">
        <button className="si-btn" type="button" onClick={props.onDetect} disabled={!props.hasSite || props.detecting}>
          <Icon name="polygon" /> {props.detecting ? t(lang, "detecting") : t(lang, "detect")}
        </button>
        <span className="si-split">
          <button className="si-btn" type="button" onClick={() => props.onSquare(ha)} disabled={!props.hasSite}>
            <Icon name="square" /> {t(lang, "square", { ha })}
          </button>
          <select className="si-select" value={ha} onChange={(e) => setHa(Number(e.target.value))} aria-label="ha">
            {[5, 10, 20, 50, 100, 200, 500].map((v) => (
              <option key={v} value={v}>
                {v} ha
              </option>
            ))}
          </select>
        </span>
        <button className="si-btn" type="button" onClick={props.onDraw} disabled={props.drawing}>
          <Icon name="pen" /> {t(lang, "drawNew")}
        </button>
      </div>

      {props.detectErr && (
        <NoticeBox notice={{ kind: "error", text: t(lang, "categoryFailed", { provider: "OpenStreetMap", msg: props.detectErr.replace(/^OpenStreetMap \(Overpass\):\s*/, "") }) }} />
      )}
      {props.candidates && !props.detecting && !props.detectErr && (
        props.candidates.length ? (
          <>
            <p className="si-sub">{t(lang, "candidatesFound", { n: props.candidates.length })}</p>
            <ul className="si-cands">
              {props.candidates.map((c) => (
                <li key={c.id}>
                  <button type="button" className={`si-cand${props.activeOrigin === c.source.url ? " is-active" : ""}`} onClick={() => props.onPick(c)}>
                    <span className="si-cand__name">{c.name || c.tag}</span>
                    <span className="si-cand__meta">
                      <code>{c.tag}</code> · <span className="mono">{c.areaHa >= 100 ? c.areaHa.toFixed(0) : c.areaHa} ha</span>
                      {c.containsPoint && <> · {t(lang, "inside")}</>}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <p className="si-sub">{t(lang, "noCandidates")}</p>
        )
      )}

      {props.pins.length > 0 && (
        <div className="si-pins">
          <h3>{t(lang, "pins")}</h3>
          <p className="si-step__hint">{t(lang, "pinsHint")}</p>
          <ul>
            {props.pins.map((p) => {
              const moved = p.pos[0] !== p.original[0] || p.pos[1] !== p.original[1];
              return (
                <li key={p.id} className={`si-pinrow${moved ? " is-moved" : ""}`}>
                  <button type="button" className="si-pinrow__name" onClick={() => props.onPinFocus(p)}>
                    <span className={`si-swatch ${p.type === "candidate" ? "is-cand" : ""}`} />
                    {p.label[lang]}
                    {moved && <span className="si-badge">{t(lang, "moved")}</span>}
                  </button>
                  <span className="mono si-pinrow__gps">{fmtCoord(p.pos, 5)}</span>
                  <span className="si-pinrow__acts">
                    <CopyButton text={fmtCoord(p.pos)} lang={lang} />
                    {moved && (
                      <button type="button" className="si-linkbtn" onClick={() => props.onPinReset(p.id)}>
                        <Icon name="reset" size={13} /> {t(lang, "reset")}
                      </button>
                    )}
                    {p.type === "candidate" && (
                      <button type="button" className="si-linkbtn" onClick={() => props.onPinUseAsSite(p)}>
                        <Icon name="target" size={13} /> {lang === "zh" ? "设为场地" : "Use as site"}
                      </button>
                    )}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </Step>
  );
}

// ---------------------------------------------------------------------------------
const CATS: Category[] = ["power", "telecom", "water"];
const RADII = [5, 10, 15, 25, 50];

function featureDetail(f: Feature) {
  const keys = ["voltage", "capacity", "source", "rfs", "capacityWater", "status", "operator"];
  return keys
    .filter((k) => f.attrs[k])
    .slice(0, 2)
    .map((k) => (k === "operator" || k === "source" ? f.attrs[k] : `${f.attrs[k]}`))
    .join(" · ");
}

export function distLabel(f: Feature, lang: Lang) {
  return f.distanceKm === 0 ? t(lang, "insideSite") : fmtKm(f.distanceKm);
}

function ResultRow({ f, lang, active, onClick }: { f: Feature; lang: Lang; active: boolean; onClick: () => void }) {
  const detail = featureDetail(f);
  return (
    <li>
      <div className={`si-res${active ? " is-active" : ""}`}>
        <button type="button" className="si-res__main" onClick={onClick} title={t(lang, "showOnMap")}>
          <span className="si-res__glyph" style={{ background: CATEGORY_COLOR[f.category] }} dangerouslySetInnerHTML={{ __html: GLYPH[f.kind] }} />
          <span className="si-res__text">
            <span className="si-res__name">{f.name || KIND_LABEL[f.kind][lang]}</span>
            <span className="si-res__meta">
              {KIND_LABEL[f.kind][lang]}
              {detail && <> · {detail}</>}
            </span>
          </span>
          <span className={`si-dist mono${f.distanceKm === 0 ? " is-inside" : ""}`}>{distLabel(f, lang)}</span>
        </button>
        {f.source.url && (
          <a className="si-res__src" href={f.source.url} target="_blank" rel="noopener noreferrer" title={`${t(lang, "openRecord")} · ${f.source.provider}`}>
            <Icon name="external" size={13} />
          </a>
        )}
      </div>
    </li>
  );
}

function CategoryGroup({ cat, features, lang, highlight, onFocus, status, radius }: {
  cat: Category; features: Feature[]; lang: Lang; highlight: string | null; onFocus: (f: Feature) => void;
  status?: { ok: boolean; message?: string }; radius: number;
}) {
  const [all, setAll] = useState(false);
  const shown = all ? features : features.slice(0, 6);
  return (
    <div className="si-group">
      <h3 className="si-group__head">
        <span className="si-group__dot" style={{ background: CATEGORY_COLOR[cat] }} />
        {CATEGORY_LABEL[cat][lang]}
        <span className="si-group__count mono">{features.length}</span>
      </h3>
      {status && !status.ok && (
        <NoticeBox notice={{ kind: "error", text: t(lang, "categoryFailed", { provider: status.message?.split(":")[0] ?? "", msg: status.message?.split(":").slice(1).join(":").trim() ?? "" }) }} />
      )}
      {features.length === 0 && status?.ok !== false && <p className="si-sub">{t(lang, "noneWithin", { r: radius })}</p>}
      <ul className="si-reslist">
        {shown.map((f) => (
          <ResultRow key={f.id} f={f} lang={lang} active={highlight === f.id} onClick={() => onFocus(f)} />
        ))}
      </ul>
      {features.length > 6 && (
        <button type="button" className="si-linkbtn si-more" onClick={() => setAll(!all)}>
          <Icon name="chevron" size={13} className={all ? "is-flipped" : ""} /> {all ? t(lang, "less") : t(lang, "more", { n: features.length })}
        </button>
      )}
    </div>
  );
}

export function ReadinessCards({ items, lang, onFocus }: { items: Readiness[]; lang: Lang; onFocus?: (f: Feature) => void }) {
  return (
    <div className="si-ready">
      {items.map((r) => (
        <button
          type="button"
          key={r.category}
          className={`si-ready__card is-${r.rating}`}
          onClick={() => r.basis && onFocus?.(r.basis)}
          disabled={!r.basis || !onFocus}
        >
          <span className="si-ready__cat">
            <span className="si-group__dot" style={{ background: CATEGORY_COLOR[r.category] }} />
            {CATEGORY_LABEL[r.category][lang]}
          </span>
          <span className={`si-pill is-${r.rating}`}>{t(lang, r.rating === "none" ? "none" : r.rating)}</span>
          {r.basis ? (
            <span className="si-ready__basis">
              <span>{t(lang, "nearest", { kind: lang === "zh" ? KIND_LABEL[r.basis.kind].zh : KIND_LABEL[r.basis.kind].en.toLowerCase() })}</span>
              <b className="mono">{distLabel(r.basis, lang)}</b>
            </span>
          ) : (
            <span className="si-ready__basis">—</span>
          )}
        </button>
      ))}
    </div>
  );
}

export function ScanStep(props: {
  lang: Lang;
  project: Project;
  hasSite: boolean;
  scanning: boolean;
  scanErr: string | null;
  stale: boolean;
  readiness: Readiness[] | null;
  highlight: string | null;
  onRadius: (r: number) => void;
  onScan: () => void;
  onFocus: (f: Feature) => void;
}) {
  const { lang, project } = props;
  const scan = project.scan;
  const when = scan ? new Date(scan.generatedAt).toLocaleString(lang === "zh" ? "zh-CN" : "en-GB", { dateStyle: "medium", timeStyle: "short" }) : "";
  return (
    <Step n={3} title={t(lang, "step3")} hint={t(lang, "step3Hint")} done={Boolean(scan) && !props.stale} disabled={!props.hasSite}>
      <div className="si-row si-row--between">
        <div className="si-seg" role="radiogroup" aria-label={t(lang, "radius")}>
          {RADII.map((r) => (
            <button
              key={r}
              type="button"
              role="radio"
              aria-checked={project.radiusKm === r}
              className={project.radiusKm === r ? "is-on" : ""}
              onClick={() => props.onRadius(r)}
            >
              {r} km
            </button>
          ))}
        </div>
        <button className="si-btn si-btn--primary" type="button" onClick={props.onScan} disabled={!props.hasSite || props.scanning}>
          <Icon name="radar" /> {props.scanning ? t(lang, "scanning") : scan ? t(lang, "rescan") : t(lang, "scan")}
        </button>
      </div>
      {props.scanning && <div className="si-progress" aria-hidden="true"><span /></div>}
      {props.scanErr && <NoticeBox notice={{ kind: "error", text: props.scanErr }} />}
      {scan && (
        <div className="si-results">
          <p className="si-sub">
            {t(lang, "scannedAt", { time: when })} · <span className="mono">{scan.radiusKm} km</span>
          </p>
          {props.stale && <NoticeBox notice={{ kind: "info", text: t(lang, "scanStale") }} />}
          {props.readiness && (
            <>
              <h3 className="si-label">{t(lang, "readiness")}</h3>
              <ReadinessCards items={props.readiness} lang={lang} onFocus={props.onFocus} />
              <p className="si-fine">{t(lang, "readinessNote")}</p>
            </>
          )}
          {CATS.map((c) => (
            <CategoryGroup
              key={c}
              cat={c}
              lang={lang}
              features={scan.features.filter((f) => f.category === c)}
              highlight={props.highlight}
              onFocus={props.onFocus}
              status={scan.status[c]}
              radius={c === "telecom" ? Math.max(100, scan.radiusKm * 3) : scan.radiusKm}
            />
          ))}
        </div>
      )}
    </Step>
  );
}

