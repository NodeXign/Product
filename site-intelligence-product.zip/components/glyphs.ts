import type { Category, Kind } from "@/lib/types";

export const ACCENT = "#1257FD";

export const CATEGORY_COLOR: Record<Category, string> = {
  power: "#D97706",
  telecom: "#7C3AED",
  water: "#0891B2",
};

export function esc(s: string): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

const svg = (body: string) =>
  `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;

export const GLYPH: Record<Kind | "move", string> = {
  move: svg('<path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>'),
  power_plant: svg('<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>'),
  substation: svg('<circle cx="9" cy="12" r="5"/><circle cx="15" cy="12" r="5"/>'),
  power_line: svg('<path d="M5 21 9 3h6l4 18M7 12h10M6 17h12"/>'),
  submarine_power_cable: svg('<path d="M3 16c3-3 6 3 9 0s6 3 9 0M12 3v9"/>'),
  landing_point: svg('<circle cx="12" cy="5" r="2"/><path d="M12 7v14M5 13a7 7 0 0 0 14 0M8 10h8"/>'),
  submarine_cable: svg('<path d="M3 12c3-4 6 4 9 0s6 4 9 0"/>'),
  data_center: svg('<rect x="4" y="4" width="16" height="7" rx="1"/><rect x="4" y="13" width="16" height="7" rx="1"/><path d="M8 7.5h.01M8 16.5h.01"/>'),
  telecom_exchange: svg('<path d="M12 21v-9M8.5 8.5a5 5 0 0 1 7 0M5.5 5.5a9 9 0 0 1 13 0"/>'),
  water_works: svg('<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>'),
  desalination: svg('<path d="M12 2s4 4.3 4 7.3a4 4 0 0 1-8 0C8 6.3 12 2 12 2zM3 18c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/>'),
  wastewater: svg('<path d="M4 12a8 8 0 0 1 14-5M20 12a8 8 0 0 1-14 5M18 3v4h-4M6 21v-4h4"/>'),
  reservoir: svg('<path d="M3 9c2-2 4-2 6 0s4 2 6 0 4-2 6 0M3 15c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/>'),
  dam: svg('<path d="M4 20V9l16-4v15zM4 14h16"/>'),
  river: svg('<path d="M4 4c4 3 0 6 4 9s0 6 4 7M12 4c4 3 0 6 4 9s0 6 4 7"/>'),
  water_tower: svg('<path d="M7 3h10v7H7zM9 10l-2 11M15 10l2 11M8 16h8"/>'),
};
