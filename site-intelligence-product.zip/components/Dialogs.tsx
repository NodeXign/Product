"use client";

import { useEffect, useRef, useState } from "react";
import type { Project, Source } from "@/lib/types";
import { t, KIND_LABEL, CATEGORY_LABEL, ATTR_LABEL, type Lang } from "@/lib/i18n";
import { fmtCoord, ringAreaHa, ringCentroid, ringPerimeterKm } from "@/lib/geo";
import { readiness } from "@/lib/readiness";
import { BATAM_STUDY, BATAM_MASTER_SOURCE, BATAM_CITATIONS } from "@/lib/batam";
import { Icon } from "./Icon";
import { ReadinessCards, distLabel } from "./Steps";
import { CATEGORY_COLOR } from "./glyphs";

// ---------------------------------------------------------------------------------
function Modal({ title, onClose, children, wide, className }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close.current();
    window.addEventListener("keydown", onKey);
    ref.current?.focus();
    return () => {
      window.removeEventListener("keydown", onKey);
      opener?.focus?.();
    };
  }, []);
  return (
    <div className={`si-modal ${className ?? ""}`} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`si-modal__card${wide ? " is-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref}>
        <header className="si-modal__head">
          <h2>{title}</h2>
          <button type="button" className="si-iconbtn" onClick={onClose} aria-label={title}>
            <Icon name="close" />
          </button>
        </header>
        <div className="si-modal__body">{children}</div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------------
export function StudyCard({ lang, onOpenSources }: { lang: Lang; onOpenSources: () => void }) {
  const [open, setOpen] = useState(false);
  const s = BATAM_STUDY;
  return (
    <section className="si-study">
      <button type="button" className="si-study__toggle" onClick={() => setOpen(!open)} aria-expanded={open}>
        <Icon name="book" />
        <span>
          <span className="si-label">{t(lang, "studySource")}</span>
          <b>{s.title[lang]}</b>
        </span>
        <Icon name="chevron" className={open ? "is-flipped" : ""} />
      </button>
      {open && (
        <div className="si-study__body">
          <p>{s.context[lang]}</p>
          {s.sites.map((site) => (
            <div key={site.key} className="si-study__site">
              <h4>{site.name[lang]}</h4>
              <ul>
                {site.points.map((p, i) => (
                  <li key={i}>{p[lang]}</li>
                ))}
              </ul>
            </div>
          ))}
          <div className="si-tablewrap">
            <table className="si-table">
              <thead>
                <tr>
                  {s.comparison.head[lang].map((h) => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {s.comparison.rows.map((r, i) => (
                  <tr key={i}>
                    {r[lang].map((c, j) => (
                      <td key={j} className={r.tone[j] > 0 ? "is-good" : r.tone[j] < 0 ? "is-weak" : ""}>
                        {c}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="si-reco">
            <h4>{lang === "zh" ? "战略推荐" : "Recommendation"}</h4>
            <ul>
              {s.recommendation.map((r, i) => (
                <li key={i}>{r[lang]}</li>
              ))}
            </ul>
          </div>
          <button type="button" className="si-linkbtn" onClick={onOpenSources}>
            <Icon name="link" size={13} /> {t(lang, "sources")}
          </button>
        </div>
      )}
    </section>
  );
}

// ---------------------------------------------------------------------------------
export function SourcesModal({ lang, project, onClose }: { lang: Lang; project: Project; onClose: () => void }) {
  const scanSources: Source[] = project.scan?.sources ?? [
    { provider: "OpenStreetMap (Overpass API)", url: "https://www.openstreetmap.org/copyright", license: "ODbL 1.0 — © OpenStreetMap contributors" },
    { provider: "TeleGeography Submarine Cable Map", url: "https://www.submarinecablemap.com/", license: "CC BY-NC-SA 3.0 — TeleGeography" },
  ];
  const base: Source[] = [
    { provider: "Google Maps Platform — Map Tiles API / Geocoding API", url: "https://cloud.google.com/maps-platform/terms" },
    { provider: "Esri World Imagery (fallback basemap)", url: "https://www.arcgis.com/home/item.html?id=10df2279f9684e4a9f6a7f08febac2a9" },
    { provider: "OpenStreetMap Nominatim (address search fallback)", url: "https://nominatim.org/", license: "ODbL 1.0" },
  ];
  const isBatam = project.notes === "batam-study";
  const row = (s: Source, i: number) => (
    <li key={i}>
      {s.url ? (
        <a href={s.url} target="_blank" rel="noopener noreferrer">
          {s.provider} <Icon name="external" size={12} />
        </a>
      ) : (
        <span>{s.provider}</span>
      )}
      {s.license && <span className="si-fine"> · {s.license}</span>}
    </li>
  );
  return (
    <Modal title={t(lang, "sourcesTitle")} onClose={onClose}>
      <p className="si-sub">{t(lang, "sourcesIntro")}</p>
      {project.origin && (
        <div className="si-srcblock is-primary">
          <h3 className="si-label">{lang === "zh" ? "场地位置来源" : "Site location from"}</h3>
          <ul>{row(project.origin, 0)}</ul>
          {project.input && !project.input.startsWith("<") && !project.input.startsWith("{") && <p className="si-fine mono">{project.input}</p>}
        </div>
      )}
      {isBatam && (
        <div className="si-srcblock">
          <h3 className="si-label">{t(lang, "studySource")}</h3>
          <ul>
            {row(BATAM_MASTER_SOURCE, 0)}
            {BATAM_CITATIONS.map((c, i) => row({ provider: c.label[lang], url: c.url }, i + 1))}
          </ul>
          <p className="si-fine">
            {lang === "zh"
              ? "Gemini 会话需登录 Google 查看；仅有机构主页的引用，其原文链接位于该会话中。"
              : "The Gemini session needs a Google sign-in; where a citation links only to an organisation's home page, the exact article link is in that session."}
          </p>
        </div>
      )}
      <div className="si-srcblock">
        <h3 className="si-label">{lang === "zh" ? "周边扫描数据" : "Scan data"}</h3>
        <ul>{scanSources.map(row)}</ul>
      </div>
      <div className="si-srcblock">
        <h3 className="si-label">{lang === "zh" ? "底图与地址检索" : "Basemaps & address search"}</h3>
        <ul>{base.map(row)}</ul>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------------------
export function ProjectsModal(props: {
  lang: Lang;
  current: Project;
  projects: Project[];
  onOpen: (p: Project) => void;
  onNew: () => void;
  onDelete: (p: Project) => void;
  onClose: () => void;
}) {
  const { lang } = props;
  return (
    <Modal title={t(lang, "projects")} onClose={props.onClose}>
      <button type="button" className="si-btn si-btn--primary" onClick={props.onNew}>
        <Icon name="plus" /> {t(lang, "newProject")}
      </button>
      <ul className="si-projlist">
        {props.projects.map((p) => (
          <li key={p.id} className={p.id === props.current.id ? "is-current" : ""}>
            <button type="button" className="si-projlist__open" onClick={() => props.onOpen(p)}>
              <b>{p.name || t(lang, "untitled")}</b>
              <span className="si-fine">
                {p.builtIn ? t(lang, "sample") : new Date(p.updatedAt).toLocaleDateString(lang === "zh" ? "zh-CN" : "en-GB")}
                {" · "}
                <span className="mono">{ringAreaHa(p.ring).toFixed(0)} ha</span>
                {p.scan && <> · {p.scan.features.length} {lang === "zh" ? "项设施" : "assets"}</>}
              </span>
            </button>
            {!p.builtIn && (
              <button
                type="button"
                className="si-iconbtn"
                aria-label={t(lang, "deleteProject")}
                onClick={() => {
                  if (confirm(t(lang, "confirmDelete", { name: p.name }))) props.onDelete(p);
                }}
              >
                <Icon name="trash" />
              </button>
            )}
          </li>
        ))}
      </ul>
    </Modal>
  );
}

// ---------------------------------------------------------------------------------
export function ReportModal({ lang, project, onClose }: { lang: Lang; project: Project; onClose: () => void }) {
  const scan = project.scan;
  const centroid = ringCentroid(project.ring);
  const fmt = (iso: string) => new Date(iso).toLocaleString(lang === "zh" ? "zh-CN" : "en-GB", { dateStyle: "long", timeStyle: "short" });
  const ready = scan ? readiness(scan) : null;
  return (
    <Modal title={t(lang, "reportTitle")} onClose={onClose} wide className="si-printable">
      <article className="si-report">
        <header className="si-report__head">
          <div className="si-label">{t(lang, "reportTitle")}</div>
          <h1>{project.name || t(lang, "untitled")}</h1>
          <p className="si-fine">{t(lang, "generated", { time: fmt(new Date().toISOString()) })}</p>
          <button type="button" className="si-btn si-noprint" onClick={() => window.print()}>
            <Icon name="report" /> {t(lang, "print")}
          </button>
        </header>

        <section>
          <h2>{t(lang, "reportSite")}</h2>
          <dl className="si-stats si-stats--report">
            <div><dt>{t(lang, "centroid")}</dt><dd className="mono">{fmtCoord(centroid)}</dd></div>
            <div><dt>{t(lang, "area")}</dt><dd className="mono">{ringAreaHa(project.ring).toFixed(1)} ha</dd></div>
            <div><dt>{t(lang, "perimeter")}</dt><dd className="mono">{ringPerimeterKm(project.ring).toFixed(2)} km</dd></div>
            <div><dt>{t(lang, "corners")}</dt><dd className="mono">{project.ring.length}</dd></div>
          </dl>
          {project.origin && (
            <p className="si-fine">
              {lang === "zh" ? "位置来源：" : "Location from: "}
              {project.origin.url ? <a href={project.origin.url}>{project.origin.provider}</a> : project.origin.provider}
            </p>
          )}
          <details className="si-report__coords">
            <summary>{t(lang, "reportBoundary")} ({project.ring.length})</summary>
            <ol className="mono">{project.ring.map((p, i) => <li key={i}>{fmtCoord(p)}</li>)}</ol>
          </details>
        </section>

        {scan && ready && (
          <>
            <section>
              <h2>{t(lang, "reportFindings")}</h2>
              <ReadinessCards items={ready} lang={lang} />
              <ul className="si-report__findings">
                {ready.map((r) =>
                  r.basis ? (
                    <li key={r.category}>
                      <b>{CATEGORY_LABEL[r.category][lang]}:</b> {t(lang, "nearest", { kind: lang === "zh" ? KIND_LABEL[r.basis.kind].zh : KIND_LABEL[r.basis.kind].en.toLowerCase() })} — {r.basis.name || KIND_LABEL[r.basis.kind][lang]}
                      {r.basis.attrs.voltage && ` (${r.basis.attrs.voltage})`}, {distLabel(r.basis, lang)}
                    </li>
                  ) : null,
                )}
              </ul>
              <p className="si-fine">{t(lang, "readinessNote")}</p>
            </section>

            <section>
              <h2>{t(lang, "reportAll")}</h2>
              <p className="si-fine">{t(lang, "scannedAt", { time: fmt(scan.generatedAt) })} · {scan.radiusKm} km</p>
              <div className="si-tablewrap">
                <table className="si-table si-table--report">
                  <thead>
                    <tr>
                      <th>{t(lang, "colName")}</th>
                      <th>{t(lang, "colType")}</th>
                      <th className="num">{t(lang, "colDistance")}</th>
                      <th>{t(lang, "colDetails")}</th>
                      <th>{t(lang, "colSource")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scan.features.map((f) => (
                      <tr key={f.id}>
                        <td>
                          <span className="si-group__dot" style={{ background: CATEGORY_COLOR[f.category] }} /> {f.name || "—"}
                        </td>
                        <td>{KIND_LABEL[f.kind][lang]}</td>
                        <td className="num mono">{distLabel(f, lang)}</td>
                        <td className="si-fine">
                          {Object.entries(f.attrs)
                            .filter(([k]) => !k.startsWith("_"))
                            .map(([k, v]) => `${ATTR_LABEL[k]?.[lang] ?? k}: ${v}`)
                            .join(" · ")}
                        </td>
                        <td className="si-fine">{f.source.url ? <a href={f.source.url}>{f.source.provider}</a> : f.source.provider}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section>
              <h2>{t(lang, "reportMethod")}</h2>
              <p>{t(lang, "reportMethodText")}</p>
              <ul className="si-fine">
                {scan.sources.map((s, i) => (
                  <li key={i}>
                    {s.url ? <a href={s.url}>{s.provider}</a> : s.provider}
                    {s.license && ` — ${s.license}`}
                  </li>
                ))}
                {project.notes === "batam-study" && (
                  <li>
                    <a href={BATAM_MASTER_SOURCE.url}>{BATAM_MASTER_SOURCE.provider}</a>
                  </li>
                )}
              </ul>
            </section>
          </>
        )}
      </article>
    </Modal>
  );
}
