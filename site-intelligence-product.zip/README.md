# Site Intelligence · 场地情报

Bilingual (English / 中文) siting tool for any parcel of land:

1. **Locate** — paste a Google Maps link (short `maps.app.goo.gl/…` or full), a **Google My Maps link with the boundary drawn**, coordinates (decimal or DMS), an address, or drop a KML / GeoJSON file.
2. **Boundary** — the boundary comes from the input (My Maps / KML / GeoJSON / parcel geocode), or is auto-detected from OpenStreetMap parcels around the point. Edit it on the map: drag corners, click a mid-point to add a corner, right-click a corner to remove it, drag the centre pin to move the whole site. Area, perimeter and centre GPS update live.
3. **Scan** — the backend searches around the boundary for **power** (plants, substations, HV lines, subsea power cables), **subsea cables & telecom** (TeleGeography landing points and cable routes, data centres, exchanges) and **water** (treatment works, desalination, reservoirs, dams, rivers). Every asset shows its distance from the boundary edge and links to the exact source record.

Plus: readiness ratings per category, a printable report, share links (the site travels in the URL), GeoJSON / JSON export, saved projects, and the original **Batam DC study** as a built-in sample with draggable reference pins.

## Data sources

| What | Source | Licence |
|---|---|---|
| Satellite / hybrid / road basemaps | Google Map Tiles API (with key) · Esri World Imagery + CARTO (fallback) | Google Maps Platform terms · Esri terms |
| Address search | Google Geocoding API (with key) · OpenStreetMap Nominatim (fallback) | — · ODbL |
| Parcels, power, water, data centres | OpenStreetMap via Overpass API | ODbL 1.0 |
| Subsea cables & landing points | TeleGeography Submarine Cable Map | CC BY-NC-SA 3.0 |

OpenStreetMap coverage varies by country — verify critical assets with the utility. TeleGeography data is non-commercial; check its terms before commercial use.

---

## Deploy to Vercel (≈5 minutes)

1. **Import the repo** — <https://vercel.com/new> → *Import Git Repository* → `NodeXign/Product`. Framework preset: Next.js (auto-detected); leave all build settings as default.
2. *(No Root Directory change needed — the app is at the repo root.)*
3. **Environment variables** (optional — the app works without them using Esri + OpenStreetMap):
   - `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` — browser key for Google satellite / hybrid / road tiles
   - `GOOGLE_MAPS_API_KEY` — server key for Google address search
4. **Deploy.** Every push to `main` redeploys automatically.

Check a deployment at `/api/health` — it reports which keys are configured and whether OpenStreetMap / TeleGeography / Nominatim are reachable.

### Google Maps API keys

1. <https://console.cloud.google.com/> → create or pick a project → enable billing.
2. *APIs & Services → Library* → enable **Map Tiles API** and **Geocoding API**.
3. *Credentials → Create API key* twice:
   - **Browser key** → *Application restrictions: Websites* → add `https://<your-app>.vercel.app/*` (and `http://localhost:3000/*` for local dev) → *API restrictions:* Map Tiles API → save as `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`.
   - **Server key** → *API restrictions:* Geocoding API (no website restriction — Vercel's server IPs change) → save as `GOOGLE_MAPS_API_KEY`.
4. Add both in *Vercel → Project → Settings → Environment Variables*, then **Redeploy** (the browser key is baked in at build time).

Google bills per tile / request beyond monthly free allowances — see the Google Maps Platform pricing page and set a budget alert.

## Run locally

```bash
cp .env.example .env.local   # optional: add keys
npm install
npm run dev                   # http://localhost:3000
```

## Tests

```bash
npm test          # unit + API tests against recorded upstream fixtures (no network)
npm run typecheck
npm run build
```

End-to-end browser test (needs Playwright) against a production build and local mock upstreams:

```bash
npx tsx tests/e2e/mock-upstreams.ts &          # Overpass / TeleGeography / Nominatim stand-in on :4010
OVERPASS_URLS=http://127.0.0.1:4010/api/interpreter \
CABLES_API_BASE=http://127.0.0.1:4010/cables \
NOMINATIM_URL=http://127.0.0.1:4010/nominatim/search \
npx next start -p 3100 &
node tests/e2e/run.mjs http://127.0.0.1:3100 ./screenshots
```

---

# 中文说明

**场地情报**是一个中英双语的选址工具，适用于任何地块：

1. **定位场地** —— 粘贴 Google 地图链接（短链 `maps.app.goo.gl/…` 或完整链接）、**已画好边界的 Google My Maps 链接**、经纬度（十进制或度分秒）、地址，或拖入 KML / GeoJSON 文件。
2. **确定边界** —— 边界来自输入本身（My Maps / KML / GeoJSON / 地块级地址），或由系统自动从 OpenStreetMap 识别该点周边的地块。可在地图上直接编辑：拖动角点；点击边中点新增角点；右键角点删除；拖动中心图钉整体移动场地。面积、周长与中心点 GPS 实时更新。
3. **周边扫描** —— 后台自动检索边界周边的**电力**（发电厂、变电站、高压线路、海底电力电缆）、**海缆与通信**（TeleGeography 海缆登陆点与路由、数据中心、电信交换局）和**供水**（自来水厂、海水淡化厂、水库、水坝、河流）。每一项设施都显示距边界边缘的距离，并链接到原始数据记录。

另有：分类条件评级、可打印报告、分享链接（场地信息直接编码在链接中）、GeoJSON / JSON 导出、项目保存，以及作为内置示例的**巴淡岛数据中心选址研究**（参考图钉可拖动，GPS 实时更新）。

## 部署到 Vercel（约 5 分钟）

1. 打开 <https://vercel.com/new> → *Import Git Repository* → 选择 `NodeXign/Product`。框架会自动识别为 Next.js，构建设置保持默认。
2. *（无需修改 Root Directory——应用就在仓库根目录。）*
3. **环境变量**（可选；不配置时使用 Esri 影像 + OpenStreetMap，同样可用）：
   - `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` —— 浏览器端密钥，用于 Google 卫星 / 混合 / 道路底图
   - `GOOGLE_MAPS_API_KEY` —— 服务器端密钥，用于 Google 地址检索
4. 点击 **Deploy**。之后每次推送到 `main` 都会自动重新部署。

部署后访问 `/api/health` 可检查密钥是否生效，以及 OpenStreetMap / TeleGeography / Nominatim 是否可达。

### 申请 Google Maps API 密钥

1. 打开 <https://console.cloud.google.com/>，新建或选择项目并开通结算。
2. *APIs & Services → Library*：启用 **Map Tiles API** 和 **Geocoding API**。
3. *Credentials → Create API key*，创建两把密钥：
   - **浏览器密钥**：*Application restrictions* 选 *Websites*，填入 `https://<你的应用>.vercel.app/*`（本地开发可加 `http://localhost:3000/*`）；*API restrictions* 选 Map Tiles API → 填到 `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`。
   - **服务器密钥**：*API restrictions* 选 Geocoding API（不要加网站限制，Vercel 服务器 IP 不固定）→ 填到 `GOOGLE_MAPS_API_KEY`。
4. 在 *Vercel → Project → Settings → Environment Variables* 中添加两把密钥，然后 **Redeploy**（浏览器密钥在构建时写入）。

超出每月免费额度后 Google 按调用量计费，请查看 Google Maps Platform 价格页并设置预算提醒。

## 数据来源

| 内容 | 来源 | 许可 |
|---|---|---|
| 卫星 / 混合 / 道路底图 | Google Map Tiles API（需密钥）· Esri World Imagery + CARTO（备用） | Google Maps Platform 条款 · Esri 条款 |
| 地址检索 | Google Geocoding API（需密钥）· OpenStreetMap Nominatim（备用） | — · ODbL |
| 地块、电力、供水、数据中心 | OpenStreetMap（Overpass API） | ODbL 1.0 |
| 海缆与登陆点 | TeleGeography Submarine Cable Map | CC BY-NC-SA 3.0 |

OpenStreetMap 的覆盖度因国家而异，关键设施请向公用事业单位核实；TeleGeography 数据为非商业许可，商业使用前请确认条款。
