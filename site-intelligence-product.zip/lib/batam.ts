import type { Pin, Project, Source } from "./types";
import { squareRing } from "./geo";

type Bi = { en: string; zh: string };

export const BATAM_MASTER_SOURCE: Source = {
  provider: "Gemini research session (original Batam study)",
  url: "https://gemini.google.com/share/5b25a8e5d95a?skid=5bae620c-9bec-4c1c-b264-bbe0f3095b74",
};

export const BATAM_CITATIONS: { label: Bi; url?: string }[] = [
  { label: { en: "Batam Pos — PLN Batam / PLN Sumatera grid expansion", zh: "Batam Pos — PLN Batam / PLN Sumatera 电网扩容报道" }, url: "https://batampos.jawapos.com/" },
  { label: { en: "PLN Batam — system frequency & dispatch", zh: "PLN Batam — 系统频率与调度" }, url: "https://plnbatam.com/" },
  { label: { en: "Singtel press releases — Batam / Nongsa data centres", zh: "Singtel 新闻稿 — 巴淡岛 / Nongsa 数据中心" }, url: "https://www.singtel.com/about-us/media-centre/news-releases" },
  { label: { en: "Batam DC Site Study (internal due-diligence report)", zh: "Batam DC Site Study（内部尽调报告）" } },
  { label: { en: "The Indonesian Institute (TII) — Rempang land conflict", zh: "The Indonesian Institute (TII) — Rempang 土地冲突报告" }, url: "https://www.theindonesianinstitute.com/" },
];

export type StudySite = { key: "A" | "B" | "C"; name: Bi; points: Bi[] };

export const BATAM_STUDY = {
  title: { en: "Batam hyperscale data centre siting study", zh: "巴淡岛超大型数据中心选址研究" },
  context: {
    en: "Batam's proximity to Singapore is making it a regional data centre hub. PLN Batam is adding up to 2,070 MW of supply; single customers such as DayOne have requested 2 × 511 MVA; 11 international subsea cables connect Batam and Bintan to Singapore.",
    zh: "巴淡岛紧邻新加坡，正成为区域数据中心枢纽。PLN Batam 正扩容至 2,070 MW；DayOne 等单一客户已申请 2 × 511 MVA；巴淡岛与民丹岛共有 11 条国际海缆直连新加坡。",
  },
  sites: [
    {
      key: "A",
      name: { en: "A · Kabil Industrial Estate (KIE)", zh: "A · Kabil 工业园（KIE）" },
      points: [
        { en: "538 ha (278 ha developed). Tenants include Singtel/Telkom (51 MW planned) and the DayOne AI campus with Nvidia/Firmus (360 MW planned).", zh: "总面积 538 公顷（已开发 278 公顷）。入驻方包括 Singtel/Telkom（规划 51 MW）及 DayOne 与 Nvidia/Firmus 合作的 AI 园区（规划 360 MW）。" },
        { en: "150 kV PLN grid plus on-site 30 MW and 50 MW gas plants; 20 MW solar planned.", zh: "接入 150 kV PLN 电网，园区自带 30 MW 与 50 MW 燃气电厂，并规划 20 MW 光伏。" },
        { en: "~5 km to the Tj Memban cable landing, 7.7 km to BSCS.", zh: "距 Tj Memban 海缆登陆点约 5 公里，距 BSCS 7.7 公里。" },
      ],
    },
    {
      key: "B",
      name: { en: "B · Tanjung Sauh SEZ", zh: "B · Tanjung Sauh 经济特区" },
      points: [
        { en: "840 ha, expandable to 2,000 ha. SEZ status: up to 20-year tax holiday, VAT and import-duty exemptions.", zh: "占地 840 公顷，可扩展至 2,000 公顷。经济特区：最高 20 年免税期、免增值税与进口关税。" },
        { en: "2,200 MW energy hub planned, with a subsea power link to PLTU Tanjung Kasam.", zh: "规划 2,200 MW 能源中心，并以海底电缆连接 PLTU Tanjung Kasam 电厂。" },
        { en: "Island site: needs a 14.2 km fibre link to Nongsa Digital Park (13.8 km subsea).", zh: "独立岛屿：需建设 14.2 公里光纤连接 Nongsa 数字园区（其中 13.8 公里为海缆）。" },
      ],
    },
    {
      key: "C",
      name: { en: "C · Setokok Island (client greenfield)", zh: "C · Setokok 岛（客户意向绿地）" },
      points: [
        { en: "Greenfield south of Barelang Bridge 1 at 0.9594, 104.0617 — high design freedom, no existing industrial constraints.", zh: "位于 Barelang 一号桥以南（0.9594, 104.0617）的纯绿地——定制自由度高，无既有工业限制。" },
        { en: "Far from the northern 150 kV ring: dedicated HV transmission needed. Water from the Sei Gong dam or desalination.", zh: "远离北部 150 kV 环网，需自建高压线路；水源依赖 Sei Gong 水坝或海水淡化。" },
        { en: "Long terrestrial backhaul along the Barelang road; watch Rempang land-acquisition social risk (TII).", zh: "需沿 Barelang 公路铺设长距离陆地回程光纤；注意 Rempang 征地社会风险（TII）。" },
      ],
    },
  ] as StudySite[],
  comparison: {
    head: { en: ["Metric", "A · KIE", "B · Tj. Sauh", "C · Setokok"], zh: ["维度", "A · KIE", "B · Tj. Sauh", "C · Setokok"] },
    rows: [
      { en: ["Scale", "Mid-high (360 MW+)", "Very high (GW)", "High (land as needed)"], zh: ["扩展潜力", "中高（360 MW+）", "极高（GW 级）", "较高（按需征地）"], tone: [0, 0, 1, 0] },
      { en: ["Infrastructure", "Very high (dual power & water)", "Under construction", "Very low (from zero)"], zh: ["基建完备度", "极高（双电双水）", "规划建设中", "极低（零起点）"], tone: [0, 1, 0, -1] },
      { en: ["Policy", "National heavy-industry zone", "SEZ (tax holiday)", "Non-SEZ, social risk"], zh: ["政策环境", "国家重工业区", "经济特区（免税）", "非特区／需防社会风险"], tone: [0, 0, 1, -1] },
      { en: ["Telecom", "Excellent (5 km to landing)", "New subsea link needed", "Long land backhaul"], zh: ["光纤连通", "极优（距登陆点 5 公里）", "需新建跨海线", "长距离陆地回程"], tone: [0, 1, 0, 0] },
    ],
  },
  recommendation: [
    { en: "500 MW+ AI campus: Tanjung Sauh (B) — SEZ incentives and room to grow power and land.", zh: "500 MW 以上 AI 园区：推荐 Tanjung Sauh（B）——特区优惠，电力与土地扩展空间大。" },
    { en: "100–300 MW, fastest and lowest risk: KIE (A) — redundant power, water and cables; proven by tier-one tenants.", zh: "100–300 MW、追求最快落地与最低风险：推荐 KIE（A）——水电与海缆高度冗余，已有头部玩家验证。" },
    { en: "Setokok (C): not a first choice unless land is very cheap or exclusive green power is available — connection CAPEX erodes IRR.", zh: "Setokok（C）：除非地价极低或有独家绿电，否则不建议作为首选——基础设施引接成本将削弱 IRR。" },
  ],
};

const pin = (id: string, en: string, zh: string, pos: [number, number], type: Pin["type"], note?: Bi, areaHa?: number): Pin => ({
  id,
  label: { en, zh },
  pos,
  original: pos,
  type,
  note,
  areaHa,
});

export const BATAM_PINS: Pin[] = [
  pin("site-a", "A · KIE", "A · KIE", [1.082, 104.116], "candidate", { en: "538 ha · 150 kV + 80 MW on-site · Singtel, DayOne", zh: "538 公顷 · 150 kV + 80 MW 自备电厂 · Singtel、DayOne" }, 538),
  pin("site-b", "B · Tanjung Sauh", "B · Tanjung Sauh", [1.141, 104.176], "candidate", { en: "840–2,000 ha · 2,200 MW planned · SEZ", zh: "840–2,000 公顷 · 规划 2,200 MW · 经济特区" }, 840),
  pin("site-c", "C · Setokok", "C · Setokok", [0.9594, 104.0617], "candidate", { en: "Greenfield · high infrastructure CAPEX · area not stated in study", zh: "绿地 · 基建投入高 · 研究未给出面积" }, 100),
  pin("nongsa", "Nongsa Digital Park", "Nongsa 数字园区", [1.121, 104.103], "reference", { en: "Existing DC hub (Singtel, PDG, DC First)", zh: "现有数据中心集群（Singtel、PDG、DC First）" }),
  pin("memban", "Tj Memban cable landing", "Tj Memban 海缆登陆点", [1.135, 104.11], "reference", { en: "~5 km from KIE", zh: "距 KIE 约 5 公里" }),
  pin("kasam", "PLTU Tanjung Kasam", "PLTU Tanjung Kasam 电厂", [1.05, 104.135], "reference", { en: "Coal power plant · 110 MW", zh: "燃煤电厂 · 110 MW" }),
  pin("batamindo", "Batamindo", "Batamindo 工业园", [1.045, 104.03], "reference", { en: "Electronics & manufacturing", zh: "电子与制造业" }),
  pin("panbil", "Panbil", "Panbil 工业园", [1.068, 104.019], "reference", { en: "Mature commercial & industry", zh: "成熟商业与工业区" }),
  pin("batuampar", "Batu Ampar", "Batu Ampar", [1.165, 104.005], "reference", { en: "Port & logistics hub", zh: "港口与物流枢纽" }),
  pin("uncang", "Tanjung Uncang", "Tanjung Uncang", [1.05, 103.92], "reference", { en: "Shipyards & marine industry", zh: "船厂与海工产业" }),
  pin("barelang", "Barelang Bridge 1", "Barelang 一号桥", [1.002, 104.043], "reference", { en: "Road link to the main island", zh: "连接主岛的道路" }),
];

/** Sample project: Site A (KIE) as the active boundary — an approximate 538 ha square to replace with the surveyed parcel. */
export function batamProject(): Project {
  const center: [number, number] = [1.082, 104.116];
  return {
    id: "sample-batam",
    name: "Batam · A · Kabil Industrial Estate",
    input: "1.082, 104.116",
    origin: { ...BATAM_MASTER_SOURCE },
    center,
    ring: squareRing(center, 538),
    pins: BATAM_PINS.map((p) => ({ ...p })),
    radiusKm: 15,
    notes: "batam-study",
    updatedAt: "2026-01-01T00:00:00.000Z",
    builtIn: true,
  };
}
