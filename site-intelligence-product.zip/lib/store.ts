import type { LatLng, Pin, Project } from "./types";
import { isValidLatLng, ringCentroid } from "./geo";

const KEY = "site-intel:projects:v1";

export function loadProjects(): Project[] {
  try {
    const raw = localStorage.getItem(KEY);
    const list = raw ? (JSON.parse(raw) as Project[]) : [];
    return Array.isArray(list) ? list.filter((p) => p && Array.isArray(p.ring)) : [];
  } catch {
    return [];
  }
}

export function saveProjects(list: Project[]): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
    return true;
  } catch {
    return false;
  }
}

export function newId() {
  return Math.random().toString(36).slice(2, 10);
}

// ---- share links: the site travels in the URL hash, nothing is stored server-side ----

type Shared = { n: string; r: LatLng[]; k: number; i?: string; p?: { l: Pin["label"]; p: LatLng; t: Pin["type"] }[] };

const round = (p: LatLng): LatLng => [Math.round(p[0] * 1e6) / 1e6, Math.round(p[1] * 1e6) / 1e6];

function b64urlEncode(s: string) {
  const bytes = new TextEncoder().encode(s);
  let bin = "";
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlDecode(s: string) {
  const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/"));
  return new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
}

export function shareUrl(p: Project): string {
  const data: Shared = {
    n: p.name,
    r: p.ring.map(round),
    k: p.radiusKm,
    i: p.input,
    p: p.pins?.map((x) => ({ l: x.label, p: round(x.pos), t: x.type })),
  };
  return `${location.origin}${location.pathname}#s=${b64urlEncode(JSON.stringify(data))}`;
}

export function projectFromHash(hash: string): Project | null {
  const m = /[#&]s=([A-Za-z0-9_-]+)/.exec(hash);
  if (!m) return null;
  try {
    const d = JSON.parse(b64urlDecode(m[1])) as Shared;
    if (!Array.isArray(d.r) || d.r.length < 3 || !d.r.every(isValidLatLng)) return null;
    return {
      id: newId(),
      name: String(d.n || "Shared site").slice(0, 120),
      input: d.i,
      center: ringCentroid(d.r),
      ring: d.r,
      radiusKm: Math.min(50, Math.max(1, Number(d.k) || 15)),
      pins: (d.p ?? [])
        .filter((x) => isValidLatLng(x.p))
        .map((x, i) => ({ id: `shared-${i}`, label: x.l, pos: x.p, original: x.p, type: x.t === "candidate" ? "candidate" : "reference" })),
      updatedAt: new Date().toISOString(),
    };
  } catch {
    return null;
  }
}

export function download(filename: string, text: string, type = "application/json") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9一-龥]+/gi, "-").replace(/^-|-$/g, "").slice(0, 60) || "site";
}

/** Boundary + scanned assets as a GeoJSON FeatureCollection (lng, lat order), sources included. */
export function toGeoJson(p: Project): string {
  const ll = (q: LatLng) => [q[1], q[0]];
  const feats: unknown[] = [
    {
      type: "Feature",
      properties: { name: p.name, role: "site-boundary", input: p.input ?? null },
      geometry: { type: "Polygon", coordinates: [[...p.ring.map(ll), ll(p.ring[0])]] },
    },
  ];
  for (const pin of p.pins ?? []) {
    feats.push({ type: "Feature", properties: { name: pin.label.en, role: pin.type }, geometry: { type: "Point", coordinates: ll(pin.pos) } });
  }
  for (const f of p.scan?.features ?? []) {
    const props = { name: f.name, kind: f.kind, category: f.category, distance_km: f.distanceKm, ...f.attrs, source: f.source.provider, source_url: f.source.url ?? null, license: f.source.license ?? null };
    feats.push(
      f.lines?.length
        ? { type: "Feature", properties: props, geometry: { type: "MultiLineString", coordinates: f.lines.map((l) => l.map(ll)) } }
        : { type: "Feature", properties: props, geometry: { type: "Point", coordinates: ll(f.pos) } },
    );
  }
  return JSON.stringify({ type: "FeatureCollection", features: feats }, null, 2);
}
