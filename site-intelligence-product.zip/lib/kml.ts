import { XMLParser } from "fast-xml-parser";
import type { LatLng, Ring } from "./types";
import { ringAreaHa, ringCentroid, isValidLatLng } from "./geo";

export type Placemark = {
  name: string;
  center: LatLng;
  ring?: Ring;
  line?: LatLng[];
};

function parseKmlCoords(text: string): LatLng[] {
  return String(text)
    .trim()
    .split(/\s+/)
    .map((t) => t.split(",").map(Number))
    .filter((a) => a.length >= 2 && Number.isFinite(a[0]) && Number.isFinite(a[1]))
    .map((a) => [a[1], a[0]] as LatLng)
    .filter(isValidLatLng);
}

function dropClosing(ring: LatLng[]): Ring {
  if (ring.length > 1) {
    const a = ring[0];
    const b = ring[ring.length - 1];
    if (a[0] === b[0] && a[1] === b[1]) return ring.slice(0, -1);
  }
  return ring;
}

function asArray<T>(v: T | T[] | undefined): T[] {
  return v === undefined ? [] : Array.isArray(v) ? v : [v];
}

type Node = Record<string, unknown>;

/** Collect every node with the given key anywhere in the tree. */
function collect(node: unknown, key: string, out: Node[] = []): Node[] {
  if (!node || typeof node !== "object") return out;
  for (const [k, v] of Object.entries(node as Node)) {
    if (k === key) for (const item of asArray(v)) out.push(item as Node);
    else if (typeof v === "object") for (const item of asArray(v)) collect(item, key, out);
  }
  return out;
}

function textOf(v: unknown): string {
  if (v === undefined || v === null) return "";
  if (typeof v === "object") return String((v as Node)["#text"] ?? "");
  return String(v);
}

export function parseKml(xml: string): Placemark[] {
  const parser = new XMLParser({
    ignoreAttributes: true,
    removeNSPrefix: true,
    parseTagValue: false,
    trimValues: true,
  });
  const doc = parser.parse(xml);
  const out: Placemark[] = [];

  for (const pm of collect(doc, "Placemark")) {
    const name = textOf(pm.name) || "Placemark";

    // Polygons (including inside MultiGeometry) — keep the largest outer ring.
    let best: Ring | undefined;
    for (const poly of collect(pm, "Polygon")) {
      for (const outer of collect(poly, "outerBoundaryIs")) {
        for (const lr of collect(outer, "LinearRing")) {
          const ring = dropClosing(parseKmlCoords(textOf(lr.coordinates)));
          if (ring.length >= 3 && (!best || ringAreaHa(ring) > ringAreaHa(best))) best = ring;
        }
      }
    }
    if (best) {
      out.push({ name, center: ringCentroid(best), ring: best });
      continue;
    }

    const ls = collect(pm, "LineString")[0];
    if (ls) {
      const line = parseKmlCoords(textOf(ls.coordinates));
      if (line.length) {
        out.push({ name, center: line[Math.floor(line.length / 2)], line });
        continue;
      }
    }

    const pt = collect(pm, "Point")[0];
    if (pt) {
      const p = parseKmlCoords(textOf(pt.coordinates))[0];
      if (p) out.push({ name, center: p });
    }
  }
  return out;
}

/** GeoJSON (Feature, FeatureCollection or bare geometry) → placemarks. */
export function parseGeoJson(text: string): Placemark[] {
  const gj = JSON.parse(text);
  const out: Placemark[] = [];
  const feats: { geometry: { type: string; coordinates: unknown }; properties?: Record<string, unknown> }[] =
    gj.type === "FeatureCollection"
      ? gj.features
      : gj.type === "Feature"
        ? [gj]
        : [{ geometry: gj, properties: {} }];

  for (const f of feats) {
    if (!f?.geometry) continue;
    const name = String(f.properties?.name ?? f.properties?.Name ?? "Feature");
    const g = f.geometry;
    const toLL = (c: number[]) => [c[1], c[0]] as LatLng;
    if (g.type === "Polygon" || g.type === "MultiPolygon") {
      const polys = (g.type === "Polygon" ? [g.coordinates] : g.coordinates) as number[][][][];
      let best: Ring | undefined;
      for (const p of polys) {
        const ring = dropClosing(p[0].map(toLL));
        if (ring.length >= 3 && (!best || ringAreaHa(ring) > ringAreaHa(best))) best = ring;
      }
      if (best) out.push({ name, center: ringCentroid(best), ring: best });
    } else if (g.type === "Point") {
      out.push({ name, center: toLL(g.coordinates as number[]) });
    } else if (g.type === "LineString") {
      const line = (g.coordinates as number[][]).map(toLL);
      if (line.length) out.push({ name, center: line[Math.floor(line.length / 2)], line });
    }
  }
  return out;
}
