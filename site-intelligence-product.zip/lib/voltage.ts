/** "150000;20000" → { label: "150 / 20 kV", max: 150 }. Accepts volts or kV. */
export function voltage(v?: string): { label: string; max: number } | null {
  if (!v) return null;
  const kv = v
    .split(/[;,/]/)
    .map((x) => parseFloat(x.replace(/[^\d.]/g, "")))
    .filter((x) => Number.isFinite(x) && x > 0)
    .map((x) => (x >= 1000 ? x / 1000 : x));
  if (!kv.length) return null;
  const uniq = [...new Set(kv)].sort((a, b) => b - a);
  return { label: `${uniq.map((x) => +x.toFixed(1)).join(" / ")} kV`, max: uniq[0] };
}
