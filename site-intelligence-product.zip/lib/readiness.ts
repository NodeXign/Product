import type { Category, Feature, Kind, ScanResult } from "./types";
import { voltage } from "./voltage";

export type Rating = "good" | "moderate" | "weak" | "none";

export type Readiness = {
  category: Category;
  rating: Rating;
  /** The asset the rating is based on. */
  basis?: Feature;
};

function nearestOf(features: Feature[], kinds: Kind[], pred: (f: Feature) => boolean = () => true) {
  return features.filter((f) => kinds.includes(f.kind) && pred(f)).sort((a, b) => a.distanceKm - b.distanceKm)[0];
}

const band = (d: number, good: number, moderate: number): Rating => (d <= good ? "good" : d <= moderate ? "moderate" : "weak");

/**
 * Transparent rules of thumb (also shown in the UI):
 *  power   — nearest substation ≤5 km strong, ≤15 km moderate; else nearest ≥66 kV line ≤2 / ≤10 km
 *  telecom — nearest cable landing point ≤25 km strong, ≤75 km moderate
 *  water   — nearest treatment works / desalination / reservoir ≤5 km strong, ≤15 km moderate;
 *            a river within 5 km counts as moderate
 */
export function readiness(scan: ScanResult): Readiness[] {
  const f = scan.features;
  const out: Readiness[] = [];

  const sub = nearestOf(f, ["substation"]);
  const hv = nearestOf(f, ["power_line", "submarine_power_cable"], (x) => (voltage(x.attrs.voltage)?.max ?? 0) >= 66);
  if (sub) out.push({ category: "power", rating: band(sub.distanceKm, 5, 15), basis: sub });
  else if (hv) out.push({ category: "power", rating: band(hv.distanceKm, 2, 10), basis: hv });
  else out.push({ category: "power", rating: "none", basis: nearestOf(f, ["power_plant", "power_line"]) });

  const lp = nearestOf(f, ["landing_point"]);
  out.push({ category: "telecom", rating: lp ? band(lp.distanceKm, 25, 75) : "none", basis: lp ?? nearestOf(f, ["submarine_cable", "data_center"]) });

  const water = nearestOf(f, ["water_works", "desalination", "reservoir"]);
  const river = nearestOf(f, ["river"]);
  if (water) out.push({ category: "water", rating: band(water.distanceKm, 5, 15), basis: water });
  else if (river && river.distanceKm <= 5) out.push({ category: "water", rating: "moderate", basis: river });
  else out.push({ category: "water", rating: "none", basis: river ?? nearestOf(f, ["wastewater", "dam", "water_tower"]) });

  return out;
}
