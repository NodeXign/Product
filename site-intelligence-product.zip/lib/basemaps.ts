import L from "leaflet";
import type { Lang } from "./i18n";

export type Basemap = "satellite" | "hybrid" | "map";
export type Provider = "google" | "esri";

const KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "";
export const HAS_GOOGLE = Boolean(KEY);

type Session = { session: string; expiry?: string };
const sessionCache = new Map<string, Promise<Session | null>>();

function createSession(body: Record<string, unknown>): Promise<Session | null> {
  const k = JSON.stringify(body);
  if (!sessionCache.has(k)) {
    sessionCache.set(
      k,
      fetch(`https://tile.googleapis.com/v1/createSession?key=${encodeURIComponent(KEY)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: k,
      })
        .then((r) => (r.ok ? (r.json() as Promise<Session>) : null))
        .catch(() => null),
    );
  }
  return sessionCache.get(k)!;
}

/**
 * Google Map Tiles API (the supported way to show Google imagery in a third-party
 * map library). Hybrid = satellite with the roadmap label layer; falls back to plain
 * satellite if that combination is rejected.
 */
async function googleLayers(kind: Basemap, lang: Lang): Promise<{ layers: L.Layer[]; session: string } | null> {
  if (!HAS_GOOGLE) return null;
  const base = { mapType: kind === "map" ? "roadmap" : "satellite", language: lang === "zh" ? "zh-CN" : "en-US", region: "US" };
  const tries = kind === "hybrid" ? [{ ...base, layerTypes: ["layerRoadmap"] }, base] : [base];
  for (const body of tries) {
    const s = await createSession(body);
    if (s?.session) {
      const layer = L.tileLayer(`https://tile.googleapis.com/v1/2dtiles/{z}/{x}/{y}?session=${s.session}&key=${encodeURIComponent(KEY)}`, {
        maxZoom: 21,
        maxNativeZoom: kind === "map" ? 21 : 20,
        attribution: "Google",
      });
      return { layers: [layer], session: s.session };
    }
  }
  return null;
}

function esriLayers(kind: Basemap): L.Layer[] {
  if (kind === "map") {
    return [
      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        subdomains: "abcd",
        maxZoom: 20,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; CARTO',
      }),
    ];
  }
  const imagery = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
    maxZoom: 20,
    maxNativeZoom: 18,
    attribution: "Imagery &copy; Esri, Maxar, Earthstar Geographics, and the GIS User Community",
  });
  if (kind === "satellite") return [imagery];
  const ref = (name: string) =>
    L.tileLayer(`https://server.arcgisonline.com/ArcGIS/rest/services/Reference/${name}/MapServer/tile/{z}/{y}/{x}`, {
      maxZoom: 20,
      maxNativeZoom: 18,
    });
  return [imagery, ref("World_Transportation"), ref("World_Boundaries_and_Places")];
}

export async function basemapLayers(kind: Basemap, lang: Lang): Promise<{ layers: L.Layer[]; provider: Provider; session?: string }> {
  const g = await googleLayers(kind, lang);
  if (g) return { layers: g.layers, provider: "google", session: g.session };
  return { layers: esriLayers(kind), provider: "esri" };
}

/** Google requires showing the data providers for the current viewport. */
export async function googleCopyright(session: string, map: L.Map): Promise<string | null> {
  const b = map.getBounds();
  const q = new URLSearchParams({
    session,
    key: KEY,
    zoom: String(Math.round(map.getZoom())),
    north: b.getNorth().toFixed(6),
    south: b.getSouth().toFixed(6),
    east: b.getEast().toFixed(6),
    west: b.getWest().toFixed(6),
  });
  try {
    const r = await fetch(`https://tile.googleapis.com/tile/v1/viewport?${q}`);
    if (!r.ok) return null;
    const j = (await r.json()) as { copyright?: string };
    return j.copyright ?? null;
  } catch {
    return null;
  }
}
