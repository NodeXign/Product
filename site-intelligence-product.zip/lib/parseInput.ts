import type { LatLng } from "./types";
import { isValidLatLng } from "./geo";

export type ParsedInput =
  | { type: "coords"; center: LatLng }
  | { type: "my-maps"; url: string; mid: string }
  | { type: "google-short"; url: string }
  | { type: "google-maps"; url: string; center?: LatLng; placeName?: string; precise: boolean }
  | { type: "kml"; text: string }
  | { type: "geojson"; text: string }
  | { type: "text"; query: string };

const NUM = String.raw`[-+]?\d{1,3}(?:\.\d+)?`;

function dmsToDeg(deg: string, min?: string, sec?: string, hemi?: string) {
  let v = parseFloat(deg) + (min ? parseFloat(min) / 60 : 0) + (sec ? parseFloat(sec) / 3600 : 0);
  if (hemi && /[SW]/i.test(hemi)) v = -v;
  return v;
}

/** Parses "1.0822, 104.1161", "1.08N 104.11E", or DMS like 1°04'56.0"N 104°06'58.0"E. */
export function parseCoordinates(input: string): LatLng | null {
  const s = input.trim().replace(/[，]/g, ",");

  // DMS (degree sign required so we don't confuse it with decimals)
  const dms = /(\d{1,3}(?:\.\d+)?)\s*°\s*(?:(\d{1,2}(?:\.\d+)?)\s*['′’]\s*)?(?:(\d{1,2}(?:\.\d+)?)\s*["″”]\s*)?([NSEW])/gi;
  const parts = [...s.matchAll(dms)];
  if (parts.length >= 2) {
    const vals = parts.slice(0, 2).map((m) => ({ v: dmsToDeg(m[1], m[2], m[3], m[4]), h: m[4].toUpperCase() }));
    const lat = vals.find((x) => x.h === "N" || x.h === "S");
    const lng = vals.find((x) => x.h === "E" || x.h === "W");
    if (lat && lng) {
      const p: LatLng = [lat.v, lng.v];
      return isValidLatLng(p) ? p : null;
    }
  }

  // Decimal with optional hemisphere letters: "1.08N, 104.11E"
  const hemi = new RegExp(String.raw`^\s*(${NUM})\s*°?\s*([NS])\s*[, ]\s*(${NUM})\s*°?\s*([EW])\s*$`, "i").exec(s);
  if (hemi) {
    const lat = parseFloat(hemi[1]) * (/S/i.test(hemi[2]) ? -1 : 1);
    const lng = parseFloat(hemi[3]) * (/W/i.test(hemi[4]) ? -1 : 1);
    const p: LatLng = [lat, lng];
    return isValidLatLng(p) ? p : null;
  }

  // Plain decimal pair (lat, lng)
  const dec = new RegExp(String.raw`^\s*\(?\s*(${NUM})\s*[, ]\s*(${NUM})\s*\)?\s*$`).exec(s);
  if (dec) {
    const p: LatLng = [parseFloat(dec[1]), parseFloat(dec[2])];
    return isValidLatLng(p) ? p : null;
  }
  return null;
}

function pairFrom(text: string | null | undefined): LatLng | null {
  if (!text) return null;
  return parseCoordinates(decodeURIComponent(text.replace(/\+/g, " ")));
}

/**
 * Pulls coordinates out of a full Google Maps URL. The `!3d…!4d…` pair is the place pin
 * itself, so it wins over the `@lat,lng` viewport centre.
 */
export function parseGoogleMapsUrl(raw: string): { center?: LatLng; placeName?: string; precise: boolean } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return { precise: false };
  }
  const full = decodeURIComponent(url.href);

  const pins = [...full.matchAll(/!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)/g)];
  if (pins.length) {
    const m = pins[pins.length - 1];
    const p: LatLng = [parseFloat(m[1]), parseFloat(m[2])];
    if (isValidLatLng(p)) return { center: p, placeName: placeNameFrom(url), precise: true };
  }

  for (const key of ["q", "query", "ll", "center", "destination", "daddr", "sll"]) {
    const p = pairFrom(url.searchParams.get(key));
    if (p) return { center: p, placeName: placeNameFrom(url), precise: true };
  }

  // /maps/place/1.08,104.11/ or /maps/search/1.08,+104.11 or DMS in the path
  const segs = url.pathname.split("/").map((x) => decodeURIComponent(x.replace(/\+/g, " ")));
  for (const seg of segs) {
    const p = parseCoordinates(seg);
    if (p) return { center: p, placeName: placeNameFrom(url), precise: true };
  }

  const at = /@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/.exec(full);
  if (at) {
    const p: LatLng = [parseFloat(at[1]), parseFloat(at[2])];
    if (isValidLatLng(p)) return { center: p, placeName: placeNameFrom(url), precise: false };
  }

  // A search with a text query but no coordinates, e.g. ?q=Kabil+Industrial+Estate
  const q = url.searchParams.get("q") || url.searchParams.get("query");
  return { placeName: q ? decodeURIComponent(q.replace(/\+/g, " ")) : placeNameFrom(url), precise: false };
}

function placeNameFrom(url: URL): string | undefined {
  const m = /\/maps\/(?:place|search)\/([^/@]+)/.exec(url.pathname);
  if (!m) return undefined;
  const name = decodeURIComponent(m[1].replace(/\+/g, " ")).trim();
  return parseCoordinates(name) ? undefined : name || undefined;
}

export function isGoogleShortLink(raw: string) {
  return /^https?:\/\/(maps\.app\.goo\.gl|goo\.gl\/maps|g\.co\/kgs)\//i.test(raw.trim());
}

export function myMapsMid(raw: string): string | null {
  try {
    const u = new URL(raw.trim());
    if (!/google\.[a-z.]+$/i.test(u.hostname) || !u.pathname.includes("/maps/d/")) return null;
    return u.searchParams.get("mid");
  } catch {
    return null;
  }
}

export function isGoogleMapsUrl(raw: string) {
  try {
    const u = new URL(raw.trim());
    return /(^|\.)google\.[a-z.]+$/i.test(u.hostname) && (u.pathname.startsWith("/maps") || u.hostname.startsWith("maps."));
  } catch {
    return false;
  }
}

export function classifyInput(input: string): ParsedInput {
  const s = input.trim();
  if (/^\s*</.test(s) && /<kml[\s>]/i.test(s)) return { type: "kml", text: s };
  if (/^\s*\{/.test(s) && /"type"\s*:/.test(s)) return { type: "geojson", text: s };

  const coords = parseCoordinates(s);
  if (coords) return { type: "coords", center: coords };

  const mid = myMapsMid(s);
  if (mid) return { type: "my-maps", url: s, mid };
  if (isGoogleShortLink(s)) return { type: "google-short", url: s };
  if (isGoogleMapsUrl(s)) {
    const g = parseGoogleMapsUrl(s);
    return { type: "google-maps", url: s, ...g };
  }
  return { type: "text", query: s };
}
