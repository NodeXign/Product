// Shared types between the API routes and the client.

/** [lat, lng] in WGS84 degrees. */
export type LatLng = [number, number];

/** A closed ring, first point not repeated. */
export type Ring = LatLng[];

export type Source = {
  /** Who published the data, e.g. "OpenStreetMap", "TeleGeography". */
  provider: string;
  /** Link to the exact record where possible. */
  url?: string;
  license?: string;
  /** When we fetched it (ISO). */
  retrieved?: string;
};

export type ResolveKind = "coordinates" | "google-maps" | "my-maps" | "kml" | "geojson" | "geocode";

export type ResolvedSite = {
  name: string;
  center: LatLng;
  /** Present when the input itself carried a boundary (My Maps / KML / GeoJSON / area geocode). */
  boundary?: Ring;
  /** Extra points or polygons found in the input (e.g. several placemarks in a My Maps layer). */
  extras?: { name: string; center: LatLng; boundary?: Ring }[];
  kind: ResolveKind;
  source: Source;
  note?: string;
};

export type BoundaryCandidate = {
  id: string;
  name: string;
  /** e.g. "landuse=industrial", "place=island". */
  tag: string;
  ring: Ring;
  areaHa: number;
  /** True when the input point is inside the ring. */
  containsPoint: boolean;
  source: Source;
};

export type Category = "power" | "telecom" | "water";

export type Kind =
  | "power_plant"
  | "substation"
  | "power_line"
  | "submarine_power_cable"
  | "landing_point"
  | "submarine_cable"
  | "data_center"
  | "telecom_exchange"
  | "water_works"
  | "desalination"
  | "wastewater"
  | "reservoir"
  | "dam"
  | "river"
  | "water_tower";

export type Feature = {
  id: string;
  category: Category;
  kind: Kind;
  name: string;
  /** Display position (point, nearest point of a line, or centroid). */
  pos: LatLng;
  /** Simplified geometry for lines, if any (one or more polylines). */
  lines?: LatLng[][];
  /** Distance to the site boundary in km (0 when inside). */
  distanceKm: number;
  /** Short normalised attributes, e.g. { voltage: "150 kV", capacity: "110 MW" }. */
  attrs: Record<string, string>;
  source: Source;
};

export type CategoryStatus = { ok: boolean; message?: string };

export type ScanResult = {
  site: { center: LatLng; ring: Ring; areaHa: number };
  radiusKm: number;
  generatedAt: string;
  features: Feature[];
  status: Record<Category, CategoryStatus>;
  sources: Source[];
};

export type Project = {
  id: string;
  name: string;
  input?: string;
  /** Where the location / boundary came from (link, file, geocoder, OSM parcel). */
  origin?: Source;
  center: LatLng;
  ring: Ring;
  /** Reference / candidate points belonging to this project (draggable). */
  pins?: Pin[];
  scan?: ScanResult;
  radiusKm: number;
  notes?: string;
  updatedAt: string;
  /** Built-in projects are read-only templates (edits are saved as a copy). */
  builtIn?: boolean;
};

export type Pin = {
  id: string;
  label: { en: string; zh: string };
  pos: LatLng;
  original: LatLng;
  type: "candidate" | "reference";
  note?: { en: string; zh: string };
  /** Default parcel size when this pin is promoted to the active site. */
  areaHa?: number;
};
