import type { Kind, Category } from "./types";

export type Lang = "en" | "zh";

const en = {
  appName: "Site Intelligence",
  appTag: "Siting due diligence for any parcel",
  langSwitch: "中文",

  step1: "Locate the site",
  step1Hint:
    "Paste a Google Maps link, a Google My Maps link with the boundary drawn, coordinates, or an address.",
  inputPlaceholder: "https://maps.app.goo.gl/…  ·  1.0822, 104.1161  ·  Kabil Industrial Estate, Batam",
  locate: "Locate",
  locating: "Locating…",
  upload: "Upload KML / GeoJSON",
  resolvedVia: "Found via {provider}",
  approxPin: "The link only gave a map view, not a pin — check the location before scanning.",
  multiPlacemarks: "{n} shapes found in this map. Using the largest; others are shown as pins.",

  step2: "Define the boundary",
  step2Hint:
    "Pick a detected boundary or adjust it on the map: drag corners, click a mid-point handle to add a corner, right-click a corner to remove it, drag the centre pin to move the whole site.",
  detect: "Detect boundaries",
  detecting: "Searching OpenStreetMap…",
  noCandidates: "No mapped parcel found here. Start from a square and shape it on the map.",
  candidatesFound: "{n} mapped boundaries around this point",
  square: "Square · {ha} ha",
  drawNew: "Draw new",
  drawHint: "Click the map to add corners. Click the first corner or press Finish to close the shape.",
  finish: "Finish",
  cancel: "Cancel",
  area: "Area",
  perimeter: "Perimeter",
  centroid: "Centre GPS",
  corners: "Corners",
  copy: "Copy",
  copied: "Copied",
  inside: "contains pin",

  step3: "Scan the surroundings",
  step3Hint: "Power, subsea cables & telecom, and water infrastructure around the boundary.",
  radius: "Search radius",
  scan: "Run scan",
  rescan: "Re-scan",
  scanning: "Scanning…",
  scanStale: "Boundary changed since the last scan — distances may be out of date.",
  scannedAt: "Scanned {time}",
  noneWithin: "Nothing mapped within {r} km.",
  categoryFailed: "{provider} didn't respond ({msg}). Re-scan in a minute.",
  insideSite: "inside site",
  showOnMap: "Show on map",
  openRecord: "Open source record",
  more: "Show all {n}",
  less: "Show fewer",

  readiness: "Readiness",
  good: "Strong",
  moderate: "Moderate",
  weak: "Weak",
  none: "No data",
  readinessNote:
    "Rule of thumb from the nearest mapped asset — power: substation ≤5 km strong, ≤15 km moderate; cables: landing point ≤25 km strong, ≤75 km moderate; water: treatment works / reservoir ≤5 km strong, ≤15 km moderate.",
  nearest: "Nearest {kind}",

  projects: "Projects",
  newProject: "New site",
  saveProject: "Save",
  saved: "Saved",
  saveAs: "Save as new",
  deleteProject: "Delete",
  confirmDelete: "Delete “{name}”? This can't be undone.",
  sample: "Sample study",
  projectName: "Site name",
  untitled: "Untitled site",
  share: "Copy share link",
  shareCopied: "Share link copied",
  exportJson: "Export JSON",
  exportGeoJson: "Export GeoJSON",
  report: "Report",
  sources: "Sources",
  pins: "Reference pins",
  pinsHint: "Drag a pin to correct its position — GPS updates live.",
  reset: "Reset",
  moved: "Moved",

  satellite: "Satellite",
  hybrid: "Hybrid",
  map: "Map",
  rings: "Distance rings",
  googleImagery: "Google imagery",
  fallbackImagery: "Esri imagery · add a Google key for Google maps",

  reportTitle: "Site scan report",
  reportSite: "Site",
  reportBoundary: "Boundary",
  reportFindings: "Findings",
  reportAll: "All mapped assets",
  reportMethod: "Method & sources",
  reportMethodText:
    "Assets are queried live from the sources below within the search radius of the boundary. Distances are straight-line from the boundary edge (0 = inside). OpenStreetMap coverage varies by country; verify critical assets with the utility before relying on them.",
  print: "Print / save PDF",
  close: "Close",
  colName: "Name",
  colType: "Type",
  colDistance: "Distance",
  colDetails: "Details",
  colSource: "Source",
  generated: "Generated {time}",

  sourcesTitle: "Data sources",
  sourcesIntro: "Every asset links back to the record it came from.",
  studySource: "Original study",

  errEmpty: "Paste a link, coordinates or an address first.",
  errResolve: "Couldn't read that input. Try a Google Maps link, coordinates like 1.08, 104.11, or an address.",
  errNetwork: "The server couldn't be reached. Check your connection and try again.",
  errNoBoundary: "Define a boundary first (step 2).",
  dropHere: "Drop a KML or GeoJSON file to load its boundary",
  welcome: "Works for any site, anywhere: paste a Google Maps link, coordinates or an address in step 1. Or explore the sample Batam study.",
};

type Dict = typeof en;

const zh: Dict = {
  appName: "场地情报",
  appTag: "任意地块的选址尽调",
  langSwitch: "EN",

  step1: "定位场地",
  step1Hint: "粘贴 Google 地图链接、已画好边界的 Google My Maps 链接、经纬度坐标或地址。",
  inputPlaceholder: "https://maps.app.goo.gl/…  ·  1.0822, 104.1161  ·  巴淡岛 Kabil 工业园",
  locate: "定位",
  locating: "定位中…",
  upload: "上传 KML / GeoJSON",
  resolvedVia: "来源：{provider}",
  approxPin: "该链接只包含地图视野而非图钉位置——扫描前请确认位置。",
  multiPlacemarks: "该地图中有 {n} 个图形，已采用面积最大的一个，其余显示为图钉。",

  step2: "确定边界",
  step2Hint:
    "选择识别出的边界，或在地图上调整：拖动角点；点击边中点新增角点；右键角点删除；拖动中心图钉整体移动场地。",
  detect: "识别边界",
  detecting: "正在检索 OpenStreetMap…",
  noCandidates: "此处未找到已测绘地块。可从方形开始，再在地图上调整形状。",
  candidatesFound: "此点周边有 {n} 个已测绘边界",
  square: "方形 · {ha} 公顷",
  drawNew: "重新绘制",
  drawHint: "在地图上点击添加角点；点击第一个角点或按「完成」闭合图形。",
  finish: "完成",
  cancel: "取消",
  area: "面积",
  perimeter: "周长",
  centroid: "中心点 GPS",
  corners: "角点",
  copy: "复制",
  copied: "已复制",
  inside: "包含图钉",

  step3: "周边扫描",
  step3Hint: "检索边界周边的电力、海缆与通信、供水基础设施。",
  radius: "搜索半径",
  scan: "开始扫描",
  rescan: "重新扫描",
  scanning: "扫描中…",
  scanStale: "边界在上次扫描后已改动——距离可能已过时。",
  scannedAt: "扫描于 {time}",
  noneWithin: "{r} 公里内未发现已测绘设施。",
  categoryFailed: "{provider} 未响应（{msg}），请稍后重新扫描。",
  insideSite: "位于场地内",
  showOnMap: "在地图上显示",
  openRecord: "查看原始记录",
  more: "显示全部 {n} 项",
  less: "收起",

  readiness: "条件评级",
  good: "优",
  moderate: "中",
  weak: "弱",
  none: "无数据",
  readinessNote:
    "按最近已测绘设施的经验规则——电力：变电站 ≤5 公里为优、≤15 公里为中；海缆：登陆点 ≤25 公里为优、≤75 公里为中；供水：水厂 / 水库 ≤5 公里为优、≤15 公里为中。",
  nearest: "最近{kind}",

  projects: "项目",
  newProject: "新场地",
  saveProject: "保存",
  saved: "已保存",
  saveAs: "另存为新项目",
  deleteProject: "删除",
  confirmDelete: "确定删除「{name}」？删除后无法恢复。",
  sample: "示例研究",
  projectName: "场地名称",
  untitled: "未命名场地",
  share: "复制分享链接",
  shareCopied: "分享链接已复制",
  exportJson: "导出 JSON",
  exportGeoJson: "导出 GeoJSON",
  report: "报告",
  sources: "数据来源",
  pins: "参考图钉",
  pinsHint: "拖动图钉可修正位置，GPS 实时更新。",
  reset: "复位",
  moved: "已移动",

  satellite: "卫星",
  hybrid: "混合",
  map: "地图",
  rings: "距离圈",
  googleImagery: "Google 影像",
  fallbackImagery: "Esri 影像 · 配置 Google 密钥后使用 Google 地图",

  reportTitle: "场地扫描报告",
  reportSite: "场地",
  reportBoundary: "边界",
  reportFindings: "主要发现",
  reportAll: "全部已测绘设施",
  reportMethod: "方法与来源",
  reportMethodText:
    "设施数据在边界搜索半径内从下列来源实时检索。距离为自边界边缘起算的直线距离（0 = 位于场地内）。OpenStreetMap 覆盖度因国家而异，关键设施请向公用事业单位核实。",
  print: "打印 / 保存 PDF",
  close: "关闭",
  colName: "名称",
  colType: "类型",
  colDistance: "距离",
  colDetails: "详情",
  colSource: "来源",
  generated: "生成于 {time}",

  sourcesTitle: "数据来源",
  sourcesIntro: "每一项设施都链接到其原始记录。",
  studySource: "原始研究",

  errEmpty: "请先粘贴链接、坐标或地址。",
  errResolve: "无法识别该输入。请尝试 Google 地图链接、类似 1.08, 104.11 的坐标或地址。",
  errNetwork: "无法连接服务器，请检查网络后重试。",
  errNoBoundary: "请先确定边界（第 2 步）。",
  dropHere: "拖入 KML 或 GeoJSON 文件以载入边界",
  welcome: "适用于全球任意场地：在第 1 步粘贴 Google 地图链接、坐标或地址即可开始。也可先看看巴淡岛示例研究。",
};

export const DICT: Record<Lang, Dict> = { en, zh };
export type MsgKey = keyof Dict;

export function t(lang: Lang, key: MsgKey, vars?: Record<string, string | number>): string {
  let s = DICT[lang][key] ?? DICT.en[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
  return s;
}

export const CATEGORY_LABEL: Record<Category, Record<Lang, string>> = {
  power: { en: "Power", zh: "电力" },
  telecom: { en: "Cables & telecom", zh: "海缆与通信" },
  water: { en: "Water", zh: "供水" },
};

export const KIND_LABEL: Record<Kind, Record<Lang, string>> = {
  power_plant: { en: "Power plant", zh: "发电厂" },
  substation: { en: "Substation", zh: "变电站" },
  power_line: { en: "Transmission line", zh: "输电线路" },
  submarine_power_cable: { en: "Subsea power cable", zh: "海底电力电缆" },
  landing_point: { en: "Cable landing point", zh: "海缆登陆点" },
  submarine_cable: { en: "Subsea telecom cable", zh: "海底通信光缆" },
  data_center: { en: "Data centre", zh: "数据中心" },
  telecom_exchange: { en: "Telecom exchange", zh: "电信交换局" },
  water_works: { en: "Water treatment works", zh: "自来水厂" },
  desalination: { en: "Desalination plant", zh: "海水淡化厂" },
  wastewater: { en: "Wastewater plant", zh: "污水处理厂" },
  reservoir: { en: "Reservoir", zh: "水库" },
  dam: { en: "Dam", zh: "水坝" },
  river: { en: "River", zh: "河流" },
  water_tower: { en: "Water tower", zh: "水塔" },
};

export const ATTR_LABEL: Record<string, Record<Lang, string>> = {
  voltage: { en: "Voltage", zh: "电压" },
  capacity: { en: "Capacity", zh: "装机容量" },
  source: { en: "Source", zh: "能源类型" },
  operator: { en: "Operator", zh: "运营方" },
  rfs: { en: "In service", zh: "投运" },
  length: { en: "Length", zh: "长度" },
  owners: { en: "Owners", zh: "所有者" },
  cables: { en: "Cables", zh: "海缆" },
  status: { en: "Status", zh: "状态" },
  method: { en: "Method", zh: "工艺" },
  capacityWater: { en: "Capacity", zh: "处理能力" },
  circuits: { en: "Circuits", zh: "回路" },
};

export function detectLang(): Lang {
  if (typeof navigator === "undefined") return "en";
  return navigator.language?.toLowerCase().startsWith("zh") ? "zh" : "en";
}
