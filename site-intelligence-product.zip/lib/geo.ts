import type { LatLng, Ring } from "./types";

const R = 6371.0088; // mean Earth radius, km
const RAD = Math.PI / 180;

/** Longitude difference wrapped to [-180, 180) so lines crossing the antimeridian behave. */
function dLngWrap(lng: number, lng0: number) {
  return ((((lng - lng0) % 360) + 540) % 360) - 180;
}

export function haversineKm(a: LatLng, b: LatLng): number {
  const dLat = (b[0] - a[0]) * RAD;
  const dLng = dLngWrap(b[1], a[1]) * RAD;
  const s =
    Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * RAD) * Math.cos(b[0] * RAD) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

/** Local equirectangular projection around `origin`, in km. Accurate to well under 1% within ~200 km. */
export function project(origin: LatLng, p: LatLng): [number, number] {
  const k = R * RAD;
  return [dLngWrap(p[1], origin[1]) * Math.cos(origin[0] * RAD) * k, (p[0] - origin[0]) * k];
}

export function unproject(origin: LatLng, xy: [number, number]): LatLng {
  const k = R * RAD;
  return [origin[0] + xy[1] / k, origin[1] + xy[0] / (Math.cos(origin[0] * RAD) * k)];
}

function segDist(p: [number, number], a: [number, number], b: [number, number]) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len2 = dx * dx + dy * dy;
  let t = len2 === 0 ? 0 : ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const q: [number, number] = [a[0] + t * dx, a[1] + t * dy];
  return { d: Math.hypot(p[0] - q[0], p[1] - q[1]), q };
}

function segmentsIntersect(a: [number, number], b: [number, number], c: [number, number], d: [number, number]) {
  const o = (p: [number, number], q: [number, number], r: [number, number]) =>
    Math.sign((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]));
  return o(a, b, c) !== o(a, b, d) && o(c, d, a) !== o(c, d, b);
}

export function pointInRing(p: LatLng, ring: Ring): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [yi, xi] = ring[i];
    const [yj, xj] = ring[j];
    if (yi > p[0] !== yj > p[0] && p[1] < ((xj - xi) * (p[0] - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

/** Distance from a point to a polygon boundary in km; 0 when the point is inside. */
export function pointToRingKm(p: LatLng, ring: Ring): number {
  if (ring.length < 3) return ring.length ? haversineKm(p, ring[0]) : Infinity;
  if (pointInRing(p, ring)) return 0;
  const origin = p;
  const P = project(origin, p);
  let best = Infinity;
  for (let i = 0; i < ring.length; i++) {
    const a = project(origin, ring[i]);
    const b = project(origin, ring[(i + 1) % ring.length]);
    best = Math.min(best, segDist(P, a, b).d);
  }
  return best;
}

/**
 * Minimum distance between a polyline and a polygon, plus the nearest point on the
 * line (useful as the marker position for long features like transmission lines).
 */
export function lineToRingKm(line: LatLng[], ring: Ring): { km: number; nearest: LatLng } {
  if (!line.length) return { km: Infinity, nearest: [0, 0] };
  const origin = ringCentroid(ring);
  const ringXY = ring.map((p) => project(origin, p));
  let best = Infinity;
  let nearestXY: [number, number] = project(origin, line[0]);

  for (const v of line) {
    if (pointInRing(v, ring)) return { km: 0, nearest: v };
  }
  for (let i = 0; i < line.length - 1; i++) {
    const a = project(origin, line[i]);
    const b = project(origin, line[i + 1]);
    for (let j = 0; j < ringXY.length; j++) {
      const c = ringXY[j];
      const d = ringXY[(j + 1) % ringXY.length];
      if (segmentsIntersect(a, b, c, d)) return { km: 0, nearest: line[i] };
      // ring vertex -> line segment
      const r1 = segDist(c, a, b);
      if (r1.d < best) {
        best = r1.d;
        nearestXY = r1.q;
      }
      // line vertex -> ring edge (nearest stays on the line vertex)
      const r2 = segDist(a, c, d);
      if (r2.d < best) {
        best = r2.d;
        nearestXY = a;
      }
    }
  }
  if (line.length === 1) {
    return { km: pointToRingKm(line[0], ring), nearest: line[0] };
  }
  // last vertex vs ring edges
  const last = project(origin, line[line.length - 1]);
  for (let j = 0; j < ringXY.length; j++) {
    const r = segDist(last, ringXY[j], ringXY[(j + 1) % ringXY.length]);
    if (r.d < best) {
      best = r.d;
      nearestXY = last;
    }
  }
  return { km: best, nearest: unproject(origin, nearestXY) };
}

export function ringAreaHa(ring: Ring): number {
  if (ring.length < 3) return 0;
  const origin = ring[0];
  const pts = ring.map((p) => project(origin, p));
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    s += x1 * y2 - x2 * y1;
  }
  return (Math.abs(s) / 2) * 100; // km² → ha
}

export function ringPerimeterKm(ring: Ring): number {
  let s = 0;
  for (let i = 0; i < ring.length; i++) s += haversineKm(ring[i], ring[(i + 1) % ring.length]);
  return s;
}

/** Area-weighted centroid; falls back to the vertex mean for degenerate rings. */
export function ringCentroid(ring: Ring): LatLng {
  if (!ring.length) return [0, 0];
  const origin = ring[0];
  const pts = ring.map((p) => project(origin, p));
  let a = 0;
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    const f = x1 * y2 - x2 * y1;
    a += f;
    cx += (x1 + x2) * f;
    cy += (y1 + y2) * f;
  }
  if (Math.abs(a) < 1e-12) {
    const m = pts.reduce((acc, p) => [acc[0] + p[0], acc[1] + p[1]], [0, 0]);
    return unproject(origin, [m[0] / pts.length, m[1] / pts.length]);
  }
  a /= 2;
  return unproject(origin, [cx / (6 * a), cy / (6 * a)]);
}

export function circleRing(center: LatLng, radiusKm: number, n = 48): Ring {
  const out: Ring = [];
  for (let i = 0; i < n; i++) {
    const t = (i / n) * 2 * Math.PI;
    out.push(unproject(center, [Math.cos(t) * radiusKm, Math.sin(t) * radiusKm]));
  }
  return out;
}

/** An axis-aligned square of the given area, centred on `center`. */
export function squareRing(center: LatLng, areaHa: number): Ring {
  const half = Math.sqrt(areaHa / 100) / 2; // km
  return [
    unproject(center, [-half, half]),
    unproject(center, [half, half]),
    unproject(center, [half, -half]),
    unproject(center, [-half, -half]),
  ];
}

export function translateRing(ring: Ring, from: LatLng, to: LatLng): Ring {
  // Translate in projected space so the shape keeps its size in km at any latitude.
  return ring.map((p) => unproject(to, project(from, p)));
}

export function maxRadiusKm(center: LatLng, ring: Ring): number {
  return ring.reduce((m, p) => Math.max(m, haversineKm(center, p)), 0);
}

export type BBox = { south: number; west: number; north: number; east: number };

export function bboxAround(center: LatLng, km: number): BBox {
  const [x0, y0] = [-km, -km];
  const sw = unproject(center, [x0, y0]);
  const ne = unproject(center, [km, km]);
  return { south: sw[0], west: sw[1], north: ne[0], east: ne[1] };
}

/** Douglas–Peucker simplification in km. */
export function simplifyLine(line: LatLng[], toleranceKm: number): LatLng[] {
  if (line.length <= 2) return line;
  const origin = line[0];
  const pts = line.map((p) => project(origin, p));
  const keep = new Uint8Array(line.length);
  keep[0] = 1;
  keep[line.length - 1] = 1;
  const stack: [number, number][] = [[0, line.length - 1]];
  while (stack.length) {
    const [i, j] = stack.pop()!;
    let maxD = 0;
    let idx = -1;
    for (let k = i + 1; k < j; k++) {
      const d = segDist(pts[k], pts[i], pts[j]).d;
      if (d > maxD) {
        maxD = d;
        idx = k;
      }
    }
    if (idx >= 0 && maxD > toleranceKm) {
      keep[idx] = 1;
      stack.push([i, idx], [idx, j]);
    }
  }
  return line.filter((_, i) => keep[i]);
}

export function isValidLatLng(p: unknown): p is LatLng {
  return (
    Array.isArray(p) &&
    p.length === 2 &&
    Number.isFinite(p[0]) &&
    Number.isFinite(p[1]) &&
    Math.abs(p[0] as number) <= 90 &&
    Math.abs(p[1] as number) <= 180
  );
}

export function fmtKm(km: number): string {
  if (km === 0) return "0";
  if (km < 1) return `${Math.round(km * 1000)} m`;
  if (km < 10) return `${km.toFixed(1)} km`;
  return `${Math.round(km)} km`;
}

export function fmtCoord(p: LatLng, digits = 6): string {
  return `${p[0].toFixed(digits)}, ${p[1].toFixed(digits)}`;
}
