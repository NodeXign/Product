import type { LatLng, Ring } from "../types";
import { isValidLatLng, ringAreaHa } from "../geo";

export function bad(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

export function asLatLng(v: unknown): LatLng | null {
  return isValidLatLng(v) ? [v[0], v[1]] : null;
}

/** A usable site polygon: 3–2000 valid vertices, at most 100 km² (10,000 ha). */
export function asRing(v: unknown): { ring?: Ring; error?: string } {
  if (!Array.isArray(v) || v.length < 3) return { error: "Boundary needs at least 3 corners." };
  if (v.length > 2000) return { error: "Boundary has too many corners (max 2000)." };
  const ring = v.map(asLatLng);
  if (ring.some((p) => !p)) return { error: "Boundary contains invalid coordinates." };
  const r = ring as Ring;
  if (ringAreaHa(r) > 10000) return { error: "Boundary is larger than 100 km². Draw the parcel itself, not the region." };
  return { ring: r };
}

