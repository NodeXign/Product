import type { Category, CategoryStatus, Feature, Kind, LatLng, Ring, ScanResult, Source } from "../types";
import {
  bboxAround, lineToRingKm, maxRadiusKm, pointInRing, pointToRingKm, ringAreaHa, ringCentroid, simplifyLine,
} from "../geo";
import {
  overpass, osmUrl, OSM_LICENSE, elementLines, elementPoint, elementRings, type OsmElement,
} from "./overpass";
import { scanCables, CABLE_SOURCE } from "./cables";
import { errMessage, nowIso } from "./http";
import { voltage } from "../voltage";

export { voltage };

const CATEGORY_OF: Record<Kind, Category> = {
  power_plant: "power",
  substation: "power",
  power_line: "power",
  submarine_power_cable: "power",
  landing_point: "telecom",
  submarine_cable: "telecom",
  data_center: "telecom",
  telecom_exchange: "telecom",
  water_works: "water",
  desalination: "water",
  wastewater: "water",
  reservoir: "water",
  dam: "water",
  river: "water",
  water_tower: "water",
};

const LINEAR: Kind[] = ["power_line", "submarine_power_cable", "river"];

const CAP: Partial<Record<Kind, number>> = { power_line: 12, submarine_power_cable: 6, river: 6, water_tower: 8, telecom_exchange: 10 };

export function classify(tags: Record<string, string> = {}): Kind | null {
  const desal = /desal|淡化|swro|reverse osmosis/i.test(`${tags.name ?? ""} ${tags["name:en"] ?? ""}`);
  if (tags.power === "plant") return "power_plant";
  if (tags.power === "substation") return "substation";
  if (tags.power === "line") return "power_line";
  if (tags.power === "cable") {
    return /underwater|submarine|sea/i.test(tags.location ?? "") ? "submarine_power_cable" : "power_line";
  }
  if (tags.telecom === "data_center" || tags.building === "data_center") return "data_center";
  if (tags.telecom === "exchange") return "telecom_exchange";
  if (tags.man_made === "desalination_plant" || tags.water_works === "desalination" || (tags.man_made === "water_works" && desal)) {
    return "desalination";
  }
  if (tags.man_made === "water_works") return "water_works";
  if (tags.man_made === "wastewater_plant") return "wastewater";
  if (tags.man_made === "water_tower") return "water_tower";
  if (tags.man_made === "reservoir_covered" || tags.water === "reservoir" || tags.landuse === "reservoir") return "reservoir";
  if (tags.waterway === "dam") return "dam";
  if (tags.waterway === "river") return "river";
  return null;
}

function attrsFor(kind: Kind, t: Record<string, string>): Record<string, string> {
  const a: Record<string, string> = {};
  const v = voltage(t.voltage);
  if (v) a.voltage = v.label;
  const cap = t["plant:output:electricity"] || t["generator:output:electricity"];
  if (kind === "power_plant" && cap && /\d/.test(cap)) a.capacity = cap;
  if (kind === "power_plant" && (t["plant:source"] || t["generator:source"])) a.source = t["plant:source"] || t["generator:source"];
  if (t.circuits) a.circuits = t.circuits;
  if (t.operator) a.operator = t.operator;
  if (kind === "power_line" && t.power === "cable") a.method = t.location || "underground";
  if (t["capacity"] && /water|desal|wastewater/.test(kind)) a.capacityWater = t.capacity;
  if (t.construction || t["construction:power"]) a.status = "under construction";
  else if (t.proposed || t["proposed:power"]) a.status = "proposed";
  return a;
}

function displayName(t: Record<string, string>) {
  return t.name || t["name:en"] || t.ref || "";
}

function dedupeKey(kind: Kind, t: Record<string, string>, id: string) {
  if (kind === "power_line" || kind === "submarine_power_cable") {
    return `${kind}|${(t.name || t.ref || "").toLowerCase()}|${voltage(t.voltage)?.max ?? "?"}`;
  }
  if (kind === "river") return `river|${(t.name || "").toLowerCase()}`;
  return id;
}

function toFeatures(elements: OsmElement[], ring: Ring, radiusKm: number, retrieved: string): Feature[] {
  const best = new Map<string, Feature>();
  const siteCentre = ringCentroid(ring);

  for (const el of elements) {
    const tags = el.tags ?? {};
    const kind = classify(tags);
    if (!kind) continue;
    const id = `osm-${el.type}-${el.id}`;

    let distanceKm: number;
    let pos: LatLng | null;
    let lines: LatLng[][] | undefined;

    if (el.type === "node") {
      pos = elementPoint(el);
      if (!pos) continue;
      distanceKm = pointToRingKm(pos, ring);
    } else {
      const parts = elementLines(el);
      if (!parts.length) {
        pos = elementPoint(el);
        if (!pos) continue;
        distanceKm = pointToRingKm(pos, ring);
      } else {
        let nearest: LatLng = parts[0][0];
        distanceKm = Infinity;
        for (const p of parts) {
          const r = lineToRingKm(p, ring);
          if (r.km < distanceKm) {
            distanceKm = r.km;
            nearest = r.nearest;
          }
        }
        // The site may sit entirely inside a large area (e.g. a reservoir catchment).
        const rings = elementRings(el);
        if (rings.some((rg) => pointInRing(siteCentre, rg))) distanceKm = 0;

        if (LINEAR.includes(kind)) {
          pos = nearest;
          lines = parts.map((p) => simplifyLine(p, 0.03)).filter((p) => p.length >= 2);
        } else {
          const outer = rings.sort((a, b) => ringAreaHa(b) - ringAreaHa(a))[0];
          if (kind === "reservoir" && outer && ringAreaHa(outer) < 2 && !tags.name) continue;
          pos = outer ? ringCentroid(outer) : elementPoint(el);
          if (!pos) continue;
        }
      }
    }
    if (!(distanceKm <= radiusKm)) continue;

    const f: Feature = {
      id,
      category: CATEGORY_OF[kind],
      kind,
      name: displayName(tags),
      pos,
      lines,
      distanceKm: Math.round(distanceKm * 1000) / 1000,
      attrs: attrsFor(kind, tags),
      source: { provider: "OpenStreetMap", url: osmUrl(el), license: OSM_LICENSE, retrieved },
    };
    const key = dedupeKey(kind, tags, id);
    const prev = best.get(key);
    if (!prev || f.distanceKm < prev.distanceKm) best.set(key, f);
  }

  // Cap per kind, nearest first.
  const byKind = new Map<Kind, Feature[]>();
  for (const f of best.values()) byKind.set(f.kind, [...(byKind.get(f.kind) ?? []), f]);
  const out: Feature[] = [];
  for (const [kind, list] of byKind) {
    list.sort((a, b) => a.distanceKm - b.distanceKm);
    out.push(...list.slice(0, CAP[kind] ?? 25));
  }
  return out;
}

export function pointsQuery(center: LatLng, meters: number) {
  const a = `around:${Math.round(meters)},${center[0].toFixed(6)},${center[1].toFixed(6)}`;
  return `[out:json][timeout:50];
(
  nwr["power"~"^(plant|substation)$"](${a});
  nwr["telecom"~"^(data_center|exchange)$"](${a});
  nwr["building"="data_center"](${a});
  nwr["man_made"~"^(water_works|wastewater_plant|water_tower|desalination_plant|reservoir_covered)$"](${a});
  nwr["water"="reservoir"](${a});
  nwr["landuse"="reservoir"](${a});
  nwr["waterway"="dam"](${a});
);
out geom;`;
}

export function linesQuery(center: LatLng, meters: number, clipKm: number) {
  const a = `around:${Math.round(meters)},${center[0].toFixed(6)},${center[1].toFixed(6)}`;
  const b = bboxAround(center, clipKm);
  const bbox = [b.south, b.west, b.north, b.east].map((x) => x.toFixed(5)).join(",");
  return `[out:json][timeout:50];
(
  way["power"~"^(line|cable)$"](${a});
  way["waterway"="river"](${a});
);
out geom(${bbox});`;
}

export async function runScan(ring: Ring, radiusKm: number, cableRadiusKm?: number): Promise<ScanResult> {
  const center = ringCentroid(ring);
  const siteR = maxRadiusKm(center, ring);
  const queryMeters = (radiusKm + siteR) * 1000;
  const retrieved = nowIso();
  const cableR = cableRadiusKm ?? Math.max(100, radiusKm * 3);

  const [points, lines, cables] = await Promise.allSettled([
    overpass(pointsQuery(center, queryMeters)),
    overpass(linesQuery(center, queryMeters, radiusKm + siteR + 2)),
    scanCables(ring, cableR),
  ]);

  const features: Feature[] = [];
  if (points.status === "fulfilled") features.push(...toFeatures(points.value, ring, radiusKm, retrieved));
  if (lines.status === "fulfilled") features.push(...toFeatures(lines.value, ring, radiusKm, retrieved));
  if (cables.status === "fulfilled") features.push(...cables.value);
  features.sort((a, b) => a.distanceKm - b.distanceKm);

  const fail = (r: PromiseSettledResult<unknown>) => (r.status === "rejected" ? errMessage(r.reason) : null);
  const osmErr = fail(points) ?? fail(lines);
  const tgErr = fail(cables);
  const status: Record<Category, CategoryStatus> = {
    power: osmErr ? { ok: false, message: `OpenStreetMap: ${osmErr}` } : { ok: true },
    water: osmErr ? { ok: false, message: `OpenStreetMap: ${osmErr}` } : { ok: true },
    telecom:
      tgErr || fail(points)
        ? { ok: false, message: [tgErr && `TeleGeography: ${tgErr}`, fail(points) && `OpenStreetMap: ${fail(points)}`].filter(Boolean).join(" · ") }
        : { ok: true },
  };

  const sources: Source[] = [
    { provider: "OpenStreetMap (Overpass API)", url: "https://www.openstreetmap.org/copyright", license: OSM_LICENSE, retrieved },
    { ...CABLE_SOURCE, retrieved },
  ];

  return {
    site: { center, ring, areaHa: Math.round(ringAreaHa(ring) * 10) / 10 },
    radiusKm,
    generatedAt: retrieved,
    features,
    status,
    sources,
  };
}

export { CATEGORY_OF };
