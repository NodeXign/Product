import type { LatLng, ResolvedSite, Ring } from "../types";
import { classifyInput, myMapsMid, parseGoogleMapsUrl, isGoogleMapsUrl } from "../parseInput";
import { parseKml, parseGeoJson, type Placemark } from "../kml";
import { ringAreaHa, fmtCoord, simplifyLine } from "../geo";
import { fetchJson, fetchWithTimeout, nowIso, UpstreamError } from "./http";

export type ResolveResponse = { site: ResolvedSite; alternatives: ResolvedSite[] };

export class InputError extends Error {}

const GOOGLE_HOST = /(^|\.)(google\.[a-z.]+|goo\.gl|g\.co)$/i;

/** Follows a short link (maps.app.goo.gl) to the full Google Maps URL without loading the page. */
export async function expandShortLink(url: string): Promise<string> {
  let current = url;
  for (let hop = 0; hop < 8; hop++) {
    // Only ever request Google hosts, so this can't be used to reach arbitrary URLs.
    if (!GOOGLE_HOST.test(new URL(current).hostname)) break;
    const res = await fetchWithTimeout(current, { redirect: "manual", timeoutMs: 10000 });
    const loc = res.headers.get("location");
    if (!loc || res.status < 300 || res.status >= 400) break;
    current = new URL(loc, current).href;
    // EU consent interstitial carries the real destination in ?continue=
    try {
      const u = new URL(current);
      if (u.hostname.startsWith("consent.") && u.searchParams.get("continue")) current = u.searchParams.get("continue")!;
    } catch {
      /* keep current */
    }
    if (isGoogleMapsUrl(current) && !/goo\.gl/.test(current)) break;
  }
  return current;
}

function fromPlacemarks(pms: Placemark[], kind: "my-maps" | "kml" | "geojson", source: ResolvedSite["source"]): ResolvedSite {
  if (!pms.length) throw new InputError("No placemarks, polygons or points found in that map.");
  const polys = pms.filter((p) => p.ring).sort((a, b) => ringAreaHa(b.ring!) - ringAreaHa(a.ring!));
  const main = polys[0] ?? pms[0];
  const extras = pms.filter((p) => p !== main).map((p) => ({ name: p.name, center: p.center, boundary: p.ring }));
  return {
    name: main.name,
    center: main.center,
    boundary: main.ring,
    extras: extras.length ? extras.slice(0, 40) : undefined,
    kind,
    source,
    note: pms.length > 1 ? `multi:${pms.length}` : undefined,
  };
}

async function readMyMaps(mid: string, viewUrl: string): Promise<ResolvedSite> {
  const kmlUrl = `https://www.google.com/maps/d/kml?mid=${encodeURIComponent(mid)}&forcekml=1`;
  const res = await fetchWithTimeout(kmlUrl, { timeoutMs: 15000 });
  const text = res.ok ? await res.text() : "";
  if (!res.ok || !/<kml[\s>]/i.test(text)) {
    throw new InputError(
      "Couldn't read that My Maps map. In My Maps choose Share → turn on “Anyone with this link can view”, then paste the link again.",
    );
  }
  return fromPlacemarks(parseKml(text), "my-maps", { provider: "Google My Maps", url: viewUrl, retrieved: nowIso() });
}

type GoogleGeocode = {
  status: string;
  error_message?: string;
  results: { formatted_address: string; place_id: string; geometry: { location: { lat: number; lng: number } } }[];
};

type NominatimHit = {
  lat: string;
  lon: string;
  display_name: string;
  osm_type?: string;
  osm_id?: number;
  geojson?: { type: string; coordinates: unknown };
};

async function geocode(query: string, lang: string): Promise<ResolvedSite[]> {
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (key) {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(query)}&language=${lang === "zh" ? "zh-CN" : "en"}&key=${key}`;
    const data = await fetchJson<GoogleGeocode>("Google Geocoding", url, { timeoutMs: 10000 });
    if (data.status === "OK") {
      return data.results.slice(0, 5).map((r) => ({
        name: r.formatted_address,
        center: [r.geometry.location.lat, r.geometry.location.lng] as LatLng,
        kind: "geocode" as const,
        source: {
          provider: "Google Geocoding API",
          url: `https://www.google.com/maps/place/?q=place_id:${r.place_id}`,
          retrieved: nowIso(),
        },
      }));
    }
    if (data.status !== "ZERO_RESULTS") {
      // Fall through to Nominatim on quota / key problems, but keep the reason visible in logs.
      console.warn("Google geocoding:", data.status, data.error_message);
    }
  }

  const base = process.env.NOMINATIM_URL || "https://nominatim.openstreetmap.org/search";
  const url = `${base}?format=jsonv2&limit=5&polygon_geojson=1&polygon_threshold=0.00005&accept-language=${lang === "zh" ? "zh-CN,en" : "en"}&q=${encodeURIComponent(query)}`;
  const hits = await fetchJson<NominatimHit[]>("OpenStreetMap Nominatim", url, { timeoutMs: 10000 });
  return hits.map((h) => {
    let boundary: Ring | undefined;
    if (h.geojson && (h.geojson.type === "Polygon" || h.geojson.type === "MultiPolygon")) {
      const pm = parseGeoJson(JSON.stringify({ type: "Feature", properties: {}, geometry: h.geojson }))[0];
      // Only keep parcel-sized polygons — not whole cities or provinces.
      if (pm?.ring && ringAreaHa(pm.ring) <= 10000) boundary = pm.ring.length > 400 ? simplifyLine(pm.ring, 0.01) : pm.ring;
    }
    return {
      name: h.display_name,
      center: [parseFloat(h.lat), parseFloat(h.lon)] as LatLng,
      boundary,
      kind: "geocode" as const,
      source: {
        provider: "OpenStreetMap Nominatim",
        url: h.osm_type && h.osm_id ? `https://www.openstreetmap.org/${h.osm_type}/${h.osm_id}` : undefined,
        license: "ODbL 1.0 — © OpenStreetMap contributors",
        retrieved: nowIso(),
      },
    };
  });
}

export async function resolveInput(input: string, lang = "en"): Promise<ResolveResponse> {
  const parsed = classifyInput(input);
  const single = (site: ResolvedSite): ResolveResponse => ({ site, alternatives: [] });

  switch (parsed.type) {
    case "coords":
      return single({
        name: fmtCoord(parsed.center, 5),
        center: parsed.center,
        kind: "coordinates",
        source: { provider: "Coordinates entered by user", retrieved: nowIso() },
      });

    case "kml":
      return single(fromPlacemarks(parseKml(parsed.text), "kml", { provider: "Uploaded KML", retrieved: nowIso() }));

    case "geojson":
      return single(fromPlacemarks(parseGeoJson(parsed.text), "geojson", { provider: "Uploaded GeoJSON", retrieved: nowIso() }));

    case "my-maps":
      return single(await readMyMaps(parsed.mid, parsed.url));

    case "google-short": {
      let full: string;
      try {
        full = await expandShortLink(parsed.url);
      } catch (e) {
        throw new UpstreamError("Google Maps", `couldn't open the short link (${(e as Error).message})`);
      }
      const mid = myMapsMid(full);
      if (mid) return single(await readMyMaps(mid, full));
      if (full === parsed.url || !isGoogleMapsUrl(full)) {
        throw new InputError("That short link didn't lead to a Google Maps place. Open it in your browser and paste the full URL instead.");
      }
      return resolveGoogleUrl(full, parsed.url, lang);
    }

    case "google-maps":
      return resolveGoogleUrl(parsed.url, parsed.url, lang);

    case "text": {
      const hits = await geocode(parsed.query, lang);
      if (!hits.length) throw new InputError(`No place found for “${parsed.query}”.`);
      return { site: hits[0], alternatives: hits.slice(1) };
    }
  }
}

async function resolveGoogleUrl(fullUrl: string, originalUrl: string, lang: string): Promise<ResolveResponse> {
  const g = parseGoogleMapsUrl(fullUrl);
  if (g.center) {
    return {
      site: {
        name: g.placeName || fmtCoord(g.center, 5),
        center: g.center,
        kind: "google-maps",
        source: { provider: "Google Maps link", url: originalUrl, retrieved: nowIso() },
        note: g.precise ? undefined : "approx",
      },
      alternatives: [],
    };
  }
  if (g.placeName) {
    const hits = await geocode(g.placeName, lang);
    if (hits.length) {
      const site = { ...hits[0], name: g.placeName, source: { ...hits[0].source, url: hits[0].source.url ?? originalUrl } };
      return { site, alternatives: hits.slice(1) };
    }
  }
  throw new InputError("That Google Maps link has no location in it. Drop a pin on the site, then use Share → Copy link.");
}
