import type { Feature, LatLng, Ring } from "../types";
import { haversineKm, lineToRingKm, pointToRingKm, ringCentroid, simplifyLine, bboxAround } from "../geo";
import { fetchJson, nowIso } from "./http";

const BASE = (process.env.CABLES_API_BASE || "https://www.submarinecablemap.com/api/v3").replace(/\/$/, "");
const PROVIDER = "TeleGeography Submarine Cable Map";
export const TG_LICENSE = "CC BY-NC-SA 3.0 — TeleGeography";

type GJPoint = { type: "Feature"; properties: { id: string; name: string }; geometry: { type: "Point"; coordinates: [number, number] } };
type GJCable = {
  type: "Feature";
  properties: { id: string; name: string; color?: string };
  geometry: { type: "MultiLineString" | "LineString"; coordinates: number[][][] | number[][] };
};

type Cache<T> = { at: number; data: T };
const TTL = 12 * 3600 * 1000;
let lpCache: Cache<GJPoint[]> | null = null;
let cableCache: Cache<GJCable[]> | null = null;

async function landingPoints(): Promise<GJPoint[]> {
  if (lpCache && Date.now() - lpCache.at < TTL) return lpCache.data;
  const fc = await fetchJson<{ features: GJPoint[] }>(PROVIDER, `${BASE}/landing-point/landing-point-geo.json`, { timeoutMs: 20000 });
  lpCache = { at: Date.now(), data: fc.features ?? [] };
  return lpCache.data;
}

async function cableRoutes(): Promise<GJCable[]> {
  if (cableCache && Date.now() - cableCache.at < TTL) return cableCache.data;
  const fc = await fetchJson<{ features: GJCable[] }>(PROVIDER, `${BASE}/cable/cable-geo.json`, { timeoutMs: 30000 });
  cableCache = { at: Date.now(), data: fc.features ?? [] };
  return cableCache.data;
}

type LandingDetail = { cables?: { id: string; name: string }[]; country?: string };
type CableDetail = {
  rfs?: string;
  rfs_year?: number;
  length?: string;
  owners?: string;
  is_planned?: boolean;
  landing_points?: { id: string; name: string; country?: string }[];
};

async function detail<T>(path: string): Promise<T | null> {
  try {
    return await fetchJson<T>(PROVIDER, `${BASE}/${path}.json`, { timeoutMs: 8000 });
  } catch {
    return null;
  }
}

function toLines(g: GJCable["geometry"]): LatLng[][] {
  const parts = (g.type === "LineString" ? [g.coordinates] : g.coordinates) as number[][][];
  return parts.map((part) => part.map((c) => [c[1], c[0]] as LatLng));
}

/** Clips a polyline to a lat/lng box, keeping one vertex beyond each crossing so lines don't stop short. */
function clipToBox(line: LatLng[], box: { south: number; west: number; north: number; east: number }): LatLng[][] {
  const inBox = (p: LatLng) => p[0] >= box.south && p[0] <= box.north && p[1] >= box.west && p[1] <= box.east;
  const out: LatLng[][] = [];
  let cur: LatLng[] = [];
  for (let i = 0; i < line.length; i++) {
    const p = line[i];
    if (inBox(p) || (i > 0 && inBox(line[i - 1])) || (i < line.length - 1 && inBox(line[i + 1]))) cur.push(p);
    else if (cur.length) {
      out.push(cur);
      cur = [];
    }
  }
  if (cur.length) out.push(cur);
  return out.filter((l) => l.length >= 2);
}

/**
 * Landing points within `radiusKm` of the site and cable routes passing within it,
 * nearest first. Enriches the closest few with the cables that land there and
 * ready-for-service / ownership details.
 */
export async function scanCables(ring: Ring, radiusKm: number): Promise<Feature[]> {
  const center = ringCentroid(ring);
  const retrieved = nowIso();
  const [lps, cables] = await Promise.all([landingPoints(), cableRoutes()]);

  const lpHits = lps
    .map((f) => {
      const pos: LatLng = [f.geometry.coordinates[1], f.geometry.coordinates[0]];
      return { f, pos, d: haversineKm(center, pos) };
    })
    .filter((x) => x.d <= radiusKm + 50)
    .map((x) => ({ ...x, d: pointToRingKm(x.pos, ring) }))
    .filter((x) => x.d <= radiusKm)
    .sort((a, b) => a.d - b.d)
    .slice(0, 12);

  const box = bboxAround(center, radiusKm * 1.3);
  const near = bboxAround(center, radiusKm + 5);
  // Cable routes are coarse; a lightly simplified boundary is plenty for distance.
  const coarse = ring.length > 60 ? simplifyLine(ring, 0.05) : ring;
  const cableHits: { f: GJCable; d: number; nearest: LatLng; lines: LatLng[][] }[] = [];
  for (const f of cables) {
    if (!f.geometry) continue;
    let best = { km: Infinity, nearest: center as LatLng };
    const clipped: LatLng[][] = [];
    for (const line of toLines(f.geometry)) {
      // Exact reject: a line that passes within the radius must have a bbox overlapping it.
      let s = 90, w = 180, n = -90, e = -180;
      for (const p of line) {
        if (p[0] < s) s = p[0];
        if (p[0] > n) n = p[0];
        if (p[1] < w) w = p[1];
        if (p[1] > e) e = p[1];
      }
      if (n < near.south || s > near.north || e < near.west || w > near.east) continue;
      const r = lineToRingKm(line, coarse);
      if (r.km < best.km) best = r;
      for (const c of clipToBox(line, box)) clipped.push(simplifyLine(c, 0.2));
    }
    if (best.km <= radiusKm) cableHits.push({ f, d: best.km, nearest: best.nearest, lines: clipped });
  }
  cableHits.sort((a, b) => a.d - b.d);
  const topCables = cableHits.slice(0, 15);

  const [lpDetails, cableDetails] = await Promise.all([
    Promise.all(lpHits.slice(0, 5).map((x) => detail<LandingDetail>(`landing-point/${x.f.properties.id}`))),
    Promise.all(topCables.slice(0, 8).map((x) => detail<CableDetail>(`cable/${x.f.properties.id}`))),
  ]);

  const features: Feature[] = [];
  lpHits.forEach((x, i) => {
    const det = lpDetails[i];
    const attrs: Record<string, string> = {};
    if (det?.cables?.length) attrs.cables = det.cables.map((c) => c.name).join(", ");
    features.push({
      id: `tg-lp-${x.f.properties.id}`,
      category: "telecom",
      kind: "landing_point",
      name: x.f.properties.name,
      pos: x.pos,
      distanceKm: x.d,
      attrs,
      source: {
        provider: PROVIDER,
        url: `https://www.submarinecablemap.com/landing-point/${x.f.properties.id}`,
        license: TG_LICENSE,
        retrieved,
      },
    });
  });
  topCables.forEach((x, i) => {
    const det = cableDetails[i];
    const attrs: Record<string, string> = {};
    if (det?.rfs) attrs.rfs = det.rfs;
    else if (det?.rfs_year) attrs.rfs = String(det.rfs_year);
    if (det?.length) attrs.length = det.length;
    if (det?.owners) attrs.owners = det.owners.length > 140 ? `${det.owners.slice(0, 137)}…` : det.owners;
    if (det?.is_planned) attrs.status = "planned";
    features.push({
      id: `tg-cable-${x.f.properties.id}`,
      category: "telecom",
      kind: "submarine_cable",
      name: x.f.properties.name,
      pos: x.nearest,
      lines: x.lines,
      distanceKm: x.d,
      attrs: { ...attrs, ...(x.f.properties.color ? { _color: x.f.properties.color } : {}) },
      source: {
        provider: PROVIDER,
        url: `https://www.submarinecablemap.com/submarine-cable/${x.f.properties.id}`,
        license: TG_LICENSE,
        retrieved,
      },
    });
  });
  return features;
}

export const CABLE_SOURCE = { provider: PROVIDER, url: "https://www.submarinecablemap.com/", license: TG_LICENSE };
