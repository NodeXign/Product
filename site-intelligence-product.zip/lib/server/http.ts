// Small fetch helpers shared by the API routes.

export const USER_AGENT = `SiteIntelligence/1.0 (siting due-diligence tool${
  process.env.CONTACT_EMAIL ? `; ${process.env.CONTACT_EMAIL}` : ""
})`;

export class UpstreamError extends Error {
  constructor(
    public provider: string,
    message: string,
    public status?: number,
  ) {
    super(message);
  }
}

export async function fetchWithTimeout(url: string, init: RequestInit & { timeoutMs?: number } = {}) {
  const { timeoutMs = 20000, ...rest } = init;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...rest,
      signal: ctrl.signal,
      headers: { "User-Agent": USER_AGENT, ...(rest.headers || {}) },
      cache: "no-store",
    });
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchJson<T>(provider: string, url: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetchWithTimeout(url, init);
  } catch (e) {
    const msg = (e as Error).name === "AbortError" ? "timed out" : (e as Error).message;
    throw new UpstreamError(provider, msg);
  }
  if (!res.ok) throw new UpstreamError(provider, `HTTP ${res.status}`, res.status);
  try {
    return (await res.json()) as T;
  } catch {
    throw new UpstreamError(provider, "invalid JSON");
  }
}

export function errMessage(e: unknown): string {
  if (e instanceof UpstreamError) return e.message;
  if (e instanceof Error) return e.message;
  return String(e);
}

export function nowIso() {
  return new Date().toISOString();
}
