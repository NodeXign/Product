import type { BoundaryCandidate, LatLng } from "../types";
import { pointInRing, ringAreaHa, simplifyLine } from "../geo";
import { overpass, elementRings, osmUrl, OSM_LICENSE, type OsmElement } from "./overpass";
import { nowIso } from "./http";

// Tags that usually describe a developable parcel, estate or island.
const TAG_KEYS = ["landuse", "industrial", "place", "power", "aeroway", "amenity", "leisure", "man_made", "military", "boundary"];

/** Bounding-box area in km² (cheap pre-filter before downloading full geometry). */
function bboxKm2(b: NonNullable<OsmElement["bounds"]>) {
  const h = (b.maxlat - b.minlat) * 111.2;
  const w = (b.maxlon - b.minlon) * 111.2 * Math.cos((((b.maxlat + b.minlat) / 2) * Math.PI) / 180);
  return Math.abs(h * w);
}

function tagLabel(tags: Record<string, string> = {}): string {
  for (const k of TAG_KEYS) if (tags[k]) return `${k}=${tags[k]}`;
  return "area";
}

/**
 * Finds mapped polygons that contain (or sit within 300 m of) the point:
 * industrial estates, landuse parcels, islets, plants, etc. Two passes: bounding
 * boxes first to drop huge areas (whole islands, provinces), then full geometry.
 */
export async function detectBoundaries(center: LatLng, maxKm2 = 120): Promise<BoundaryCandidate[]> {
  const [lat, lng] = center;
  const pass1 = `[out:json][timeout:25];
is_in(${lat},${lng})->.a;
(
  way(pivot.a)["landuse"]; rel(pivot.a)["landuse"];
  way(pivot.a)["industrial"]; rel(pivot.a)["industrial"];
  way(pivot.a)["place"~"^(island|islet|locality|neighbourhood|quarter)$"]; rel(pivot.a)["place"~"^(island|islet)$"];
  way(pivot.a)["power"~"^(plant|substation)$"]; rel(pivot.a)["power"="plant"];
  way(pivot.a)["aeroway"="aerodrome"]; way(pivot.a)["amenity"]; way(pivot.a)["leisure"]; way(pivot.a)["man_made"];
  rel(pivot.a)["boundary"="administrative"]["admin_level"~"^(8|9|10)$"];
  way(around:300,${lat},${lng})["landuse"]; rel(around:300,${lat},${lng})["landuse"];
  way(around:300,${lat},${lng})["industrial"];
);
out tags bb;`;

  const first = await overpass(pass1, 30000);
  const keep = new Map<string, OsmElement>();
  for (const el of first) {
    if (el.type === "node" || !el.bounds) continue;
    const km2 = bboxKm2(el.bounds);
    if (km2 > maxKm2 || km2 < 0.0005) continue;
    keep.set(`${el.type}/${el.id}`, el);
  }
  if (!keep.size) return [];

  const ids = [...keep.values()]
    .sort((a, b) => bboxKm2(a.bounds!) - bboxKm2(b.bounds!))
    .slice(0, 14);
  const ways = ids.filter((e) => e.type === "way").map((e) => e.id);
  const rels = ids.filter((e) => e.type === "relation").map((e) => e.id);
  const pass2 = `[out:json][timeout:25];
(
  ${ways.length ? `way(id:${ways.join(",")});` : ""}
  ${rels.length ? `rel(id:${rels.join(",")});` : ""}
);
out geom;`;
  const full = await overpass(pass2, 30000);

  const out: BoundaryCandidate[] = [];
  for (const el of full) {
    const rings = elementRings(el);
    if (!rings.length) continue;
    // Prefer the ring that holds the point; otherwise the largest.
    const ring =
      rings.find((r) => pointInRing(center, r)) ?? rings.sort((a, b) => ringAreaHa(b) - ringAreaHa(a))[0];
    const simplified = ring.length > 400 ? simplifyLine(ring, 0.01) : ring;
    const tags = el.tags ?? {};
    out.push({
      id: `${el.type}/${el.id}`,
      name: tags.name || tags["name:en"] || "",
      tag: tagLabel(tags),
      ring: simplified,
      areaHa: Math.round(ringAreaHa(simplified) * 10) / 10,
      containsPoint: pointInRing(center, simplified),
      source: { provider: "OpenStreetMap", url: osmUrl(el), license: OSM_LICENSE, retrieved: nowIso() },
    });
  }
  // Containing polygons first, smallest (most specific) first.
  return out.sort((a, b) => Number(b.containsPoint) - Number(a.containsPoint) || a.areaHa - b.areaHa);
}
