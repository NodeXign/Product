import type { LatLng, Ring } from "../types";
import { fetchWithTimeout, UpstreamError } from "./http";

export const DEFAULT_OVERPASS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

export function overpassEndpoints(): string[] {
  const env = process.env.OVERPASS_URLS?.split(",").map((s) => s.trim()).filter(Boolean);
  return env?.length ? env : DEFAULT_OVERPASS;
}

type GeomPt = { lat: number; lon: number } | null;

export type OsmElement = {
  type: "node" | "way" | "relation";
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  bounds?: { minlat: number; minlon: number; maxlat: number; maxlon: number };
  geometry?: GeomPt[];
  members?: { type: string; ref: number; role: string; geometry?: GeomPt[]; lat?: number; lon?: number }[];
  tags?: Record<string, string>;
};

/** Runs a query, trying each endpoint in turn on rate limits, timeouts and server errors. */
export async function overpass(query: string, timeoutMs = 45000): Promise<OsmElement[]> {
  let lastErr = "no endpoint";
  for (const url of overpassEndpoints()) {
    try {
      const res = await fetchWithTimeout(url, {
        method: "POST",
        body: new URLSearchParams({ data: query }).toString(),
        headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
        timeoutMs,
      });
      if (!res.ok) {
        lastErr = `HTTP ${res.status}`;
        continue; // 429 / 504 / 5xx → next mirror
      }
      const data = (await res.json()) as { elements?: OsmElement[]; remark?: string };
      if (data.remark && /error|timed out|out of memory/i.test(data.remark) && !data.elements?.length) {
        lastErr = data.remark.slice(0, 140);
        continue;
      }
      return data.elements ?? [];
    } catch (e) {
      lastErr = (e as Error).name === "AbortError" ? "timed out" : (e as Error).message;
    }
  }
  throw new UpstreamError("OpenStreetMap (Overpass)", lastErr);
}

export function osmUrl(el: Pick<OsmElement, "type" | "id">) {
  return `https://www.openstreetmap.org/${el.type}/${el.id}`;
}

export const OSM_LICENSE = "ODbL 1.0 — © OpenStreetMap contributors";

/** Splits a geometry array on null gaps (Overpass leaves nulls for nodes clipped by a bbox). */
export function geomParts(geom: GeomPt[] | undefined): LatLng[][] {
  const parts: LatLng[][] = [];
  let cur: LatLng[] = [];
  for (const g of geom ?? []) {
    if (g && Number.isFinite(g.lat) && Number.isFinite(g.lon)) cur.push([g.lat, g.lon]);
    else if (cur.length) {
      parts.push(cur);
      cur = [];
    }
  }
  if (cur.length) parts.push(cur);
  return parts;
}

const same = (a: LatLng, b: LatLng) => Math.abs(a[0] - b[0]) < 1e-7 && Math.abs(a[1] - b[1]) < 1e-7;

/** Joins way segments end-to-end into closed rings (multipolygon outer members). */
export function stitchRings(segments: LatLng[][]): Ring[] {
  const pool = segments.filter((s) => s.length >= 2).map((s) => s.slice());
  const rings: Ring[] = [];
  while (pool.length) {
    let ring = pool.shift()!;
    let grew = true;
    while (!same(ring[0], ring[ring.length - 1]) && grew) {
      grew = false;
      for (let i = 0; i < pool.length; i++) {
        const s = pool[i];
        const end = ring[ring.length - 1];
        if (same(end, s[0])) ring = ring.concat(s.slice(1));
        else if (same(end, s[s.length - 1])) ring = ring.concat(s.slice(0, -1).reverse());
        else if (same(ring[0], s[s.length - 1])) ring = s.slice(0, -1).concat(ring);
        else if (same(ring[0], s[0])) ring = s.slice(1).reverse().concat(ring);
        else continue;
        pool.splice(i, 1);
        grew = true;
        break;
      }
    }
    if (ring.length >= 4 && same(ring[0], ring[ring.length - 1])) rings.push(ring.slice(0, -1));
  }
  return rings;
}

/** Polygon rings of an element (closed way, or stitched outer members of a relation). */
export function elementRings(el: OsmElement): Ring[] {
  if (el.type === "way") {
    const parts = geomParts(el.geometry);
    if (parts.length === 1 && parts[0].length >= 4 && same(parts[0][0], parts[0][parts[0].length - 1])) {
      return [parts[0].slice(0, -1)];
    }
    return [];
  }
  if (el.type === "relation") {
    const outers = (el.members ?? [])
      .filter((m) => m.type === "way" && (m.role === "outer" || m.role === ""))
      .flatMap((m) => geomParts(m.geometry));
    return stitchRings(outers);
  }
  return [];
}

/** All polylines of an element (ways and relation members), for distance calculations. */
export function elementLines(el: OsmElement): LatLng[][] {
  if (el.type === "way") return geomParts(el.geometry);
  if (el.type === "relation") return (el.members ?? []).flatMap((m) => geomParts(m.geometry));
  return [];
}

export function elementPoint(el: OsmElement): LatLng | null {
  if (el.lat !== undefined && el.lon !== undefined) return [el.lat, el.lon];
  if (el.center) return [el.center.lat, el.center.lon];
  const lines = elementLines(el);
  const pts = lines.flat();
  if (!pts.length) return null;
  const s = pts.reduce((a, p) => [a[0] + p[0], a[1] + p[1]], [0, 0]);
  return [s[0] / pts.length, s[1] / pts.length];
}
